import { Component, inject, Input, OnInit } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import {
	IWidgetSettingsContext,
	IWidgetSettingsInstance,
} from "@infor-lime/core";
import { SohoButtonModule } from "ids-enterprise-ng";

/**
 * This component can be used to display a Title setting field with a padlock.
 * It works with the given (required) widgetSettingContext to determine whether title should
 * be locked, unlocked, editable, unlockable etc.
 *
 * Call save() to commit the changes to the widget settings.
 */
@Component({
	selector: "infor-sample-setting-title-field",
	template: `
		<div class="field">
			@if (label) {
				<label>{{ label }}</label>
			}
			<input
				[readOnly]="!isTitleEditEnabled || isTitleLocked"
				[(ngModel)]="title" />
			<button
				soho-button="icon"
				[icon]="lockIcon"
				[disabled]="!isTitleUnlockable"
				(click)="onLockClicked()"></button>
		</div>
	`,
	standalone: true,
	imports: [ReactiveFormsModule, FormsModule, SohoButtonModule],
})
export class TitleSettingComponent implements OnInit {
	@Input() widgetSettingsContext!: IWidgetSettingsContext;
	@Input() label!: string;
	readonly #instance = inject(IWidgetSettingsInstance);

	title!: string;
	isTitleEditEnabled!: boolean;
	isTitleUnlockable!: boolean;
	isTitleLocked!: boolean;

	get lockIcon(): string {
		return this.isTitleLocked ? "locked" : "unlocked";
	}

	ngOnInit(): void {
		const widgetContext = this.widgetSettingsContext.getWidgetContext();
		this.isTitleEditEnabled = widgetContext.isTitleEditEnabled();
		this.isTitleLocked = widgetContext.isTitleLocked();
		this.title = widgetContext.getResolvedTitle(this.isTitleLocked);
		this.isTitleUnlockable = widgetContext.isTitleUnlockable();

		this.#instance.closing = ({ isSave }) => {
			if (isSave) {
				this.save();
			}
		};
	}

	/**
	 * Persist changes to the title and lock by saving to widget context.
	 */
	save(): void {
		const widgetContext = this.widgetSettingsContext.getWidgetContext();
		widgetContext.setTitleLocked(this.isTitleLocked);
		if (this.isTitleEditEnabled) {
			widgetContext.setTitle(this.title);
		}
	}

	onLockClicked(): void {
		this.isTitleLocked = !this.isTitleLocked;
		if (this.isTitleLocked) {
			this.title = this.widgetSettingsContext
				.getWidgetContext()
				.getStandardTitle();
		}
	}
}
