import * as i0 from '@angular/core';
import { InjectionToken, ViewContainerRef } from '@angular/core';
import { Observable } from 'rxjs';
import IdsAbout from 'ids-enterprise-wc/components/ids-about/ids-about';
import IdsAccordion from 'ids-enterprise-wc/components/ids-accordion/ids-accordion';
import IdsAccordionHeader from 'ids-enterprise-wc/components/ids-accordion/ids-accordion-header';
import IdsAccordionPanel from 'ids-enterprise-wc/components/ids-accordion/ids-accordion-panel';
import IdsAccordionSection from 'ids-enterprise-wc/components/ids-accordion/ids-accordion-section';
import IdsActionPanel from 'ids-enterprise-wc/components/ids-action-panel/ids-action-panel';
import IdsActionSheet from 'ids-enterprise-wc/components/ids-action-sheet/ids-action-sheet';
import IdsAlert from 'ids-enterprise-wc/components/ids-alert/ids-alert';
import IdsAppMenu from 'ids-enterprise-wc/components/ids-app-menu/ids-app-menu';
import IdsAppMenuContainer from 'ids-enterprise-wc/components/ids-app-menu/ids-app-menu-container';
import IdsAreaChart from 'ids-enterprise-wc/components/ids-area-chart/ids-area-chart';
import IdsAvatar from 'ids-enterprise-wc/components/ids-avatar/ids-avatar';
import IdsAxisChart from 'ids-enterprise-wc/components/ids-axis-chart/ids-axis-chart';
import IdsBadge from 'ids-enterprise-wc/components/ids-badge/ids-badge';
import IdsBarChart from 'ids-enterprise-wc/components/ids-bar-chart/ids-bar-chart';
import IdsBlockGrid from 'ids-enterprise-wc/components/ids-block-grid/ids-block-grid';
import IdsBlockGridItem from 'ids-enterprise-wc/components/ids-block-grid/ids-block-grid-item';
import IdsBox from 'ids-enterprise-wc/components/ids-box/ids-box';
import IdsBreadcrumb from 'ids-enterprise-wc/components/ids-breadcrumb/ids-breadcrumb';
import IdsButton from 'ids-enterprise-wc/components/ids-button/ids-button';
import IdsButtonGroup from 'ids-enterprise-wc/components/ids-button/ids-button-group';
import IdsButtonGroupSection from 'ids-enterprise-wc/components/ids-button/ids-button-group-section';
import IdsCalendar from 'ids-enterprise-wc/components/ids-calendar/ids-calendar';
import IdsCalendarEvent from 'ids-enterprise-wc/components/ids-calendar/ids-calendar-event';
import IdsCard from 'ids-enterprise-wc/components/ids-card/ids-card';
import IdsCardAction from 'ids-enterprise-wc/components/ids-card/ids-card-action';
import IdsCheckbox from 'ids-enterprise-wc/components/ids-checkbox/ids-checkbox';
import IdsCheckboxGroup from 'ids-enterprise-wc/components/ids-checkbox/ids-checkbox-group';
import IdsColor from 'ids-enterprise-wc/components/ids-color/ids-color';
import IdsColorPicker from 'ids-enterprise-wc/components/ids-color-picker/ids-color-picker';
import IdsContainer from 'ids-enterprise-wc/components/ids-container/ids-container';
import IdsCounts from 'ids-enterprise-wc/components/ids-counts/ids-counts';
import IdsDataGrid from 'ids-enterprise-wc/components/ids-data-grid/ids-data-grid';
import IdsDataGridCell from 'ids-enterprise-wc/components/ids-data-grid/ids-data-grid-cell';
import IdsDataGridHeader from 'ids-enterprise-wc/components/ids-data-grid/ids-data-grid-header';
import IdsDataGridRow from 'ids-enterprise-wc/components/ids-data-grid/ids-data-grid-row';
import IdsDataLabel from 'ids-enterprise-wc/components/ids-data-label/ids-data-label';
import IdsDatePicker from 'ids-enterprise-wc/components/ids-date-picker/ids-date-picker';
import IdsDatePickerPopup from 'ids-enterprise-wc/components/ids-date-picker/ids-date-picker-popup';
import IdsDraggable from 'ids-enterprise-wc/components/ids-draggable/ids-draggable';
import IdsDrawer from 'ids-enterprise-wc/components/ids-drawer/ids-drawer';
import IdsDropdown from 'ids-enterprise-wc/components/ids-dropdown/ids-dropdown';
import IdsDropdownList from 'ids-enterprise-wc/components/ids-dropdown/ids-dropdown-list';
import IdsEditor from 'ids-enterprise-wc/components/ids-editor/ids-editor';
import IdsEmptyMessage from 'ids-enterprise-wc/components/ids-empty-message/ids-empty-message';
import IdsErrorPage from 'ids-enterprise-wc/components/ids-error-page/ids-error-page';
import IdsExpandableArea from 'ids-enterprise-wc/components/ids-expandable-area/ids-expandable-area';
import IdsFieldset from 'ids-enterprise-wc/components/ids-fieldset/ids-fieldset';
import IdsFilterField from 'ids-enterprise-wc/components/ids-filter-field/ids-filter-field';
import IdsForm from 'ids-enterprise-wc/components/ids-form/ids-form';
import IdsHeader from 'ids-enterprise-wc/components/ids-header/ids-header';
import IdsHidden from 'ids-enterprise-wc/components/ids-hidden/ids-hidden';
import IdsHierarchy from 'ids-enterprise-wc/components/ids-hierarchy/ids-hierarchy';
import IdsHierarchyItem from 'ids-enterprise-wc/components/ids-hierarchy/ids-hierarchy-item';
import IdsHierarchyLegend from 'ids-enterprise-wc/components/ids-hierarchy/ids-hierarchy-legend';
import IdsHierarchyLegendItem from 'ids-enterprise-wc/components/ids-hierarchy/ids-hierarchy-legend-item';
import IdsHomePage from 'ids-enterprise-wc/components/ids-home-page/ids-home-page';
import IdsHyperlink from 'ids-enterprise-wc/components/ids-hyperlink/ids-hyperlink';
import IdsIcon from 'ids-enterprise-wc/components/ids-icon/ids-icon';
import IdsImage from 'ids-enterprise-wc/components/ids-image/ids-image';
import IdsInput from 'ids-enterprise-wc/components/ids-input/ids-input';
import IdsInputGroup from 'ids-enterprise-wc/components/ids-input-group/ids-input-group';
import IdsKpi from 'ids-enterprise-wc/components/ids-kpi/ids-kpi';
import IdsLayoutFlex from 'ids-enterprise-wc/components/ids-layout-flex/ids-layout-flex';
import IdsLayoutFlexItem from 'ids-enterprise-wc/components/ids-layout-flex/ids-layout-flex-item';
import IdsLayoutGrid from 'ids-enterprise-wc/components/ids-layout-grid/ids-layout-grid';
import IdsLayoutGridCell from 'ids-enterprise-wc/components/ids-layout-grid/ids-layout-grid-cell';
import IdsLineChart from 'ids-enterprise-wc/components/ids-line-chart/ids-line-chart';
import IdsLinkList from 'ids-enterprise-wc/components/ids-hyperlink/ids-link-list';
import IdsListBox from 'ids-enterprise-wc/components/ids-list-box/ids-list-box';
import IdsListBoxOption from 'ids-enterprise-wc/components/ids-list-box/ids-list-box-option';
import IdsListBuilder from 'ids-enterprise-wc/components/ids-list-builder/ids-list-builder';
import IdsListView from 'ids-enterprise-wc/components/ids-list-view/ids-list-view';
import IdsListViewGroupHeader from 'ids-enterprise-wc/components/ids-list-view/ids-list-view-group-header';
import IdsListViewItem from 'ids-enterprise-wc/components/ids-list-view/ids-list-view-item';
import IdsLoadingIndicator from 'ids-enterprise-wc/components/ids-loading-indicator/ids-loading-indicator';
import IdsLookup from 'ids-enterprise-wc/components/ids-lookup/ids-lookup';
import IdsMasthead from 'ids-enterprise-wc/components/ids-masthead/ids-masthead';
import IdsMediaGallery from 'ids-enterprise-wc/components/ids-media-gallery/ids-media-gallery';
import IdsMediaViewer from 'ids-enterprise-wc/components/ids-media-gallery/ids-media-viewer';
import IdsMenu from 'ids-enterprise-wc/components/ids-menu/ids-menu';
import IdsMenuButton from 'ids-enterprise-wc/components/ids-menu-button/ids-menu-button';
import IdsMenuGroup from 'ids-enterprise-wc/components/ids-menu/ids-menu-group';
import IdsMenuHeader from 'ids-enterprise-wc/components/ids-menu/ids-menu-header';
import IdsMenuItem from 'ids-enterprise-wc/components/ids-menu/ids-menu-item';
import IdsMessage from 'ids-enterprise-wc/components/ids-message/ids-message';
import IdsModal from 'ids-enterprise-wc/components/ids-modal/ids-modal';
import IdsModalButton from 'ids-enterprise-wc/components/ids-modal/ids-modal-button';
import IdsModuleNav from 'ids-enterprise-wc/components/ids-module-nav/ids-module-nav';
import IdsModuleNavBar from 'ids-enterprise-wc/components/ids-module-nav/ids-module-nav-bar';
import IdsModuleNavButton from 'ids-enterprise-wc/components/ids-module-nav/ids-module-nav-button';
import IdsModuleNavContent from 'ids-enterprise-wc/components/ids-module-nav/ids-module-nav-content';
import IdsModuleNavItem from 'ids-enterprise-wc/components/ids-module-nav/ids-module-nav-item';
import IdsModuleNavSettings from 'ids-enterprise-wc/components/ids-module-nav/ids-module-nav-settings';
import IdsModuleNavSwitcher from 'ids-enterprise-wc/components/ids-module-nav/ids-module-nav-switcher';
import IdsModuleNavUser from 'ids-enterprise-wc/components/ids-module-nav/ids-module-nav-user';
import IdsMonthView from 'ids-enterprise-wc/components/ids-month-view/ids-month-view';
import IdsMonthYearPicklist from 'ids-enterprise-wc/components/ids-date-picker/ids-month-year-picklist';
import IdsMultiselect from 'ids-enterprise-wc/components/ids-multiselect/ids-multiselect';
import IdsNotificationBanner from 'ids-enterprise-wc/components/ids-notification-banner/ids-notification-banner';
import IdsOverlay from 'ids-enterprise-wc/components/ids-modal/ids-overlay';
import IdsPager from 'ids-enterprise-wc/components/ids-pager/ids-pager';
import IdsPagerButton from 'ids-enterprise-wc/components/ids-pager/ids-pager-button';
import IdsPagerDropdown from 'ids-enterprise-wc/components/ids-pager/ids-pager-dropdown';
import IdsPagerInput from 'ids-enterprise-wc/components/ids-pager/ids-pager-input';
import IdsPagerNumberList from 'ids-enterprise-wc/components/ids-pager/ids-pager-number-list';
import IdsPickerPopup from 'ids-enterprise-wc/components/ids-popup/ids-picker-popup';
import IdsPieChart from 'ids-enterprise-wc/components/ids-pie-chart/ids-pie-chart';
import IdsPopup from 'ids-enterprise-wc/components/ids-popup/ids-popup';
import IdsPopupMenu from 'ids-enterprise-wc/components/ids-popup-menu/ids-popup-menu';
import IdsProcessIndicator from 'ids-enterprise-wc/components/ids-process-indicator/ids-process-indicator';
import IdsProcessIndicatorStep from 'ids-enterprise-wc/components/ids-process-indicator/ids-process-indicator-step';
import IdsProgressBar from 'ids-enterprise-wc/components/ids-progress-bar/ids-progress-bar';
import IdsProgressChart from 'ids-enterprise-wc/components/ids-progress-chart/ids-progress-chart';
import IdsRadio from 'ids-enterprise-wc/components/ids-radio/ids-radio';
import IdsRadioGroup from 'ids-enterprise-wc/components/ids-radio/ids-radio-group';
import IdsRating from 'ids-enterprise-wc/components/ids-rating/ids-rating';
import IdsScrollContainer from 'ids-enterprise-wc/components/ids-layout-flex/ids-scroll-container';
import IdsScrollView from 'ids-enterprise-wc/components/ids-scroll-view/ids-scroll-view';
import IdsSearchField from 'ids-enterprise-wc/components/ids-search-field/ids-search-field';
import IdsSegmentedControl from 'ids-enterprise-wc/components/ids-segmented-control/ids-segmented-control';
import IdsSeparator from 'ids-enterprise-wc/components/ids-separator/ids-separator';
import IdsSkipLink from 'ids-enterprise-wc/components/ids-skip-link/ids-skip-link';
import IdsSlider from 'ids-enterprise-wc/components/ids-slider/ids-slider';
import IdsSpinbox from 'ids-enterprise-wc/components/ids-spinbox/ids-spinbox';
import IdsSplitter from 'ids-enterprise-wc/components/ids-splitter/ids-splitter';
import IdsSplitterPane from 'ids-enterprise-wc/components/ids-splitter/ids-splitter-pane';
import IdsStats from 'ids-enterprise-wc/components/ids-stats/ids-stats';
import IdsStepChart from 'ids-enterprise-wc/components/ids-step-chart/ids-step-chart';
import IdsSubTab from 'ids-enterprise-wc/components/ids-tabs/ids-sub-tab';
import IdsSubTabs from 'ids-enterprise-wc/components/ids-tabs/ids-sub-tabs';
import IdsSwaplist from 'ids-enterprise-wc/components/ids-swaplist/ids-swaplist';
import IdsSwappable from 'ids-enterprise-wc/components/ids-swappable/ids-swappable';
import IdsSwappableItem from 'ids-enterprise-wc/components/ids-swappable/ids-swappable-item';
import IdsSwipeAction from 'ids-enterprise-wc/components/ids-swipe-action/ids-swipe-action';
import IdsSwitch from 'ids-enterprise-wc/components/ids-switch/ids-switch';
import IdsTab from 'ids-enterprise-wc/components/ids-tabs/ids-tab';
import IdsTabContent from 'ids-enterprise-wc/components/ids-tabs/ids-tab-content';
import IdsTabDivider from 'ids-enterprise-wc/components/ids-tabs/ids-tab-divider';
import IdsTabMore from 'ids-enterprise-wc/components/ids-tabs/ids-tab-more';
import IdsTabs from 'ids-enterprise-wc/components/ids-tabs/ids-tabs';
import IdsTabsContext from 'ids-enterprise-wc/components/ids-tabs/ids-tabs-context';
import IdsTag from 'ids-enterprise-wc/components/ids-tag/ids-tag';
import IdsTagList from 'ids-enterprise-wc/components/ids-tag/ids-tag-list';
import IdsText from 'ids-enterprise-wc/components/ids-text/ids-text';
import IdsTextarea from 'ids-enterprise-wc/components/ids-textarea/ids-textarea';
import IdsThemeSwitcher from 'ids-enterprise-wc/components/ids-theme-switcher/ids-theme-switcher';
import IdsTimePicker from 'ids-enterprise-wc/components/ids-time-picker/ids-time-picker';
import IdsTimePickerPopup from 'ids-enterprise-wc/components/ids-time-picker/ids-time-picker-popup';
import IdsToast from 'ids-enterprise-wc/components/ids-toast/ids-toast';
import IdsToastMessage from 'ids-enterprise-wc/components/ids-toast/ids-toast-message';
import IdsToggleButton from 'ids-enterprise-wc/components/ids-toggle-button/ids-toggle-button';
import IdsToolbar from 'ids-enterprise-wc/components/ids-toolbar/ids-toolbar';
import IdsToolbarMoreActions from 'ids-enterprise-wc/components/ids-toolbar/ids-toolbar-more-actions';
import IdsToolbarSection from 'ids-enterprise-wc/components/ids-toolbar/ids-toolbar-section';
import IdsTooltip from 'ids-enterprise-wc/components/ids-tooltip/ids-tooltip';
import IdsTree from 'ids-enterprise-wc/components/ids-tree/ids-tree';
import IdsTreeNode from 'ids-enterprise-wc/components/ids-tree/ids-tree-node';
import IdsTreemap from 'ids-enterprise-wc/components/ids-treemap/ids-treemap';
import IdsTriggerButton from 'ids-enterprise-wc/components/ids-trigger-field/ids-trigger-button';
import IdsTriggerField from 'ids-enterprise-wc/components/ids-trigger-field/ids-trigger-field';
import IdsUpload from 'ids-enterprise-wc/components/ids-upload/ids-upload';
import IdsUploadAdvanced from 'ids-enterprise-wc/components/ids-upload-advanced/ids-upload-advanced';
import IdsUploadAdvancedFile from 'ids-enterprise-wc/components/ids-upload-advanced/ids-upload-advanced-file';
import IdsVirtualScroll from 'ids-enterprise-wc/components/ids-virtual-scroll/ids-virtual-scroll';
import IdsWeekView from 'ids-enterprise-wc/components/ids-week-view/ids-week-view';
import IdsWidget from 'ids-enterprise-wc/components/ids-widget/ids-widget';
import IdsWizard from 'ids-enterprise-wc/components/ids-wizard/ids-wizard';
import IdsWizardStep from 'ids-enterprise-wc/components/ids-wizard/ids-wizard-step';
import { SohoMessageService } from 'ids-enterprise-ng';

/**
 * Represents configuration data for an application in Ming.le.
 *
 * @since 1.0
 */
interface IApplication {
    /**
     * Gets a value that indicates if this application instance is the default one.
     */
    isDefault: boolean;
    /**
     * Gets the application version.
     */
    version: string;
    /**
     * Gets the product name.
     */
    productName: string;
    /**
     * Gets the tenant ID.
     */
    tenantId: string;
    /**
     * Gets the logical ID prefix.
     */
    logicalIdPrefix: string;
    /**
     * Get the logical ID for the application instance.
     */
    logicalId: string;
    /**
     * Gets the hostname.
     */
    hostname: string;
    /**
     * Get the URL context.
     */
    context: string;
    /**
     * Gets the port number.
     */
    port: number;
    /**
     * Gets a value that indicates if HTTPS should be used.
     */
    useHttps: boolean;
    /**
     * Gets the custom properties and settings for the application.
     * @since 1.0.11
     */
    customProperties: ICustomProperties;
}
/**
 * Represents custom properties and settings for the application.
 */
interface ICustomProperties {
    [key: string]: any;
}
/**
 * Defines data sources for workspace settings.
 * The "static" data source is used when the settings values are manually configured by an admin user.
 * The "dynamic" data source is used when the widget loads settings values from an API.
 * @since 3.40.0, 2024.10
 */
type WorkspaceSettingSource = "static" | "dynamic";
/**
 * Defines types of rules for workspace settings.
 *
 * "cn" = Contains
 * "eq" = Equals
 * "in" = In set
 * "nin" = Not in set
 * "rn" = Range
 * "sw" = Starts with
 *
 * @since 3.40.0, 2024.10
 */
type WorkspaceSettingRuleType = "cn" | "eq" | "in" | "nin" | "rn" | "sw";
/**
 * Defines types of workspace settings.
 * @since 3.40.0, 2024.10
 */
type WorkspaceSettingType = "string";
/**
 * Represents a value for a workspace setting.
 * @since 3.40.0, 2024.10
 */
interface IWorkspaceSettingValue {
    /**
     * Gets the settings value.
     */
    value: string;
    /**
     * Gets an optional value label.
     * If no label is specified the value should be used as the label.
     */
    label?: string;
}
/**
 * Represents a rule for a workspace setting.
 * @since 3.40.0, 2024.10
 */
interface IWorkspaceSettingRule {
    /**
     * Gets the type of rule.
     */
    type: WorkspaceSettingRuleType;
    /**
     * Gets the rules value.
     * Some rules such as "range" will have more than one value.
     * If a rule has a single value, the array will contain a single item.
     */
    values: string[];
}
/**
 * Represents a workspace setting.
 * @since 3.40.0, 2024.10
 */
interface IWorkspaceSetting {
    /**
     * The name of the setting.
     * This name is used to refer to the setting in code and in Companyon messages.
     * A setting name should be an alphanumeric string of 1-32 characters.
     */
    name: string;
    /**
     * The setting data type.
     * The default value is "string".
     * Only the “string” data type is supported for now, but other types may be added in future releases.
     */
    type: WorkspaceSettingType;
    /**
     * The setting label.
     * The label is optional for settings that do not require a label.
     */
    label?: string;
    /**
     * The source for the setting data.
     * Some settings can support more than one data source, and the source to use can be configured.
     * The default value is "static".
     */
    source: WorkspaceSettingSource;
    /**
     * Indicates if the setting is enabled.
     * The default value is true.
     */
    enabled: boolean;
    /**
     * Indicates if the setting is visible.
     * The default value is true.
     */
    visible: boolean;
    /**
     * The max length of a setting value.
     * The default value is the 64, which is the max.
     */
    maxLength: number;
    /**
     * The max number of setting values or rules that can be configured for the setting.
     * The default value is the 20, which is the max.
     */
    maxItems: number;
    /**
     * An array of static values.
     * This property may only be set if the data source is "static".
     */
    values?: IWorkspaceSettingValue[];
    /**
     * A default value.
     * The default value is optional.
     */
    defaultValue?: string;
    /**
     * An array of rules.
     * This property may only be set if the data source is "dynamic".
     */
    rules?: IWorkspaceSettingRule[];
    /**
     * Indicates if character casing should be ignored when evaluating rules for the setting.
     * The default value is false.
     */
    ignoreCase: boolean;
}
/**
 * Represents a configuration of workspace settings.
 *
 * There will always be one default configuration,
 * and there can be one or more additional configurations connected to a functional role.
 *
 * @since 3.40.0, 2024.10
 */
interface IWorkspaceSettingsConfiguration {
    /**
     * Gets an array of workspace settings.
     *
     * This is a combination of the settings metadata from the workspace JSON and any data configured
     * by an administrator in the Portal Admin tool.
     */
    settings: IWorkspaceSetting[];
    /**
     * Gets the workspace settings data that has been saved by a user for this configuration.
     * The data can be an empty object, and the widget should expect that any setting value can be undefined.
     */
    data: IWorkspaceSettingsData;
    /**
     * Tests if a value matches the rules defined for the setting.
     * If no rules are defined for the settings, the method will always return true.
     * Usage of this method is optional, and it is not applicable for settings dynamic data sources
     * where the rules are evaluated by a server API.
     *
     * @param settingName the name of the setting to match the value against
     * @param value the value to match
     * @returns true if the value matches the rules, or if no rules are defined
     */
    isMatch(settingName: string, value: string): boolean;
}
/**
 * Represents the workspace settings context that is provided to the workspace settings widget.
 *
 * @since 3.40.0, 2024.10
 */
interface IWorkspaceSettingsContext {
    /**
     * Gets the currently active workspace settings configuration.
     */
    configuration: IWorkspaceSettingsConfiguration;
}
/**
 * Represents workspace level settings for widgets on a workspace.
 * The key is the setting name and the value is the setting value as a string.
 *
 * @since 3.40.0, 2024.10
 */
interface IWorkspaceSettingsValues {
    /**
     * Gets a setting value as a string, or undefined if the setting has not been configured.
     */
    [key: string]: string;
}
/**
 * Represents workspace settings data.
 * An object of this type is provided to a workspace settings widget when the workspace settings events are raised.
 *
 * @since 3.40.0, 2024.10
 */
interface IWorkspaceSettingsData {
    /**
     *  Gets the workspace settings values.
     */
    settings: IWorkspaceSettingsValues;
    /**
     * Gets the ID of the settings configuration that this data applies to.
     * The ID will be "default" for the default configuration.
     * The ID for additional configuration can be a functional role, or some other kind of identifier.
     */
    id?: string;
}
/**
 * Represents the data for a "inforWorkspaceContext" message.
 *
 * The "inforWorkspaceContext" message is used to propagate workspace level settings to widgets on a workspace,
 * but may also be used for other purposes in future releases.
 *
 * @since 3.40.0, 2024.10
 */
interface IWorkspaceContextData {
    /**
     *  Gets the workspace settings values.
     */
    settings: IWorkspaceSettingsValues;
    /**
     * Gets the ID of the current workspace settings configuration.
     * This property is only intended for information purposes and should not be used in logic.
     */
    id?: string;
}
/**
 * Defines the event types for a workspace settings event.
 */
type WorkspaceSettingsEvent = "init" | "apply" | "reset";
/**
 * Represent event arguments for workspace settings.
 *
 * @since 3.40.0, 2024.10
 */
interface IWorkspaceSettingsArg {
    /**
     * The type of event.
     */
    type: WorkspaceSettingsEvent;
    /**
     * The currently active workspace settings context.
     */
    context: IWorkspaceSettingsContext;
}
/**
 * Represent event arguments for workspace settings.
 *
 * @since 3.40.0, 2024.10
 */
interface IWorkspaceSettingsState {
    /**
     *
     */
    data?: IWorkspaceSettingsData;
}
/**
 * Represents localized language constants.
 * @since 1.0
 */
interface ILanguage<T = null> extends ISharedLanguage {
    /**
     * Gets a language constant with the given ID.
     * @param id The language constant ID.
     * @return Gets the language constant or null if it does not exist.
     */
    get(id: T extends null ? string : keyof (T & ISharedLanguage)): string;
    /**
     * Formats a localization string by replacing {0} with the value parameter
     * @param text The string containing replacement variable {0}
     * @param value The value to be inserted at {0}
     * @return Returns the formatted text string.
     */
    format(text: string, value: string): string;
}
/**
 * Shared lime language constants.
 *
 * The following language constants will always be available to use from the widget.
 * Constants listed here does not have to be specified & localized in the widget manifest.
 */
interface ISharedLanguage {
    /**
     * OK
     */
    ok: string;
    /**
     * Cancel
     */
    cancel: string;
    /**
     * Yes
     */
    yes: string;
    /**
     * No
     */
    no: string;
    /**
     * Refresh
     */
    refresh: string;
    /**
     * Add
     */
    add: string;
    /**
     * Save
     */
    save: string;
    /**
     * Delete
     */
    delete: string;
    /**
     * Name
     */
    name: string;
    /**
     * Url
     */
    url: string;
    /**
     * Edit
     */
    edit: string;
    /**
     * Translations
     * @since 1.0.22
     */
    translations: string;
}
/**
 * Represents an item in the map with environment information returned by
 * the Companyon client function getEnvironmentInformation.
 */
interface EnvironmentInfo {
    LogicalId: string;
    ApplicationName: string;
    DisplayName: string;
    ApplicationVersion: string;
    IconUrl: string;
}
/**
 * Represents the map with environment information returned by
 * the Companyon client function getEnvironmentInformation.
 */
interface EnvironmentInfoMap {
    [key: string]: EnvironmentInfo;
}
/**
 * Options for {@link IWidgetContext.showBadge}.
 *
 * @property count - The value to be displayed in the badge. Must be a number equal to or greater than 0.
 * @property type - The type of the badge, the default is {@link BadgeType.Info}
 *
 * @since 3.8.0
 */
interface IBadgeOptions {
    count: number;
    type?: BadgeType;
}
/**
 * Badge type controlling the background color of the badge.
 * @since 3.8.0
 */
declare enum BadgeType {
    Info = 0,
    Alert = 1,
    Error = 2,
    Good = 3,
    Neutral = 4
}
/**
 * Options for {@link IWidgetContext.setEmptyState}.
 *
 * @since 3.11.0
 */
interface IEmptyStateOptions {
    title: string;
    icon: EmptyStateIcon;
    description?: string;
    button?: IEmptyStateButtonOptions;
}
/**
 * Options for the button in the empty state message shown by {@link IWidgetContext.setEmptyState}.
 *
 * @since 3.11.0
 */
interface IEmptyStateButtonOptions {
    text: string;
    click?: Function;
}
/**
 * Icon to be used in the empty state message shown by {@link IWidgetContext.setEmptyState}.
 *
 * @since 3.11.0
 */
declare enum EmptyStateIcon {
    ErrorLoading = "error-loading",
    Generic = "generic",
    GenericAlt = "generic-alt",
    NewProject = "new-project",
    NoAlerts = "no-alerts",
    NoAnalytics = "no-analytics",
    NoBudget = "no-budget",
    NoData = "no-data",
    NoEvents = "no-events",
    NoNotes = "no-notes",
    NoOrders = "no-orders",
    NoTasks = "no-tasks",
    NoUsers = "no-users",
    SearchData = "search-data"
}
/**
 * Options for [[IWidgetContext.trackEvent]]
 *
 * @since 3.11.0
 */
interface ITrackEventOptions {
    /**
     * Name of the event, e.g "Add Item", "Save", "Launch Drillback".
     */
    name: string;
    type: TrackEventType;
    /**
     * Optional extra attributes of the event.
     */
    attributes?: ITrackingAttributes;
}
declare enum TrackEventType {
    Click = "click"
}
interface ITrackViewOptions {
    /**
     * Name of the view, e.g "Home", "Settings", "Details".
     */
    name: string;
    /**
     * Tags used create reports
     */
    tags?: [string] | [string, string] | [string, string, string];
    /**
     * Optional extra attributes of the view.
     */
    attributes?: ITrackingAttributes;
}
interface ITrackingAttributes {
    screenId?: string;
    logicalIdPrefix?: string;
}
/**
 * Defines sources for messages.
 * The "default" message source is used for normal messages.
 * The "push" message source is used for push notifications.
 * Note that Push notifications are only supported in Portal, which can be checked with widgetContext.isPortal().
 *
 * @since 3.10.0
 */
type MessageSource = "default" | "push";
/**
 * Represents a Companyon message or a push notification message.
 *
 * @since 3.29.0, 2023.11
 */
interface IMessage<T> {
    /**
     * The Companyon message type.
     */
    type?: string;
    /**
     * The Companyon message data.
     */
    data?: T;
    /**
     * The push notification message type.
     */
    messageType?: string;
    /**
     * The push notification destination.
     */
    destination?: string;
    /**
     * The push notification body.
     */
    body?: T;
}
/**
 * Options used to register for messages.
 *
 * @since 3.10.0
 */
interface IMessageOptions {
    /**
     * The message type.
     * This property is mandatory.
     */
    messageType: string;
    /**
     * An optional message namespace.
     * A unique namespace will be automatically generated when necessary if not provided.
     */
    namespace?: string;
    /**
     * An optional message source.
     * This property is mandatory when subscribing to push notifications.
     * Note that Push notifications are only supported in Portal, which can be checked with widgetContext.isPortal().
     */
    source?: MessageSource;
    /**
     * An application name.
     * This property should only be used for push notifications and in that case it is mandatory.
     */
    application?: string;
    /**
     * A context ID.
     * Used for push notifications.
     */
    contextId?: string;
}
/**
 * Represents a widget module.
 *
 * A widget module must implement a widget factory function called widgetFactory.
 * The function signature of the widget factory function is defined in this interface.
 * @since 1.0
 */
interface IWidgetModule {
    /**
     * Creates a new widget instance.
     *
     * @param context The widget context.
     * @returns An object representing the widget instance.
     */
    widgetFactory(context: IWidgetContext): IWidgetInstance;
}
/**
 * Represents a widget module.
 *
 * A widget module must implement a widget factory function called widgetFactory.
 * The function signature of the widget factory function is defined in this interface.
 * @since 1.0.17
 */
interface IWidgetModule2 extends IWidgetModule {
}
/**
 * Defines widget states.
 * @since 1.0
 */
declare class WidgetState {
    /**
     * Running state.
     *
     * The running state is the default widget state.
     */
    static readonly running = "running";
    /**
     * Busy state.
     *
     * The busy state can be used to indicate that the widget is busy performing an operation
     * such as a server request.
     */
    static readonly busy = "busy";
    /**
     * Error state.
     *
     * The error state indicates that the widget is broken in some way and is not functioning properly.
     * There could be different reasons for this such as missing settings
     * or that a backend service cannot be reached for example.
     */
    static readonly error = "error";
}
/**
 * Represents a widget activation or deactivation.
 * @since 1.0
 */
interface IWidgetActivationArg {
    /**
     * Gets the type of activation.
     *
     * Activation types are defined in [[WidgetActivationType]].
     */
    type: string;
    /**
     * Gets a value that indicates if the widget is new.
     *
     * A widget is considered to be new if it has been added from the widget library.
     */
    isNew?: boolean;
}
/**
 * Represents a widget destroy event.
 *
 * @since 1.0.28
 */
interface IWidgetDestroyArg {
}
/**
 * Represents the widget settings close event.
 *
 * @since 1.0
 */
interface IWidgetSettingsCloseArg {
    /**
     * Gets a value that indicates if the widget settings was saved.
     *
     * If the value is false the settings were cancelled.
     */
    isSave: boolean;
}
/**
 * Defines widget activation and deactivation types.
 *
 * The activation types indicates what caused a widget to be activated or deactivated.
 * Most types can be used for both activation and deactivation but close for example can only be used in deactivation.
 *
 * @since 1.0
 */
declare class WidgetActivationType {
    /**
     * The widget visibility has been changed.
     */
    static readonly visibility = "visibility";
    /**
     * The "close" type has been deprecated since it was never raised.
     * If it was raised it would only happen just before the widget is destroyed which serves no purpose.
     *
     * Usage is deprecated from version 2.0.0 and the property may be removed in future versions.
     *
     * @deprecated
     */
    static readonly close = "close";
    /**
     * The widget settings dialog has been opened or closed.
     */
    static readonly settings = "settings";
    /**
     * The widget has entered or exited edit mode.
     */
    static readonly edit = "edit";
}
/**
 * Represents the configuration for a widget implemented using Angular.
 *
 * When this configuration is used the framework will create the widget UI using an Angular module and
 * a component type or a component selector.
 *
 * The widget factory should not modify the parent DOM element directly when IAngularWidgetConfig is used.
 *
 * @since 1.0
 */
interface IAngularWidgetConfig {
    /**
     * @deprecated Use a `componentType` with a component marked as `standalone` instead. See https://angular.dev/guide/components/importing#standalone-components
     *
     * Gets or sets an Angular module type that has at least one component.
     */
    moduleType?: any;
    /**
     * Gets or sets the Angular AOT module factory.
     *
     * This property is mandatory for an AOT widget.
     * @since 1.0.22
     *
     * @deprecated This property is no longer used, and will be removed in the future.
     */
    moduleFactory?: any;
    /**
     * Gets or sets an Angular component type used to find the Angular component factory for the widget component.
     */
    componentType?: any;
}
/**
 * Represents the configuration for a widget implemented using web components.
 *
 * When this configuration is used the framework will register and create
 * the element for the widget using a component type.
 *
 * The widget factory should not modify the parent DOM element directly when IWebComponentWidgetConfig is used.
 *
 * @since 3.33.0
 */
interface IWebComponentWidgetConfig<ComponentType = IWidgetComponent> {
    /**
     * Gets or sets a web component type used to create the widget component.
     */
    componentType?: CustomElementConstructor & {
        new (...params: any[]): ComponentType;
    };
}
/**
 * Represents the configuration for a widget implemented using Angular.
 *
 * When this configuration is used the framework will create the widget UI using an Angular module and
 * a component type or a component selector.
 *
 * The widget factory should not modify the parent DOM element directly when IAngularWidgetConfig2 is used.
 *
 * @since 1.0.17
 */
interface IAngularWidgetConfig2 extends IAngularWidgetConfig {
}
/**
 * Represents a custom widget action.
 *
 * Custom widget action will be displayed in the widget menu.
 *
 * @since 1.0
 */
interface IWidgetAction {
    /**
     * Gets or sets the text to display for the action.
     */
    text?: string;
    /**
     * Gets or sets a function that will be called when the action is executed by the user.
     */
    execute?: Function;
    /**
     * Gets or sets a value that indicates if the action is enabled or not.
     *
     * The default value is true.
     */
    isEnabled?: boolean;
    /**
     * Gets or sets a value that indicates if the action should be available
     * even if the widget is not configured.
     *
     * Actions are normally not available when a widget that requires configuration is not configured.
     * This property can be used to override this behavior for specific actions that can still be used
     * when the widget is not configured.
     *
     * The default value is false.
     *
     * @since 1.0.34
     */
    isEnabledNotConfigured?: boolean;
    /**
     * Gets or sets a value that indicates if the action is visible or not.
     *
     * The default value is true.
     */
    isVisible?: boolean;
    /**
     * Gets or sets a value that indicates if the action represents a separator or not.
     *
     * The default value is false.
     */
    isSeparator?: boolean;
    /**
     * Gets or sets a value that indicates if the action represents a submenu or not.
     *
     * The default value is false.
     *
     * @since 1.0.13
     */
    isSubmenu?: boolean;
    /**
     * Gets or sets a value that indicates if the action is primary and should be shown in the widget header.
     * If an action is primary, it has to be set on the widget instance before it's returned from the widget factory
     */
    isPrimary?: boolean;
    /**
     * Gets or sets a SoHo Xi icon name to use if it is a primary widget header action (ex. "#icon-delete").
     *
     */
    standardIconName?: string;
    /**
     * Gets or sets a custom svg icon name to use if it is a primary widget header action.
     *
     */
    customIconName?: string;
    /**
     * Gets or sets submenu items to the widget menu, use with isSubmenu.
     *
     * @since 1.0.13
     */
    submenuItems?: IWidgetAction[];
    /**
     * Determines how the primary action is displayed in the widget header.
     * The default value if not specified is "icon".
     *
     * "icon" - Only show the icon
     * "text" - Only show the text
     * "icon-text" - Show the text next to the icon
     *
     * @since 3.27.0
     */
    primaryDisplay?: "icon" | "text" | "icon-text";
    /**
     * If set, the action will be displayed as a menu button with a popupmenu containing these options.
     * Note: Only applicable for actions that are primary.
     * Actions displayed as a menu button will not appear in the widget menu.
     *
     * since 3.28.0
     */
    options?: IWidgetActionOption[];
    /**
     * Display a check mark next to the selected option.
     * Note: Only applicable for actions that are primary, with options set.
     *
     * @since 3.28.0
     */
    optionsSelectable?: boolean;
    /**
     * If true, a notification badge (info) will be shown on the primary action icon.
     * Note: Only applicable for actions that are primary, with options set and that only display an icon.
     *
     * @since 3.28.0
     */
    notify?: boolean;
    /**
     * If the widget uses navigation, view can be set to "detail"
     * to show the action in the details view instead (two such actions are allowed).
     * The default value if not specified is "default".
     * Note: "detail" actions are implicitly primary, as the widget menu isn't displayed in the details view.
     *
     * @since 2024.03
     */
    view?: "default" | "detail";
}
/**
 * Widget action option displayed in a popupmenu, when action is shown as a menu button.
 *
 * @since 3.28.0
 */
interface IWidgetActionOption {
    text: string;
    execute?: () => void;
    isSelected?: boolean;
    /**
     * Indicates if the option is enabled or not. The default value is true.
     */
    isEnabled?: boolean;
}
/**
 * A message type used to display inline widget messages.
 *
 * @since 1.0
 */
interface IWidgetMessage {
    /**
     * The plain text message to display
     */
    message: string;
    /**
     * Type defines severity and how the message looks like.
     */
    type: WidgetMessageType;
    /**
     * Text used for a clickable link. The link will only show if onLinkClick is set as well.
     * @since 3.10.0
     */
    linkText?: string;
    /**
     * Override logic for the X (Close) button on the message
     * If used, the message needs to be removed using IWidgetContext.removeWidgetMessage().
     */
    onClose?: () => void;
    /**
     * Callback when the link is clicked, if set.
     * @since 3.10.0
     */
    onLinkClick?: () => void;
}
/**
 * A widget status.
 *
 * @since 2.5.0
 */
interface IWidgetStatus {
    message?: string;
    /**
     * A number between 1 and 99.
     */
    count?: number;
}
/**
 * Used to define severity in IWidgetMessage.
 *
 * @since 1.0
 */
declare enum WidgetMessageType {
    /**
     * Information message.
     */
    Info = 0,
    /**
     * Alert message.
     */
    Alert = 1,
    /**
     * Error message.
     */
    Error = 2,
    /**
     * Success message.
     * @since 3.10.0
     */
    Success = 3
}
/**
 * Represents a widget instance.
 *
 * An object of this type should be returned by the widgetFactory function in the widget module.
 * All properties in this interface are optional however so it is OK to return an empty object.
 *
 * A widget implementation may choose which properties to set depending on what types of callbacks the widget requires.
 *
 * @since 1.0
 */
declare abstract class IWidgetInstance {
    /**
     * Optional event function that will be called when the widget is activated.
     *
     * A widget is activated when it is shown after being hidden,
     * the settings dialog is closed or the widget is no longer in edit mode.
     *
     * Note that the activated function is not called when a widget is created.
     * A newly created widget is always considered activated.
     * The activated function will only be called after the widget has been deactivated at least once.
     */
    abstract activated?: (arg: IWidgetActivationArg) => void;
    /**
     * Optional event function that will be called when the widget is deactivated.
     *
     * A widget is deactivated when it is not visible, the settings dialog is open or the widget is in edit mode.
     */
    abstract deactivated?: (arg: IWidgetActivationArg) => void;
    /**
     * Optional event function that will be called when the widget is destroyed.
     *
     * This function should be implemented by widgets that need to do special cleanup such
     * as removing IFrames etc. Most Angular widgets can just rely on the OnDestroy interface and do not
     * need to implement this function.
     *
     * @since 1.0.28
     */
    abstract destroy?: (arg: IWidgetDestroyArg) => void;
    /**
     * Optional event function that will be called before the settings dialog for a widget is opened.
     */
    abstract settingsOpening?: (arg: IWidgetSettingsArg) => void;
    /**
     * Optional event function that will be called when settings are saved for a widget.
     */
    abstract settingsSaved?: (arg: IWidgetSettingsArg) => void;
    /**
     * Optional event function that will be called when the widget is restored.
     * Restore is available in the widget menu and restore the widget to the default configuration.
     * If the title are set from api it will not be restored but the widget can choose to do so by adding
     * this restore function.
     */
    abstract restored?: (arg: IWidgetRestoreArg) => void;
    /**
     * Optional event function that will be called when a user has clicked the refresh button or the refresh menu item.
     *
     * This functionality requires that the enableRefresh manifest property is set to true.
     *
     * @since 1.0.21
     */
    abstract refreshed?: (arg: IWidgetRefreshArg) => void;
    /**
     * Optional event function that will be called when the parent page color is changed.
     *
     * A Banner widget may register this callback to be able to update styles based on the new banner container color
     * Function is called with the new color string as parameter, ex. "#0E5B52"
     * Function will not be called for widgets not used as Banners
     */
    abstract bannerBackgroundChanged?: (newBackgroundColor: string) => void;
    /**
     * Optional function that gets settings metadata for a widget with dynamic settings metadata.
     *
     * If this function returns an array with at least one item the existing settings metadata will be overridden.
     * This function will be called by the framework when settings metadata is required such as when opening the
     * settings dialog or publishing a widget. A widget that defines settings in the manifest should normally not
     * implement this function.
     *
     * @returns An array with metadata for each setting.
     */
    abstract getMetadata?: () => IWidgetSettingMetadata[];
    /**
     * Optional function that gets settings metadata asynchronously for a widget with dynamic settings metadata.
     *
     * This fuction is similar to the getMetadata function but allows the widget to call a server to get
     * the settings metadata. The Homepages UI will be blocked by a progress indicator while the widget loads the
     * settings metadata.
     *
     * @returns An Observable for the settings metadata.
     */
    abstract getMetadataAsync?: () => Observable<IWidgetSettingMetadata[]>;
    /**
     * Optional function that gets if the widget is properly configured
     *
     * This function may be implemented if the "requiresConfig" flag is set to true in the Manifest.
     * If not implemented, the configuration check is made by the Framework where the configuration is deemed valid if
     * at least one setting has an assigned value.
     * This function can be used if more advanced validation criterias are required.
     *
     * Function will get called when the widget is loaded, reset to default or when Configuration dialog is saved,
     * if requiresConfig flag is set to true in the Manifest
     *
     * @returns A boolean indicating if the widget is properly configured or not
     */
    abstract isConfigured?: (settings: IWidgetSettings) => boolean;
    /**
     * Optional function that will be called when the button in the empty state is clicked.
     * @since 1.0.32
     */
    abstract emptyConfigClicked?: () => void;
    /**
     * Optional event function that will be called when the widget enters edit mode.
     */
    abstract editing?: () => void;
    /**
     * Optional event function that will be called when the widget exits edit mode.
     */
    abstract edited?: () => void;
    /**
     * Gets or sets an optional event function that will be called when the widget enters publish widget mode.
     */
    abstract publishing?: () => void;
    /**
     * Gets or sets an optional event function that will be called when a workspace settings event is raised.
     * This method should only be implemented by widgets that provides a UI for the workspace settings section.
     *
     * The expected return value depends on the event type.
     *
     * The “init” event is raised when the settings widget is initially loaded and when the settings configuration
     * is changed, if there is more than one configuration. In both cases the widget is expected to update the settings
     * values, which settings components are visible, enabled etc.
     * The widget should return undefined or null for the "init" event, the framework will ignore any return value.
     *
     * The “apply” event is raised when the user clicks the “Apply” button in the workspace settings section.
     * The widget should return the settings data that the user has selected for the "apply" event.
     * The framework will save the returned data for the user so that it is available the next time the workspace is opened.
     * The widget can return undefined or null to prevent the "apply" event in case there are validation errors that
     * the user must address, or if there is some other kind of error.
     *
     * The “reset” event is raised when the user clicks the “Reset All” button in the workspace settings section.
     * The settings data will be reset to a default state for the "reset" event. The default state for the settings data
     * is usually an empty object, but it could contain configured default values.
     * The widget should update the settings values with the settings data that is received for the "reset" event.
     * In most cases the widget should just return the settings data that is provided in the event (arg.context.configuration.data).
     * The widget may set some default values on the settings data that is returned, if that is applicable for the widget.
     * The framework will save the returned data in the same way as for the "apply" event.
     *
     * @returns Workspace settings data or undefined.
     */
    abstract workspaceSettings?: (arg: IWorkspaceSettingsArg) => IWorkspaceSettingsData | undefined | null;
    /**
     * Gets or sets an optional configuration for a widget implemented using Angular.
     *
     * This property should not be used if content is added to the element property in IWidgetContext.
     */
    abstract angularConfig?: IAngularWidgetConfig;
    /**
     * Gets or sets an optional configuration for a widget implemented using web components.
     * This property is mandatory for widgets the specify framework as "webcomponent" in the widget manifest.
     *
     * @since 3.33.0
     */
    abstract webComponentConfig?: IWebComponentWidgetConfig;
    /**
     * Gets or sets an optional factory function for creating a custom settings UI.
     *
     * Set this function to create custom content in the widget settings dialog.
     * The custom content should contain everything except the save and cancel buttons that are handled
     * by the framework. The custom dialog content can be created with Angular or with jQuery.
     *
     * To hande the complete dialog use the settingsOpening event and cancel the settings and then open your own dialog.
     */
    abstract widgetSettingsFactory?: (context: IWidgetSettingsContext) => IWidgetSettingsInstance;
    /**
     * Gets or sets an optional array of custom widget actions that will be displayed in the widget menu.
     */
    abstract actions?: IWidgetAction[];
    /**
     * Optional function to return the IFrame Name for Hybrid widgets that use IFrame to show the UI and that would like
     * to receive inforBusinessContext messages. This function must be
     * implemented for Context Application Widgets that subscribes to context messages to provide easy access to the
     * IFrame for message delivery but it optional for other types of widgets.
     * @since 2.5.0
     */
    abstract getIFrameName?: () => string;
    /**
     * Set this function to return a runtime version for a widget.
     * This is intended for some specific generic widgets that has an underlying runtime version
     * that needs to be displayed or logged.
     * The function will only be called for applicable widgets.
     */
    abstract getRuntimeVersion?: () => string;
    static ɵfac: i0.ɵɵFactoryDeclaration<IWidgetInstance, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<IWidgetInstance>;
}
/**
 * Represents a widget instance.
 *
 * An object of this type should be returned by the widgetFactory function in the widget module.
 * Most properties in this interface are optional so it is OK to return an empty object for jQuery widgets
 * but the angularConfig is required for Angular widgets.
 *
 * A widget implementation may choose which properties to set depending on what types of callbacks the widget requires.
 *
 * @since 1.0.17
 */
interface IWidgetInstance2 extends IWidgetInstance {
}
/**
 * Represent event arguments for the restored event function defined in [[IWidgetInstance]].
 * Needs to be implemented if title is set via setTitle by the widget itself.
 *
 * This event is called after the framework has updated the settings.
 *
 * @since 1.0.12
 */
interface IWidgetRestoreArg {
    /**
     * Remove any user settings from a published widget and restore the widget to the configuration it
     * has when it is first added from the catalog.
     */
    userSettings?: boolean;
    /**
     * Remove any configuration and restore to the default values from the standard widget.
     */
    settings?: boolean;
}
/**
 * Represent event arguments for the refreshed event function defined in [[IWidgetInstance]].
 *
 * @since 1.0.21
 */
interface IWidgetRefreshArg {
    /**
     * Gets the time when the last refresh event occurred expressed in milliseconds since the epoch (new Date().getTime()).
     * The value will be zero for the first refresh.
     */
    lastRefresh: number;
}
/**
 * Represent options for the settingsOpening and settingsSaved event functions defined in [[IWidgetInstance]].
 *
 * @since 1.0
 */
interface IWidgetSettingsArg {
    /**
     * Gets the widget settings.
     *
     * These are the same settings that are available on the [[IWidgetContext]].
     */
    settings: IWidgetSettings;
    /**
     * Gets an optional data parameter.
     *
     * This property will only be available if the settings were opened using
     * the showSettings function on the [[IWidgetContext]] and a data parameter was set on the [[IShowSettingsOptions]].
     */
    data?: any;
    /**
     * Gets a value that indicates that the standard settings dialog should be cancelled.
     *
     * The default value is false.
     *
     * This property can be set to true by widgets that have a completely custom settings UI including dialog management.
     */
    cancel?: boolean;
}
/**
 * Represents metadata for a widget setting.
 *
 * @since 1.0
 */
interface IWidgetSettingMetadata {
    /**
     * Gets or sets the name of the setting.
     */
    name: string;
    /**
     * Gets or sets the settings value type defined in [[WidgetSettingsType]].
     */
    type?: string;
    /**
     * Gets or sets the default value for the setting if not changed.
     */
    defaultValue?: string;
    /**
     * Gets or sets the ID of a label to translate.
     * If no translation is found the text will be used. Label for settings UI.
     */
    labelId?: string;
    /**
     * Gets or sets a value that indicates if the setting should be visible in the widget settings UI.
     * The default value is true. The value of this property will not have any effect if the isHidden property
     * is set to true.
     */
    isVisible?: boolean;
    /**
     * Gets or sets a value that indicates if the setting is hidden. The default value is false.
     * A setting that is hidden will always be hidden and setting the isVisible property will not have any effect.
     * When a setting is hidden it will not be possible to configure the setting visibility when publishing a widget.
     */
    isHidden?: boolean;
    /**
     * Gets or sets a value that indicates if the setting is enabled. The default value is true.
     * A setting might be disabled for a published widget or a widget on a published page.
     * Settings will always be enabled on a private page.
     */
    isEnabled?: boolean;
    /**
     * Gets or sets the mode to use for an enabled setting. The default value is 0, which is the user setting mode.
     * The enabledMode property will only have an effect if the isEnabled property is set to true.
     *
     * 0 = User setting mode. The setting is enabled for end users on private or published workspaces / insights.
     * 1 = Admin setting mode. The setting is enabled for admin users when publishing a workspace / insight.
     */
    enabledMode?: number;
    /**
     * Gets or sets a value that indicates if the setting is enabled when publishing/published. The default value is true.
     *
     * @since 1.0.19
     */
    isEnabledWhenPublished?: boolean;
    /**
     * Gets or sets a value that indicates if the setting is mandatory. The default value is false.
     *
     * @since 1.0.21
     */
    isMandatory?: boolean;
    /**
     * Gets or sets a value that indicates if the setting is intended as an end user setting. The default value is false.
     *
     * This property can be used for non-critical settings that the end user should be allowed to change in
     * most cases. Examples of this could be the default sorting order or filter in a list.
     *
     * Setting this property to true will be a hint to the framework but what effect it actually has
     * depends on the context. There are always be ways to override this behavior, when publishing a widget
     * for example, so there is no guarantee that a user will be able to change a setting even if this property
     * is set to true.
     *
     * @since 2.0.5
     */
    isUser?: boolean;
    /**
     * Gets or sets the maximum length for string values.
     */
    maxLength?: number;
    /**
     * Gets or sets an array of values for a selector type setting.
     */
    values?: IValueItem[];
}
/**
 * Represents the different types of widget settings.
 * All except the object type are supported in the metadata settings UI.
 *
 * @since 1.0
 */
declare class WidgetSettingsType {
    static readonly stringType = "string";
    static readonly numberType = "number";
    static readonly booleanType = "boolean";
    static readonly selectorType = "selector";
    static readonly radioType = "radio";
    static readonly objectType = "object";
}
/**
 * An entity optimized for usage with the autocomplete control.
 * @since 1.0
 */
interface IAutocompleteEntity {
    /**
     * The visible text.
     */
    label: string;
    /**
     * An optional value of the item.
     */
    value?: any;
    /**
     * An optional secondary string.
     */
    info?: string;
    /**
     * Additional optional property to separate different types.
     */
    type?: any;
}
/**
 * Represents an item for a selector setting.
 *
 * @since 1.0
 */
interface IValueItem {
    /**
     * Gets or sets a language constant ID for the item text.
     *
     * Use this property or the text property, not both.
     */
    textId?: string;
    /**
     * Gets or sets the item text.
     *
     * Use this property or the textId property, not both.
     */
    text?: string;
    /**
     * Gets or sets the value.
     */
    value: string;
}
/**
 * Represents options for a widget settings dialog.
 *
 * @since 1.0
 */
interface IShowSettingsOptions {
    /**
     * Gets or sets an optional data object.
     */
    data?: any;
}
/**
 * Represents options for getting an application view URL.
 *
 * @since 1.0
 */
interface IViewUrlOptions {
    /**
     * Gets or sets the view ID.
     */
    viewId: string;
    /**
     * Gets or sets an optional application logical ID or logical ID prefix.
     *
     * If no value is specified the default application is used.
     */
    logicalId?: string;
    /**
     * Gets or sets a value that indicates if the URL template should be resolved by replacing values.
     *
     * The default value is true.
     * This property can be set to false to get the original URL template without replacing values.
     */
    resolve?: boolean;
}
interface IIntervalOptions {
    /**
     * Period, in milliseconds
     *
     * NOTE: Setting a number under 1000 (1 second) will throw an error.
     */
    period: number;
}
/**
 * Defines ION API constants.
 *
 * @since 1.0.17
 */
declare class IonApiConstants {
    /**
     * Gets the name of the header used to specify the platform that is calling ION API.
     * The header value should always be "homepages", specified in the platformHeaderValue property.
     */
    static readonly platformHeaderName = "x-infor-ionapi-platform";
    /**
     * Gets the ION API platform header value to use in Homepages.
     */
    static readonly platformHeaderValue = "infor.osportal";
    /**
     * Gets the name of the header used to specify the source that is calling ION API.
     * The value should be the standard widget ID of the calling widget.
     */
    static readonly sourceHeaderName = "x-infor-ionapi-source";
}
/**
 * Represents options used when getting an IonApiContext.
 *
 * @since 1.0
 */
interface IIonApiOptions {
    /**
     * @deprecated The refresh property is deprecated since ION API token refresh is now handled automatically
     * based on the token expiry time. Setting this property will not have any effect.
     */
    refresh?: boolean;
}
/**
 * Represents options when executing an ION API HTTP request.
 *
 * Note that the url property should be set to a relative URL (absolute URLs are not supported).
 * The ION API base URL will be automatically prepended to the url property to create an absolute URL before
 * the request is executed.
 *
 * The OAuth authorization header will also be automatically added to the headers map.
 */
interface IIonApiRequestOptions {
    /**
     * Gets or sets the HTTP method ('GET', 'POST', etc).
     */
    method: string;
    /**
     * Gets or sets the absolute or relative URL of the resource that is being requested.
     */
    url: string;
    /**
     * Gets or sets a map of strings which will be turned to ?key1=value1&key2=value2 after the url.
     */
    params?: any;
    /**
     * Gets or sets the data to be sent as the request message data {string|Object}.
     */
    data?: any;
    /**
     * Gets or sets the response type ('arraybuffer'|'blob'|'json'|'text').
     */
    responseType?: string;
    /**
     * Gets or sets optional HTTP headers.
     */
    headers?: {
        [requestType: string]: any;
    };
    /**
     * If caching is enabled.
     */
    cache?: boolean;
    /**
     * Gets or sets an optional value that indicates if a request should be retried if the ION API returns
     * a 401 HTTP response code.
     *
     * A 401 response code usually means that the OAuth token has expired and must be renewed. A 401 response code
     * could also mean that the user cannot be authorized at all.
     *
     * The default value is true.
     */
    ionApiRetry?: boolean;
    /**
     * Gets or sets a value that indicates if the request should be executed using a web worker.
     * The default value is false.
     *
     * @since  1.0.23
     */
    enableWorker?: boolean;
    /**
     * Gets or sets a value that indicates if the base URL should automatically have tenant added to the URL.
     * Only enable for calls to ION API metadata service where the context root should not be the tenant ID as
     * the tenant ID is included later in the URL. For all standard ION API calls this property should be false.
     * The default value is false.
     * @since  nextVersion
     */
    enableNonTenantUrl?: boolean;
}
/**
 * Represents the response from an ION API HTTP request.
 *
 * @since 1.0.17
 */
interface IIonApiResponse<T> {
    data: T;
    status: number;
    statusText: string;
}
/**
 * Represents the ION API context which contains values required when making ION API HTTP requests.
 *
 * To call an ION API a client must construct an absolute URL using the ION API base URL returned by
 * the getUrl function. Each HTTP request to an ION API must include an authorization header with
 * an OAuth 2.0 bearer token. The authorization header name and value can be retrieved using the
 * getHeaderName and getHeaderValue functions. It is also possible to get just the OAuth token using
 * the getToken function.
 *
 * Refer to the documentation for the API used to make HTTP calls for information about how to add
 * a header to a request.
 *
 * Authorization header example: "Authorization: Bearer yg06wrbaBoutluM8Rdb9v4YH0ztx"
 *
 * @since 1.0
 */
interface IIonApiContext {
    /**
     * Gets the ION API base URL.
     * @return a URL
     */
    getUrl(): string;
    /**
     * Gets an OAUth token.
     *
     * The OAuth token must be provided in an Authorization header for each ION API call.
     * @return an OAuth token
     */
    getToken(): string;
    /**
     * Gets the name of the HTTP Authorization header (Authorization).
     * @return the authorization header name
     */
    getHeaderName(): string;
    /**
     * Gets the value for the HTTP authorization header including the OAuth token.
     *
     * The returned value is an Authorization Request Header Field for an OAuth 2.0 Bearer Token
     * according to https://tools.ietf.org/html/rfc6750#section-2.1
     *
     * Example return value: "Bearer yg06wrbaBoutluM8Rdb9v4YH0ztx"
     *
     * @return the authorization header value
     */
    getHeaderValue(): string;
    /**
     * Gets the ION API customer context.
     *
     * The ION API customer context must be used in the ION API URL for applications that are not Infor provisioned.
     * Applications that are provisioned in the cloud and is using the standard ION API suite name should not add
     * the customer context to the ION API URL. In most other cases such as on-premise and when using
     * a non-standard ION API suite name the customer context must be added to the ION API URL. There are a
     * few exceptions to this for Infor Tech products that are always Infor provisioned both in cloud and on-premise.
     *
     * The default value for the ION API customer context is "CustomerApi" but the value can be configured
     * so it cannot be hardcoded.
     *
     * Example (M3 application with standard API suite provisioned in cloud):
     * https://ionapiserver:54321/ACME_AX1/M3/
     *
     * Example (Application with custom API suite in cloud or on-premise):
     * https://ionapiserver:54321/ACME_AX1/CustomerApi/MyApp/
     *
     * @returns The ION API customer context
     *
     * @since 1.0.1
     */
    getCustomerContext(): string;
}
/**
 * Options for calling the ION API metadata service to check for ION API registrations for the product
 * that you are using. Not all endpoints will be returned but this options object can be used to check for
 * existence of a suite or product.
 * @since 2.4
 */
interface IIonApiInfoOptions {
    /**
     * The logical id prefix for a product. Will check for metadata based on the logicalId prefix.
     * Endpoint: ​/products​/{logicalIdPrefix}
     *
     * Example: infor.m3
     */
    productLogicalId?: string;
    /**
     * The suite context. This is the ION API context.
     * Endpoint: /apisuites/{suiteContext}
     *
     * Exaxmple: M3, Mingle
     */
    suiteContext?: string;
}
/**
 * Metadata result object for calling ION API Metadata APIs. It can represent a product but also a suite.
 * @since 2.4
 */
interface IIonApiInfo {
    /**
     * A list of products. If the list is empty there are no products.
     */
    ionApiProducts: IIonApiProduct[];
    /**
     * Indicates if there are products.
     */
    hasProducts: boolean;
    /**
     *  The type of suite or product, for example "INFORNONPROVISIONED" or "INFORPROVISIONED".
     */
    typeName?: string;
    /**
     * The error message that should be used when no product is found.
     * The string will be "ION API Configuration is required." in the user's language.
     * The message will only be returned when there are no products found.
     */
    configurationRequiredMessage?: string;
    /**
     * Error message potentially set by framework.
     */
    errorMessage?: string;
}
/**
 * Representation of metadata for a suite or product from ION API.
 * @since 2.4
 */
interface IIonApiProduct {
    /**
     * Logical Id prefix without lid://
     */
    logicalIdPrefix: string;
    /**
     * Description.
     */
    description: string;
    /**
     * Name
     */
    name: string;
    /**
     * The suite context for example M3 for the M3 suite
     */
    suiteContext: string;
    /**
     * The type of product or suite. For example "INFORPROVISIONED" or "INFORNONPORVISIONED".
     */
    typeName: string;
}
/**
 * Represents the parent workspace or insight.
 * @since 3.26.0
 */
interface IWidgetParentContext {
    /**
     * Gets a value that indicates if the widget is part of a published workspace or insight.
     *
     * @returns True if the parent workspace or insight is published.
     *
     * @since 3.26.0
     */
    isPublished(): boolean;
    /**
     * Gets a value that indicates if the parent workspace or insight is in the publishing edit mode.
     *
     * @returns True if the parent workspace or insight is in the publishing edit mode.
     *
     * @since 3.26.0
     */
    isPublishing(): boolean;
    id?: string;
    type?: number;
    subType?: number;
}
/**
 * Represents options for navigation.
 *
 * @see INavigation
 * @since 3.27.0
 */
interface INavigationOptions {
    /**
     * The title to set in the widget title bar.
     */
    title: string;
    /**
     * An optional state object that will be provided in the navigation event.
     */
    state?: any;
}
/**
 * Represents a widget navigation event.
 *
 * @see INavigation
 * @since 3.27.0
 */
interface INavigationEvent {
    /**
     * The direction of the navigation.
     */
    direction: "back" | "forward";
    /**
     * The cancel property can be set to true to cancel a navigation event.
     */
    cancel?: boolean;
    /**
     * An optional state object, if that was provided in the navigation options.
     */
    state?: any;
}
/**
 * Represents the navigation object that provides navigation functionality for a widget.
 *
 * A widget may support navigation from a list view to a detail view and back.
 * The navigation object is used to notify the framework when navigation occurs, and also to get events when the user
 * navigates back to the previous view by clicking the back button in the widget title bar.
 *
 * Navigation is currently limited to single level.
 *
 * @since 3.27.0
 */
interface INavigation {
    /**
     * An observable for navigation events.
     * The observable will be triggered when the user clicks the back button in the widget title bar.
     */
    navigated$: Observable<INavigationEvent>;
    /**
     * Notifies the framework that the widget has navigated to a new view.
     * The framework will update the widget title bar with the new title, and show a back button.
     *
     * @param options The navigation options
     */
    navigate(options: INavigationOptions): any;
    /**
     * Navigates back to the previous view.
     * This method can be used if a widget needs to programmatically trigger the back button.
     * The effect is the same as if the user clicked the back button.
     * The method will have no effect if no navigation is active.
     */
    back(): void;
}
/**
 * Represents the user that is currently signed in to Portal.
 *
 * Only available in OS Portal.
 * @since 3.3.36, 2024.06
 */
interface IPortalUser {
    /**
     * The ID of the user.
     */
    userId: string;
    /**
     * The tenant that the user belongs to.
     */
    tenant: string;
    /**
     * The first name of the user.
     */
    firstName: string;
    /**
     * The last name of the user.
     */
    lastName: string;
    /**
     * The display name of the user, which usually consists of the first and last name.
     */
    displayName: string;
    /**
     * The e-mail address of the user.
     */
    email: string;
    /**
     * The active language.
     */
    language: string;
    /**
     * The active locale.
     */
    locale: string;
    /**
     * The active time zone.
     */
    timeZone: string;
    /**
     * The active time zone on the legacy format.
     */
    inforTimeZone: string;
    /**
     * The active theme.
     */
    theme: string;
    /**
     * The active theme color.
     */
    themeColor: string;
    /**
     * Whether the user is allowed to publish content.
     */
    isContentPublisher: boolean;
}
/**
 * Only available in OS Portal. Represents getting information and actions related to OS Portal functionality.
 *
 * The Portal Shell object in Homepages will exist and have a dummy implementation but the actions will not be
 * available.
 * Before accessing anything in this API the widget should check if running in OS Portal by checking "isPortal".
 *
 * @since 3.28.0
 */
interface IPortalShell {
    workspace: IWorkspaceShell;
    widgetShell: IWidgetShell;
    /**
     * Gets an object that represents the user that is currently signed in to Portal.
     *
     * @since 3.3.36, 2024.06
     */
    user: IPortalUser;
    /**
     * Gets a value that indicates if Portal is built from a development branch.
     * This property will only return true in Portal deployments that are built from a development branch.
     * This property will always return false in Portal release deployments or in the Widget SDK.
     *
     * @since 3.35.0, 2024.05
     */
    isDevelopmentBranch: boolean;
    /**
     * Deprecated. As of OS Portal 2025.10 (3.49.0) this method will remain but the observable will never fire.
     * This method will be removed completely.
     * Returns an observable of user settings for the specified application.
     * Note that the returned observable will emit new values whenever settings are updated.
     *
     * This method will unsubscribe automatically to application setting updates if the widget is destroyed.
     *
     * @since 3.28.0
     * @Deprecated
     * @param lidPrefix The lid prefix of the application.
     * @return An observable of user settings for the specified application.
     */
    getUserApplicationSetting<T>(lidPrefix: string): Observable<T>;
    /**
     * Gets a tenant setting from a limited set of tenant settings that are available to a widget.
     *
     * @param name The name of the tenant setting.
     * @return A setting value or null if the setting is not supported using this API.
     */
    getTenantSetting(name: string): string | null;
}
/**
 * Represents the widget context for the trusted domain setting.
 *
 * Only available in OS Portal.
 * @since 3.40.0, 2024.10
 */
interface IWidgetShell {
    trustedDomains: ITrustedDomains;
}
/**
 * Represents the trusted domain setting used to check the domain is trusted or not.
 *
 * Only available in OS Portal.
 * @since 3.40.0, 2024.10
 */
interface ITrustedDomains {
    /**
     * boolean property to check whether trusted domain is applicable to web widget
     *
     *  @since 3.40.0, 2024.10
     */
    isEnabled: boolean;
    /**
     * text property to show the information about the validstion applied for trusted domain
     *
     *  @since 3.40.0, 2024.10
     */
    informationText: string;
    /**
     * text property to show the validation message if the entered domain is not trusted
     *
     *  @since 3.40.0, 2024.10
     */
    validationErrorText: string;
    /**
     * Check the provided url's domain is trusted domain or not from the already exists set of
     * trusted domain
     *
     * @param url The provided url to validate
     * @return true or false by validation the entered url with existing trusted domains list.
     */
    isTrusted(url: string): boolean;
}
/**
 * Represents workspace related functionality and information in OS Portal.
 *
 * Only available in OS Portal.
 * @since 3.28.0
 */
interface IWorkspaceShell {
    /**
     * Gets the currently active workspace settings context.
     *
     * This property should only be used by a workspace settings widget that implements a workspace settings UI.
     * The settings context is also available using the workspaceSettings event on IWidgetInstance.
     *
     * @returns a workspace settings context or undefined
     * @since 3.40.0, 2024.10
     */
    settingsContext: IWorkspaceSettingsContext;
    /**
     * If the user is allowed to add private workspaces or to add workspaces from the catalog.
     * This does not mean that the user is currently allowed to add additional workspace as limits might be reached,
     * but if no limits are reached the user would be able to open the dialog to add / create a workspace.
     *
     * @since 3.28.0
     */
    isAddEnabled: boolean;
    /**
     * Shows the Add workspace dialog.
     * Before invoking showAdd the isAddEnabled has to be checked to verify that it's a valid option to open the dialog.
     *
     * If the user has reached the limit of workspaces an error message will be displayed.
     *
     * @since 3.28.0
     */
    showAdd(): void;
    /**
     * Checks if a workspace feature is enabled.
     *
     * @param name the name of the workspace feature to check
     * @returns true if the feature is defined and enabled or if the feature is not defined,
     * false if the feature is defined and not enabled
     *
     * @since 3.40.0, 2024.10
     */
    isFeatureEnabled(name: string): boolean;
}
/**
 * Represents the context for a widget in runtime.
 *
 * The context is received as a parameter to the widgetFactory function in the widget module.
 *
 * The context provides a widget instance with data, settings, the DOM element etc and
 * functions that can be used to interact with the framework.
 *
 * @since 1.0
 */
declare abstract class IWidgetContext {
    /**
     * Gets the parent context for the widget.
     *
     * @since 3.26.0
     */
    abstract getParentContext(): IWidgetParentContext;
    /**
     * Gets the navigation object.
     *
     * @returns The navigation object
     * @since 3.27.0
     */
    abstract getNavigation(): INavigation;
    /**
     * Gets a value that indicates if the widget is running in Portal.
     */
    abstract isPortal(): boolean;
    /**
     * Gets a value that indicates if the widget is running in Homepages.
     */
    abstract isHomepages(): boolean;
    /**
     * Gets the widget ID.
     *
     * This ID will be a either a standard widget ID or a published widget ID for a published widget.
     */
    abstract getId(): string;
    /**
     * Gets the widget settings.
     *
     * If the widget defines settings in the widget manifest the settings will contain default values when
     * a widget is added to a page. If a widget use ad-hoc settings or do not use settings at all the settings
     * object might be empty.
     */
    abstract getSettings(): IWidgetSettings;
    abstract getSettings<T>(): IWidgetSettings<T>;
    /**
     * Gets the widget language object for the current user language.
     * @return A language object.
     */
    abstract getLanguage(): ILanguage;
    abstract getLanguage<T extends ILanguage<T>>(): T;
    /**
     * Gets the widget DOM element wrapped in a JQuery object.
     *
     * A widget may add content to this element and for widgets not implemented using Angular
     * this is the only option for adding content.
     *
     * Note that a widget is only allowed to add content as children to this element.
     * A widget is not allowed to explicitly add elements to other parts of the DOM. The only exceptions
     * are when elements are added implicitly using modal dialogs, popups etc.
     *
     * Angular widgets that uses one of the template properties defined on the
     * angularContext property ([[IAngularWidgetConfig]]) in [[IWidgetInstance]] should ignore this property.
     * In this case the framework will add content to the element automatically.
     */
    abstract getElement(): JQuery<HTMLElement>;
    /**
     * Gets a URL to the widget folder or a resource in the widget directory.
     *
     * A widget must use an API such as this to get the URL to the widget directory since the widget directory location
     * is an implementation detail that might change in future versions.
     *
     * **Example:**
     * var iconUrl = widgetContext.getUrl("images/icon.png");
     * var baseUrl = widgetContext.getUrl();
     *
     * @param path An optional relative path that will be appended to the widget directory URL.
     * If this parameter is omitted or is blank the URL to the widget directory will be returned.
     * @returns A URL to the widget directory or a resource in the wiget directory.
     */
    abstract getUrl(path?: string): string;
    /**
     * Get the device, which should primarily be used to access native features of the mobile device that is
     * running the widget.
     * @since 1.0.32
     */
    abstract getDevice(): Observable<IDevice>;
    /**
     * Starts an interval similar to setInterval.
     * The interval will only be triggered while the widget is active,
     * and it will complete when the widget is destroyed.
     */
    abstract interval(options: IIntervalOptions): Observable<unknown>;
    /**
     * Gets a value that indicates if the widget is active.
     *
     * A widget is considered to be active if it is visible,
     * the settings dialog is not open and the widget is not in edit mode.
     *
     * @returns True if the widget is active.
     */
    abstract isActive(): boolean;
    /**
     * Gets a value that indicates if the widget is visible.
     *
     * A widget is considered to be visible if the widget is part of the current page / workspace / insight,
     * it is not hidden by contextual messages, and it is not in maintenance mode.
     *
     * @returns True if the widget is visible.
     */
    abstract isVisible(): boolean;
    /**
     * Gets a value that indicates if the widget is a published widget or if the widget is on a published page.
     *
     * @returns True if the widget is published.
     */
    abstract isPublished(): boolean;
    /**
     * Gets a value that indicates if the widget is running in the development environment.
     */
    abstract isDev(): boolean;
    /**
     * Get a value that indicates if the widget is running in the banner part of a page.
     */
    abstract isBanner(): boolean;
    /**
     * Get a value that indicates if the widget is running in the top bar / KPI ribbon.
     */
    abstract isTop(): boolean;
    /**
     * Notifies the framework that the widget data has been changed and that the widget needs to be saved.
     *
     * This function can be used to explicitly save widget data or settings, only if settings are enabled.
     * There is no need to call this function when the widget settings dialog is used since the framework saves
     * automatically in that case. This function should only be used if the widget modifies data or settings
     * that the framework is not aware of.
     *
     * The widget data is saved as part of the current page and this is asynchronous so there is
     * no guarantee exactly when the data is saved. There might be a delay and frequent calls to this function might
     * not result in the same number of server calls.
     */
    abstract save(): void;
    /**
     * Sets the widget state and options.
     *
     * See {@link WidgetState}
     * See {@link BusyStateOptions}
     * @param state The new widget state.
     * @param options The widget state options.
     */
    abstract setState(state: string, options?: BusyStateOptions): void;
    /**
     * Gets the current widget state.
     *
     * See [[WidgetState]]
     *
     * @returns A widget state.
     */
    abstract getState(): string;
    /**
     * Gets the current widget title.
     *
     * @returns A widget title.
     */
    abstract getTitle(): string;
    /**
     * Gets the standard widget title as defined in the widget manifest.
     *
     * @returns A widget title.
     */
    abstract getStandardTitle(): string;
    /**
     * Gets a resolved widget title for a locked or unlocked title.
     *
     * This function is intended for widgets with a custom settings UI that want to support
     * locked titles in the same way as the standard metadata settings UI. When the widget title
     * is locked is should revert back to a default title which can be retrieved by calling this function with true.
     *
     * @param isTitleLocked True if the widget is locked.
     * @returns A widget title.
     * @since 1.0.2
     */
    abstract getResolvedTitle(isTitleLocked: boolean): string;
    /**
     * Sets the widget title.
     *
     * This function will override the default title or a title set by the user and
     * should only be used by special widgets where the title is dependent on the configuration or
     * the current data for example. If the widget is configured to have the same title as in the widget catalog
     * calling this method will have no effect.
     *
     * @param title The title to set.
     */
    abstract setTitle(title: string): void;
    /**
     * Sets a subtitle that is displayed below the main title in the widget title bar.
     * A subtitle can be used in the main view of widget in some scenarios to display extra information.
     *
     * @param title The subtitle to set
     * @since 3.27.0
     */
    abstract setSubTitle(title: string): void;
    /**
     * Resets the widget title so it reverts to the widget standard title.
     *
     * This function will revert all changes to the title. Should only be used by widgets which uses
     * the setTitle method and needs to revert the title to the definition standard title. If the widget is configured
     * to have the same title as in the widget catalog calling this method will have no effect.
     */
    abstract setStandardTitle(): void;
    /**
     * Enables or disables the possibility for the user to edit the widget title.
     * @param isEnabled True to enable title editing, False to disable.
     */
    abstract enableTitleEdit(isEnabled: boolean): void;
    /**
     * Gets a value that indicates if the user is allowed to edit the widget title.
     * @return True if title editing is enabled.
     */
    abstract isTitleEditEnabled(): boolean;
    /**
     * Gets a value that indicates if the widget title is currently locked.
     *
     * The widget title can be locked explicitly by the user or implicitly if the widget catalog
     * title is used for a published widget. The isTitleUnlockable function can be used to check if
     * the widget title can be unlocked. The title can also be locked using the setTitleLocked function.
     *
     * @returns True if the widget title is locked.
     */
    abstract isTitleLocked(): boolean;
    /**
     * Gets a value that indicates if the widget title can be unlocked.
     *
     * The widget title may not be possible to unlock if the widget catalog title is used for a published widget.
     * There may also be other reasons in future versions for why the widget title cannot be unlocked.
     *
     * @returns True if the widget title can be unlocked.
     */
    abstract isTitleUnlockable(): boolean;
    /**
     * Sets a value that indicates if the widget title should be locked or not.
     *
     * Note that calls to this function may be ignored if the widget catalog title is used for a published widget.
     * If the isTitleUnlockable function returns false calling this function will not have any effect.
     *
     * @param isLocked True to lock the title, false to unlock.
     */
    abstract setTitleLocked(isLocked: boolean): void;
    /**
     * Resolves a key by searching for the key in the following order:
     *
     * <ul>
     * <li>Widget Settings</li>
     * <li>Ad-hoc properties</li>
     * <li>Application configuration in Ming.le.</li>
     * </ul>
     *
     * A key can contain any of the following reserved prefixes (followed by .) for accessing the key directly
     * intead of using the search order:  widget, property, application. For example application.hostname
     * to get the hostname from the application's configuration.
     *
     * The key is case-sensitive.
     *
     * Ad-hoc properties are defined by an administrator and can be useful if an installation has multiple links
     * to another on-premise system.
     *
     * This is only available if the widget has an application dependency defined in the Manifest
     * by specifying applicationLogicalId and applicationVersion.
     *
     * Note that for this to work with Ming.le configuration when using the Test Container, configuration data
     * needs to be provided by setting dev-configuration. See the developers guide or sample for more information.
     *
     * @param key is the name of the value that should be resolved. It might contain a prefix(e.g. application.xxxx)
     * @return The value for the key or null if no value is found.
     */
    abstract resolve(key: string): string;
    /**
     * Resolves a URL template with replacement variables in curly brackets.
     *
     * For example: http://{application.host}:{application.port}/root/{resource}?view={selectedView}
     *
     * By default all replacement variables will be encoded with the encodeURI function.
     *
     * It is possible to add extra information in the expression to specify the encoding method that should be used and
     * a default value if the value is null or empty.
     *
     * For example: {selectedView|encode:component}
     *
     * The encode takes three different options:
     * <ul>
     * <li>none - no encoding {selectedView|encode:none}</li>
     * <li>uri - encodeURI {selectedView|encode:uri}</li>
     * <li>component - encodeURIComponent {selectedView|encode:component}</li>
     * </ul>
     *
     * Another option is to specify a default value, for example: {selectedView|default:standard}. If the selectedView
     * cannot be resolved standard would be the fallback.
     *
     * Note that for this to work with Ming.le configuration when using the Test Container, configuration data
     * needs to be provided by setting dev-configuration. See the developers guide or sample for more information.
     *
     *
     * @param template A template with substitution variables. http://{external.server.test}/info/test/{selected}.
     * @return The resolved template with all substitution variables replaced (or removed if they can't be resolved).
     */
    abstract resolveAndReplace(template: string): string;
    /**
     * Gets the default application instance.
     *
     * If there are more than one instance of the application the one that is considered
     * to be default by the framework will be returned.
     *
     * Note that for this to work when using the Test Container, configuration data needs to be provided
     * by setting dev-configuration. See the developers guide or sample for more information.
     *
     * @returns The default application instance or null if the widget does not belong to an application.
     */
    abstract getApplication(): IApplication;
    /**
     * Gets an array with all application instances.
     *
     * If there is only a single application instance the result will be an array with one element.
     *
     * Note that for this to work when using the Test Container, configuration data needs to be provided
     * by setting dev-configuration.  See the developers guide or sample for more information.
     *
     * @returns An array of application instances or an empty array if the widgets does not belong to an application.
     */
    abstract getApplications(): IApplication[];
    /**
     * Gets the logical ID.
     * @returns The logical ID or null if the widget does not belong to an application.
     */
    abstract getLogicalId(): string;
    /**
     * Sets the logical ID. This function can be called by widgets that supports multiple application instances
     * to change the default application instance.
     *
     * Calling this function will only have an effect if the widget belongs to an application.
     *
     * @param logicalId The logical ID.
     */
    abstract setLogicalId(logicalId: string): void;
    /**
     * Gets the Ming.le application settings for a specified application.
     *
     * If a logical ID is specified it must match exactly with an existing application instance.
     * If a logical ID prefix is specified the default application instance will be returned.
     *
     * Note that for this to work when using the Test Container, configuration data needs to be provided
     * by setting dev-configuration. See the developers guide or sample for more information.
     *
     * @param logicalId The logical ID or logical ID prefix for the application to get.
     * @returns A promise that will be resolved when the application settings are available.
     */
    abstract getApplicationAsync(logicalId: string): Observable<IApplication>;
    /**
     * Gets the Ming.le application settings for all instances of the specified application.
     *
     * If a logical ID is specified it must match exactly with an existing application instance.
     * If a logical ID prefix is specified the default application instance will be returned.
     *
     * Note that all instances of an application will be returned even if the logical ID for
     * a specific instance is specified.
     *
     * Note that for this to work when using the Test Container, configuration data needs to be provided
     * by setting dev-configuration. See the developers guide or sample for more information.
     *
     * @param logicalId The logical ID or logical ID prefix for the application to get.
     * @returns A promise that will be resolved when the application settings are available.
     */
    abstract getApplicationsAsync(logicalId: string): Observable<IApplication[]>;
    /**
     * Resolves a URL template with replacement variables in curly brackets using values from a Ming.le application.
     *
     * If a logical ID is specified it must match exactly with an existing application instance.
     * If a logical ID prefix is not specified the default application instance will be used when resolving values.
     *
     * @param logicalId The logical ID prefix for the application to use when resolving values.
     * @returns A promise that will be resolved when the template has been resolved.
     */
    abstract resolveAndReplaceAsync(template: string, logicalId?: string): Observable<string>;
    /**
     * Gets an application view URL.
     *
     * The default behavior of this function is to get the view URL template for the current default application,
     * replace values in the template and return the URL. It is possible to specify another application and to
     * prevent variable replacement by using additional properties on the options object.
     *
     * @param options Used to specifiy the view to get and other options.
     * @returns A promise that will be resolved when the URL is available. The promise will be rejected
     * if the application or the view does not exist or if some other error occurs.
     */
    abstract getViewUrlAsync(options: IViewUrlOptions): Observable<string>;
    /**
     * Gets the ION API customer context.
     *
     * The ION API customer context must be used in the ION API URL for applications that are not Infor provisioned.
     * Applications that are provisioned in the cloud and is using the standard ION API suite name should not add
     * the customer context to the ION API URL.
     *
     * There are a few exceptions to this for Infor Tech products that are always Infor provisioned
     * both in cloud and on-premise.
     *
     * The default value for the ION API customer context is "CustomerApi" but the value can be configured
     * so it cannot be hardcoded.
     *
     * Example (M3 application with standard API suite provisioned in cloud):
     * https://ionapiserver:54321/ACME_AX1/M3/
     *
     *
     * Example (M3 application with custom API suite in cloud or on-premise):
     * https://ionapiserver:54321/ACME_AX1/CustomerApi/M3_CUSTOM/
     *
     * @returns The ION API customer context.
     */
    abstract getIonApiCustomerContext(): string;
    /**
     * Gets an ION API context required when making ION API HTTP requests.
     *
     * This function is asynchronous since a server request might be required to get the OAuth token for ION API.
     *
     * In most cases an ION API request can be executed using the executeIonApiAsync function that will automatically
     * get the ION API context and retry requests when the OAuth token has expired. This function can be used when more
     * control is required when making the request or when the executeIonApiAsync fuction cannot be used
     * for some other reason.
     *
     * The OAuth token has a limited lifetime and will become invalid once it has timed out.
     * The OAuth token might be invalid if an ION API HTTP request returns 401.
     * A client can get a new ION API context with a new OAuth token by setting the refresh property to true
     * on the options parameter.
     *
     * @param options Optional object for specifying options when getting the context.
     * @return A promise that will be resolved when the ION API context is available.
     */
    abstract getIonApiContextAsync(options?: IIonApiOptions): Observable<IIonApiContext>;
    /**
     * Executes ION Metadata APIs to read information about products and suites.
     * All previous data is cached by the framework. If a new suite has been registered in ION API
     * a restart would be required.
     *
     * If a product call returns HTTP400 the cause can be that the Suite does not exists in ION API.
     * For such scenarios this method can be used to check if there are products related to the suite or
     * logicalId prefix in ION API.
     *
     * If not then use the configurationRequiredMessage and display that as an widget inline error message.
     * @since 2.4
     */
    abstract getIonApiInfoAsync(options: IIonApiInfoOptions): Observable<IIonApiInfo>;
    /**
     * Executes an ION API HTTP request.
     *
     * This function will automatically get the IonApiContext which contains the OAuth token necessary
     * to complete the request.
     *
     * If the url parameter is relative (which it should be in most cases) the ION API base URL will be prepended
     * to the URL before the request is executed.
     *
     * If the ION API HTTP request returns a 401 response code this function will perform a single retry.
     * The retry attempt will get a fresh OAuth token and repeat the same request. If the second request completes
     * without errors it will be transparent to the caller. If the second request fails the promise will be rejected.
     *
     * If more control is required when making the request the getIonApiContextAsync function can be used to
     * get the OAuth token and ION API base URL. In this case the retry for expired OAuth tokens must be handled manually.
     *
     * @param options An object that describes the request.
     * @returns An observable that can be subscribed to.
     */
    abstract executeIonApiAsync<T>(options: IIonApiRequestOptions): Observable<IIonApiResponse<T>>;
    /**
     * Gets a framework service.
     *
     * This function can be used to get access to framework services implemented in Angular from a widget that
     * is not implemented in Angular. The function can be used from an Angular widget as well if the
     * normal dependency injection cannot be used for some reason.
     *
     * The available services are documented in the API documentation.
     * Note that a widget is only allowed to request services that are part of the public API documentation.
     * Any other services that might be accessible could be removed or refactored at any time without prior notice.
     *
     * @param name The type of the service to get.
     * @returns A service instance or null if the service could not be found.
     */
    abstract getService<T>(serviceType: new (...args: any[]) => T): T;
    /**
     * Launches a URL or a drillback link.
     *
     * This function can be used to launch a link in the browser or send a companyon message to open a drillback link.
     * The launchOptions will control if replacement variables should be resolved automatically or not.
     * Default is true and any curly brackets would result in that for example {lid://infor.m3} would be resolved
     * to the for the Homepages default instance id for m3, eg {lid://infor.m3.1}. This is for example used in
     * the custom menu widget as it makes widget link configuration portable for the default application wihtout
     * having to update logical ids.
     *
     * The link can contain replacement variables for specific applications as well using the syntax
     * with the logicalId prefix.
     * {lid://infor.homepages:Host}
     *
     * Any url that starts with a slash or http or https would be considered a standard web link and will be
     * handled by the browser opening a new window or tab. All other url will be handled by Ming.le companyon.
     *
     * Note that for this to work when using the Test Container, configuration data needs to be provided
     * by setting dev-configuration. See the developers guide or sample for more information.
     *
     * @param launchOptions The launch options.
     */
    abstract launch(launchOptions: ILaunchOptions): void;
    /**
     * Displays a dismissible inline message in the widget.
     */
    abstract showWidgetMessage(message: IWidgetMessage): void;
    /**
     * Sets the current widget status. For example this can be used to show an indicator in the widget title bar in
     * Context Application mode when the widget is collapsed. This is to indicate that the widget has current content.
     *
     * @since 2.5.0
     */
    abstract setWidgetStatus(status: IWidgetStatus): void;
    /**
     * Clears any existing widget status.
     *
     * @since 2.5.0
     */
    abstract clearWidgetStatus(): void;
    /**
     * Removes the inline message in the widget.
     */
    abstract removeWidgetMessage(): void;
    /**
     * Returns the pageId of the parent page or null if the widget does not have a parent context at this time.
     */
    abstract getPageId(): string;
    /**
     * Returns the ID if the widget is a standard widget or the standard widget id the widget is based on.
     */
    abstract getStandardWidgetId(): string;
    /**
     * Returns the runtime instance id for the widget.
     */
    abstract getWidgetInstanceId(): string;
    /**
     * Returns the container (top level) url in the form of schema://host, for example https://mingledev.infor.com if
     * Homepages is running withing Ming.le. This url should be used when implementing X-Frame-Options for widgets
     * that has IFrames. The replacement variable to use in templates is 'framework.containerurl'.
     * If Homepages is running standalone or in dev mode it will return the URL to the Hompages host.
     */
    abstract getContainerUrl(): string;
    /**
     * Gets a value that indicates if the Homepages server is running the cloud mode or on-premise mode.
     *
     * This function can be used by widgets that needs to have a different behavior in cloud mode compared to
     * on-premise mode. Please note that Single Tenant Cloud installations are running in on-premise mode.
     * isSingleTenantCloud has been added to check this, but it is a grid property that needs to
     * be set manually on those installations.
     *
     * @returns True if the server is running in cloud mode.
     */
    abstract isCloud(): boolean;
    /**
     * Gets a value that indicated if the Homepages server is running in Single Tenant Cloud mode. This is
     * an on-prem installation running in the cloud. This information is used by some widgets to differentiate
     * between on-prem in the cloud (eg. isCloud is false since that is true only for multitenant).
     * @returns True if the grid property Server.IsSingleTenantCloud is set to True.
     */
    abstract isSingleTenantCloud(): boolean;
    /**
     * Gets the tenant ID.
     * @returns the tenant ID
     */
    abstract getTenantId(): string;
    /**
     * Gets the user ID.
     * Be sure to never send this value to identify a user. It can only be used for non-priviliged scenarios.
     * @returns the user ID
     */
    abstract getUserId(): string;
    /**
     * Finds widgets that are part of the same page as the current widget.
     *
     * If no options are specified the function will find all widgets on the page except for the current widget.
     *
     * @param options Optional find options.
     * @returns An array of widgets or an empty array if no matching widgets can be found.
     */
    abstract findWidgetsOnPage(options?: IFindWidgetOptions): IWidgetInstanceInfo[];
    /**
     * Gets a value that indicates if one or more widgets exists on the same page as the current widget.
     *
     * @param options Options that defines which widget to find. At least one of the ID properties should be set.
     * @returns True if one or more widgets matching the options exists on the page.
     */
    abstract isWidgetOnPage(options: IFindWidgetOptions): boolean;
    /**
     * Gets the Infor time zone in raw format if available.
     * Example: (UTC-05:00)Eastern Time(US & Canada)
     *
     * This value can be also be resolved using the key "inforTimeZoneRaw".
     *
     * @returns time zone in raw format or null
     * @since 1.0.13
     */
    abstract getInforTimeZoneRaw(): string;
    /**
     * Gets the Infor time zone if available.
     * Example: UTC-05:00
     *
     * This value can be also be resolved using the key "inforTimeZone".
     *
     * @returns time zone or null
     * @since 1.0.13
     */
    abstract getInforTimeZone(): string;
    /**
     * Gets the standard Infor time zone if available.
     * Example: Europe/Berlin
     *
     * This value can be also be resolved using the key "inforStdTimeZone".
     *
     * @returns time zone or null
     * @since 1.0.34
     */
    abstract getInforStdTimeZone(): string;
    /**
     * Gets the Infor current language if available.
     *
     * This value can be also be resolved using the key "inforCurrentLanguage".
     *
     * @returns the Infor current language or null
     * @since 1.0.28
     */
    abstract getInforCurrentLanguage(): string;
    /**
     * Gets the Infor current locale if available.
     *
     * This value can be also be resolved using the key "inforCurrentLocale".
     *
     * @returns the Infor current locale or null
     * @since 1.0.28
     */
    abstract getInforCurrentLocale(): string;
    /**
     * Gets the Infor theme name if available.
     *
     * This value can be also be resolved using the key "inforThemeName".
     *
     * @returns the Infor theme name or null
     * @since 1.0.28
     */
    abstract getInforThemeName(): string;
    /**
     * Returns the current background color used for the banner widget(s) container.
     *
     * This method is useful for banner widget implementation only, for instance to
     * be able to apply specific styles that are coherent with the current background color
     *
     * Example: #0E5B52
     *
     * @returns Banner background color string or null if the widget does not have a parent context at this time
     */
    abstract getBannerBackgroundColor(): string;
    /**
     * Gets the value of a drillback/bookmark parameter.
     *
     * This method can be used if Homepages is opened via a drillback or bookmark, including one or
     * more parameters, that the widget needs to resolve value(s) for. Only string values can be resolved.
     *
     * Example drillback: ?LogicalId=lid://infor.homepages.1&param1=valuefromparameterone
     * Value for "param1" can be retrieved using this method
     *
     * @param parameter The name of the parameter.
     * @returns The value of the parameter, or null if no matching parameter is found.
     * @since 1.0.19
     */
    abstract getContextParameter(parameter: string): string;
    /**
     * Tells the framework that the widget's primary action needs to be reevaluated.
     *
     * This method can be used if the widget supports different primary actions, depending on e.g. state.
     * An example would be a widget that has one primary action that is only relevant when it is editable,
     * and a different action that should be primary if it is published.
     *
     * @since 1.0.23
     */
    abstract updatePrimaryAction(): void;
    /**
     * Gets the mode that the widget is executing in. The widget will start in one mode that cannot be
     * changed during the entire session.
     * @since 1.0.34
     */
    abstract getMode(): Mode;
    /**
     * Gets the sub mode that the widget is executing in. The widget will start in one sub mode
     * that cannot change during the entire session.
     * @since 1.0.34
     */
    abstract getSubMode(): SubMode;
    /**
     * Send Mingle companyon messages like Business Context messages or custom application message. This method is
     * a wrapper for infor.companyon.client. Never access infor.companyon.client directly.
     *
     * Note that messages will only be sent while the widget is active. If this method is called while the widget is
     * inactive, the last message of each type will be sent as soon as the widget is activated again.
     *
     * This method can be used for widget to widget communication. To communicate with widgets on the same page
     * the @see GetPageId() that returns the page id can be used as message type prefix.
     *
     * @since 1.0.34
     * @param name Message name
     * @param data Message data
     */
    abstract send(name: string, data: unknown): void;
    /**
     * Receive Mingle Companyon messages like Business Context messages or custom application messages that
     * are sent by applications or other widgets. Use this method instead of using infor.companyon.client directly.
     *
     * Note that messages will only be delivered when the widget is active. If messages arrive while the widget is
     * inactive, only the last one of each type will be delivered once the widget is activated again.
     *
     * This method will unsubscribe automatically to messages if the widget is destroyed.
     *
     * This method can be used for widget to widget communication. To communicate with widgets on the same page
     * the @see GetPageId() that returns the page id can be used as message type prefix.
     *
     * @since 1.0.34, 3.10.0
     * @param options a message type or message options
     * @returns A stream of messages
     */
    abstract receive(options: string | IMessageOptions): Observable<unknown>;
    /**
     * Receives Companyon messages.
     *
     * This method has the same functionality as the "receive" method, but provides the message object
     * with the type and data properties, instead of just the data object.
     * This can be used for wildcard (*) subscriptions or generic message handlers for example.
     *
     * @since 3.29.0, 2023.11
     *
     * @param options a message type or message options
     * @returns A stream of messages
     */
    abstract receiveMessage<T>(options: string | IMessageOptions): Observable<IMessage<T>>;
    /**
     * Gets environment information from the top level parent application.
     *
     * This is equivalent to calling infor.companyon.client.getEnvironmentInformation which should
     * never be done directly.
     *
     * @since 3.11.0
     * @returns An observable for the environment information
     */
    abstract getEnvironmentInformation(): Observable<EnvironmentInfoMap>;
    /**
     * Gets the URL of the top level parent application.
     *
     * This is equivalent to calling infor.companyon.client.getInforMingleHomeUrl which should
     * never be done directly.
     *
     * @since 3.11.0
     * @returns An observable for the top level parent URL
     */
    abstract getParentUrl(): Observable<string>;
    /**
     * Receive the current size of the widget. Any time the size of the widget changes due to an edited layout or
     * browser window resize, the observable will emit a new value. The size information can be used for
     * responsive style & functionality of the widget.
     *
     * This method will unsubscribe automatically to size updates if the widget is destroyed.
     *
     * @since 2.3.0
     * @returns An [[IWidgetSize]] Observable
     */
    abstract getSize(): Observable<IWidgetSize>;
    /**
     * Shows an IDS badge next to the title in the widget header, containing a number equal to or greater than 0.
     * Values greater than 1000 will be abbreviated by displaying the number in thousands followed by "k+".
     * For example, 1525 will be displayed as 1k+. Values greater than 10,000 will always be displayed as 10k+.
     *
     * @since 3.8.0
     * @param options The options for the badge, including the value (count) and color (type)
     */
    abstract showBadge(options: IBadgeOptions): void;
    /**
     * Removes the badge, shown by [[showBadge]], from the widget header.
     *
     * @since 3.8.0
     */
    abstract removeBadge(): void;
    /**
     * Sets an empty state message in the widget.
     *
     * @param options The options for the message.
     * @since 3.11.0
     */
    abstract setEmptyState(options: IEmptyStateOptions): void;
    /**
     * Clears the empty state message, shown by [[setEmptyState]].
     *
     * @since 3.11.0
     */
    abstract clearEmptyState(): void;
    /**
     * Tracks that an event (e.g a click) has happened.
     *
     * Used for analytics.
     * Note: This feature is not supported for tenant widgets.
     * @since 3.11.0
     */
    abstract trackEvent(options: ITrackEventOptions): void;
    /**
     * Tracks that a view is shown to the user.
     *
     * Note that this should only be called if the widget is visible on the page, and there is more than one "sub-view".
     * The widget itself is already tracked as a view, so this method should only be used for more detailed tracking.
     *
     * Used for analytics.
     *
     * Note: This feature is not supported for tenant widgets.
     * @since 3.18.0
     */
    abstract trackView(options: ITrackViewOptions): void;
    /**
     * Gets an object with Portal version numbers.
     *
     * @returns A version object.
     * @since nextVersion
     */
    abstract getVersionInfo(): IVersionInfo;
    /**
     * Portal V2 Spotlight widget API
     *
     * NOTE: This should not be used in normal Homepages widgets!
     *
     * @since 3.16.0
     * @deprecated Federated Search and the related Spotlight API is not available.
     */
    abstract getSpotlight(): ISpotlight;
    /**
     * Gets an object with different ways to interact with OS Portal.
     * Note that the Portal Shell is only available in OS Portal and widget must check isPortal() before accessing or
     * using any of the methods and properties on this object.
     */
    abstract getPortal(): IPortalShell;
    /**
     * Sets the type of border a widget should have.
     * This will override the default border from the widget manifest.
     *
     * "default" - Show the default widget border.
     * "none" - Don't show a widget border.
     *
     * @since 2024.03
     */
    abstract setBorder(border: "none" | "default"): void;
    /**
     * Sets the type of header a widget should have.
     * This will override the default header from the widget manifest.
     *
     * "default" - Show the default widget header.
     * "none" - Don't show the widget header.
     *
     * @since 2025.07
     */
    abstract setHeader(header: "none" | "default"): void;
    /**
     * Adds both custom and standard parameters to the URL and returns the updated URL.
     *
     * @param url
     *
     * @since 2024.12
     */
    abstract appendStandardParameters(url: string): string;
    /**
     * Receive the current collapsed state of the widget. Any time the collapsed state of the widget changes, the observable will emit a new value.
     * Note: Only applicable for widgets in the Smart Panel.
     *
     * @since 2025.10
     */
    abstract isCollapsed(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<IWidgetContext, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<IWidgetContext>;
}
interface IVersionInfo {
    /**
     * Gets the full Portal release version number.
     *
     * The version includes numbers for major, minor, release and build separated by dots.
     *
     * Example. 2020.01.00
     */
    version: string;
    /**
     * Gets the Portal release version number excluding the build number.
     *
     * The version includes numbers for major, minor, release separated by dots.
     *
     * Example. 2020.01
     */
    releaseVersion: string;
    /**
     * Gets the Portal display version number.
     *
     * The display version includes numbers for year and month separated by dots.
     *
     * Example: 2020.01.01
     */
    displayVersion: any;
    /**
     * Gets the Portal client framework version number.
     *
     * The framework version follows semantic versioning with numbers for major, minor and patch separated by dots.
     * This version can be used to check if a specific client API is available in the framework.
     *
     * Example: 3.10.0
     */
    frameworkVersion: string;
}
/**
 * Represents the context for a widget in runtime.
 *
 * The context is received as a parameter to the widgetFactory function in the widget module.
 *
 * The context provides a widget instance with data, settings, the DOM element etc and
 * functions that can be used to interact with the framework.
 *
 * @since 1.0.17
 */
interface IWidgetContext2 extends IWidgetContext {
}
/**
 * Represents a widget instance on a page.
 *
 * @since 1.0.11
 */
interface IWidgetInstanceInfo {
    /**
     * Gets the unique widget instance ID.
     *
     * This ID is generated when a widget is added to a page.
     */
    instanceId: string;
    /**
     * Gets the widget ID.
     *
     * This ID will be a either a standard widget ID or a published widget ID for a published widget.
     */
    id: string;
    /**
     * Gets the standard widget ID.
     *
     * For a standard widget this property will have the same value as the id property.
     */
    standardWidgetId: string;
    /**
     * Gets the title of the widget.
     */
    title: string;
}
/**
 * Options for finding widgets on a page.
 *
 * @since 1.0.11
 */
interface IFindWidgetOptions {
    /**
     * Gets or sets a value that indicates if the current widget instance should be included in the result.
     *
     * The default value is false.
     */
    includeSelf?: boolean;
    /**
     * Gets or sets a unique widget instance ID to search for.
     *
     * This ID is generated when a widget is added to a page.
     */
    instanceId?: string;
    /**
     * Gets or sets a widget ID to search for.
     *
     * This ID will be a either a standard widget ID or a published widget ID for a published widget.
     */
    id?: string;
    /**
     * Gets or sets a standard widget ID to search for.
     */
    standardWidgetId?: string;
}
/**
 * Launch options for the IWidgetContext launch method.
 *
 * @since 1.0
 */
interface ILaunchOptions {
    /**
     * An url starting with slash, http, https or a Ming.le drillback link.
     */
    url: string;
    /**
     * Indicates if values should be automatically resolved using application context information.
     * Either the link must start with a logicalId prefix or logicalId or the logical ID should be set on this function.
     *
     * An example of a URL that can be replaced to link to Ming.le posts is:
     * {lid://infor.social}{Scheme}://{Hostname}:{Port}/{TenantId}/webpart/posts
     *
     * The logicalIdPrefix in the beginning of the link determines that the default social application will be
     * used to resolve the other values. It is also possible to have values in the link that is from
     * the widget settings or ad-Hoc properties.
     *
     * Another example to open a M3 program would be:
     * {lid://infor.m3}?LogicalId={logicalId}&program=MMS001
     *
     */
    resolve?: boolean;
}
/**
 * If A is null, cast to B. Otherwise cast to C.
 */
type Nullable<A, B = any, C = A> = A extends null ? B : C;
/**
 * Represents the widget settings.
 *
 * Note that all settings values must be possible to serialize to JSON.
 *
 * @since 1.0
 */
interface IWidgetSettings<T = null> {
    /**
     * Gets the settings value object.
     *
     * This object can be used directly instead of using the get/set functions if necessary.
     *
     * @returns The settings value object.
     */
    getValues(): Nullable<T>;
    /**
     * Sets the settings value object.
     *
     * Note that calling this function will overwrite all existing setting values.
     *
     * @param values The settings value object.
     */
    setValues(values: Nullable<T>): void;
    /**
     * Gets the settings metadata.
     * @returns An array of metadata for each setting.
     */
    getMetadata(): IWidgetSettingMetadata[];
    /**
     * Sets the settings metadata
     *
     * Note that calling this function will overwrite all existing settings metadata.
     *
     * @param metadata An array of metadata for each setting.
     */
    setMetadata(metadata: IWidgetSettingMetadata[]): any;
    /**
     * Gets a property.
     *
     * @param name The name of the property. Must be a valid property name of T.
     * @param defaultValue Optional default value to return if the property is missing.
     * @returns The property value or the default value.
     */
    get<V extends NonNullable<T>, N extends keyof V & string>(name: N, defaultValue?: V[N]): V[N];
    /**
     * Gets a property of type RT.
     *
     * @param name The name of the property.
     * @param defaultValue Optional default value to return if the property is missing.
     * @returns The property value or the default value.
     */
    get<RT>(name: Nullable<T, string, never>, defaultValue?: RT): RT;
    /**
     * Sets a settings value.
     *
     * Note that the value must be possible to serialize to JSON.
     *
     * @param name The name of the setting.
     * @param value The setting value.
     */
    set<N extends keyof Nullable<T>>(name: Nullable<T, string, N>, value: Nullable<T>[N]): void;
    /**
     * Gets a string property.
     *
     * If the property value is not a string it will be converted to a string by this function.
     *
     * @param name The name of the property.
     * @param defaultValue Optional default value to return if the property is missing.
     * @returns The property value or the default value.
     */
    getString<N extends keyof Nullable<T>>(name: Nullable<T, string, N>, defaultValue?: string): string;
    /**
     * Shows the widget settings dialog.
     *
     * This function can be used to manually show the widget settings dialog.
     * The widget settings can be opened from the widget title bar menu but some widgets may
     * have some additional UI element that should also open the widget settings.
     *
     * @param options Optional settings options.
     */
    showSettings(options?: IShowSettingsOptions): void;
    /**
     * Gets a value that indicates if settings are currently enabled.
     * The value depends on the following factors: if settings are enabled in the definition,
     * if settings are enabled for a published widget,
     * if the widget is in a published / edit published state in the client.
     * This means that the value might change over time when working with a published widget.
     * @return True if settings are enabled.
     */
    isSettingsEnabled(): boolean;
    /**
     * Gets a value that indicates if the specified setting is enabled.
     *
     * A setting might be disabled for a published widget.
     * A widget implementation with custom settings management should check if a setting is enabled or not.
     *
     * @param name The name of the setting
     * @return True if the setting is enabled or if the setting is not recognized.
     * False if the setting is disabled or if all settings are disabled.
     */
    isSettingEnabled<N extends keyof Nullable<T>>(name: Nullable<T, string, N>): boolean;
    /**
     * Gets a value that indicates if the specified setting should be visible to the end user.
     *
     * A setting might be hidden for a published widget.
     * A widget implementation with custom settings management should check if a setting is hidden or not.
     *
     * @param name The name of the setting
     * @return  True if the setting is visible or if the setting is not recognized. False if the setting is hidden.
     */
    isSettingVisible<N extends keyof Nullable<T>>(name: Nullable<T, string, N>): boolean;
    /**
     * Sets if the Configure (Settings Menu) should be visible or not. Default is true if the widget has defined settings.
     * Intended for widgets that want to use the settings framework but not the standard Configure menu
     * that opens the settings dialog.
     * @param enabled If configure menu should be visible.
     */
    enableSettingsMenu(enabled: boolean): void;
    /**
     * @since 1.0.21
     */
    hasMandatory(): boolean;
    /**
     * @since 1.0.21
     */
    isMandatory<N extends keyof Nullable<T>>(name: Nullable<T, string, N>): boolean;
}
/**
 * Represents a custom widget settings instance.
 *
 * An object of this type should be set in IWidgetSettings object when settingsOpenings is called.
 *
 * A widget implementation may choose which properties to set depending on what types of callbacks the widget requires.
 *
 * @since 1.0
 */
declare abstract class IWidgetSettingsInstance {
    /**
     * Gets or sets an optional event function that will be called when the Settings dialog is closing.
     */
    abstract closing?: (arg: IWidgetSettingsCloseArg) => void;
    /**
     * Gets or sets an optional angular configuration for widgets implementing the settings UI with an Angular component.
     */
    abstract angularConfig?: IAngularWidgetConfig;
    /**
     * Gets or sets an optional web component configuration for widgets implementing the settings UI with a web component.
     *
     * @since 3.33.0
     */
    abstract webComponentConfig?: IWebComponentWidgetConfig<IWidgetSettingsComponent>;
    static ɵfac: i0.ɵɵFactoryDeclaration<IWidgetSettingsInstance, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<IWidgetSettingsInstance>;
}
/**
 * Represents a custom widget settings instance.
 *
 * An object of this type should be set in IWidgetSettings object when settingsOpenings is called.
 *
 * A widget implementation may choose which properties to set depending on what types of callbacks the widget requires.
 *
 * @since 1.0.17
 */
interface IWidgetSettingsInstance2 extends IWidgetSettingsInstance {
}
/**
 * Represents the context for a custom settings UI implementation.
 *
 * @since 1.0
 */
declare abstract class IWidgetSettingsContext {
    /**
     * Gets the widget context.
     *
     * @returns The widget context.
     */
    abstract getWidgetContext(): IWidgetContext;
    /**
     * Enables or disables save in the settings dialog.
     *
     * @param isEnabled A value that indicates if save should be enabled.
     */
    abstract enableSave(isEnabled: boolean): void;
    /**
     * Gets a value that indicates if save is enabled in the settings dialog.
     * @retruns True if save is enabled.
     */
    abstract isSaveEnabled(): boolean;
    /**
     * Gets the widget settings DOM element wrapped in a JQuery object.
     *
     * A widget may add settings UI content to this element and for widgets not implemented using AngularJS
     * this is the only option for adding custom settings content.
     *
     * Note that a widget is only allowed to add content as children to this element.
     * A widget is not allowed to explicitly add elements to other parts of the DOM. The only exceptions
     * are when elements are added implicitly using modal dialogs, popups etc.
     *
     * AngularJS widgets may add compiled content to this element.
     * The angularContext property contains the the scope and the compile service required for
     * compiling AngularJS elements.
     *
     * AngularJS widgets that uses one of the template properties defined on
     * the angularConfig property ([[IAngularWidgetConfig]]) in [[IWidgetSettingsInstance]] should ignore this property.
     * In this case the framework will add content to the element automatically.
     *
     * @returns The parent jQuery element.
     */
    abstract getElement(): JQuery<HTMLElement>;
    /**
     * Closes the settings dialog.
     * @param isSave A value that indicates if the settings should be saved or not.
     * The default value is false. See [[IWidgetSettingsCloseArg]].
     */
    abstract close(isSave?: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<IWidgetSettingsContext, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<IWidgetSettingsContext>;
}
/**
 * Represents the context for a custom settings UI implementation.
 *
 * @since 1.0.17
 */
interface IWidgetSettingsContext2 extends IWidgetSettingsContext {
}
/**
 * Defines widget constants.
 *
 * @since 1.0
 */
declare class WidgetConstants {
    static readonly widgetInstanceKey = "lmWidgetInstance";
    static readonly widgetContextKey = "lmWidgetContext";
    static readonly widgetTitle = "widgetTitle";
    static readonly widgetDescription = "widgetDescription";
}
/**
 * Represents a widget implemented as an Angular component.
 *
 * The widget should implement the properties in this interface as component inputs, @Input().
 * The framework will set the properties when the component is created so that they are
 * available in the ngAfterViewInit function.
 *
 * @since 1.0.17
 */
interface IWidgetComponent {
    /**
     * Gets or sets the widget context.
     */
    widgetContext: IWidgetContext;
    /**
     * Gets or sets the widget instance.
     */
    widgetInstance: IWidgetInstance;
}
/**
 *
 * @since 1.0.17
 */
interface IWidgetSettingsComponent {
    widgetSettingsContext: IWidgetSettingsContext;
    widgetSettingsInstance: IWidgetSettingsInstance;
}
/**
 * The Device provides access to native functions on a mobile device when the widget is running in InforGO.
 *
 * @since 1.0.32
 */
interface IDevice {
    /**
     *
     * Get current geographic location of the device.
     * @param options
     * @since 1.0.32
     */
    getLocation(options?: IGetLocationOptions): Observable<IGetLocationResult>;
    /**
     *
     * Get an image from the device camera or photo library.
     * @param options
     * @since 1.0.32
     */
    getImage(options?: IGetImageOptions): Observable<IGetImageResult>;
    /**
     *
     * Get a video from the device camera or photo library.
     * @param options
     * @since 1.0.32
     */
    getVideo(options?: IGetVideoOptions): Observable<IGetVideoResult>;
    /**
     *
     * Get an audio clip from the device.
     * @param options
     * @since 1.0.32
     */
    getAudio(options?: IGetAudioOptions): Observable<IGetAudioResult>;
    /**
     *
     * Get motion sensor data from the device.
     * @param options
     * @since 1.0.32
     */
    getSensors(options?: IGetSensorsOptions): Observable<IGetSensorsResult>;
    /**
     *
     * Get connectivity status of the device.
     * @param options
     * @since 1.0.32
     */
    getNetwork(options?: IGetNetworkOptions): Observable<IGetNetworkResult>;
    /**
     *
     * Read a QR code from the device camera or photo library.
     * @param options
     * @since 1.0.32
     * @deprecated use readBarcode() instead
     */
    readQRCode(options?: IReadQRCodeOptions): Observable<IReadQRCodeResult>;
    /**
     *
     * Read a 1D or 2D barcode from the device camera or photo library.
     *
     * Has been tested to work with the following barcodes:
     *
     * - UPC-E
     * - Code 39
     * - Code 39 mod
     * - EAN-13
     * - EAN-8
     * - Code 93
     * - Code 128
     * - PDF417
     * - QR Codes
     * - Aztec
     * - Interleaved
     * - ITF14
     * - DataMatrix
     *
     * @param options
     * @since 1.0.47
     */
    readBarcode(options?: IReadBarCodeOptions): Observable<IReadBarcodeResult>;
    /**
     *
     * Open the native application for Maps.
     * @param options
     * @since 1.0.32
     */
    showMap(options?: IShowMapOptions): Observable<IShowMapResult>;
    /**
     *
     * Open a link to an external web site.
     * @param options
     * @since 1.0.32
     */
    openExternalLink(options: IOpenLinkOptions): Observable<IOpenLinkResult>;
    /**
     * Open a document.
     * @param options
     * @since 1.0.45
     */
    openDocument(options: IOpenDocumentOptions): Observable<IOpenDocumentResult>;
}
/**
 * Request options with this interface are intended for resources that can send continuous updates of data.
 * @since 1.0.32
 */
interface IWatchOption {
    /**
     * Request continous updates of data, rather than a single request-response.
     * @since 1.0.32
     */
    watch?: boolean;
}
/**
 * Response from [[IDevice.getLocation]].
 * @since 1.0.32
 */
interface IGetLocationResult {
    /**
     * Latitude coordinate
     * @since 1.0.32
     */
    readonly latitude: number;
    /**
     * Longitude coordinate
     * @since 1.0.32
     */
    readonly longitude: number;
}
/**
 * Generic interface for [[IDevice]] responses with base64-encoded media.
 * @since 1.0.32
 */
interface IGetMediaResult {
    /**
     * Base64-encoded media data
     * @since 1.0.32
     */
    readonly data: string;
}
/**
 * Response from [[IDevice.getImage]].
 * @since 1.0.32
 */
interface IGetImageResult extends IGetMediaResult {
}
/**
 * Response from [[IDevice.getVideo]].
 * @since 1.0.32
 */
interface IGetVideoResult extends IGetMediaResult {
}
/**
 * Response from [[IDevice.getAudio]].
 * @since 1.0.32
 */
interface IGetAudioResult extends IGetMediaResult {
}
/**
 * Request option for [[IDevice.getLocation]].
 * @since 1.0.32
 */
interface IGetLocationOptions extends IWatchOption {
}
/**
 * This type describes the different media sources for [[IDevice]] requests.
 * @since 1.0.32
 */
type IMediaSource = "camera" | "library" | "all";
/**
 * Request option for [[IDevice.getImage]].
 * @since 1.0.32
 */
interface IGetImageOptions {
    /**
     * Set the source of the image.
     * @since 1.0.32
     */
    source: IMediaSource;
}
/**
 * Request option for [[IDevice.getVideo]].
 * @since 1.0.32
 */
interface IGetVideoOptions {
    /**
     * Set the source of the video.
     * @since 1.0.32
     */
    source: IMediaSource;
}
/**
 * Request option for [[IDevice.getAudio]].
 * @since 1.0.32
 */
interface IGetAudioOptions {
}
/**
 * Geographic coordinates [[IDevice.getLocation]] requests.
 * @since 1.0.32
 */
interface IMapCoordinates {
    /**
     * Longitude coordinate.
     * @since 1.0.32
     */
    longitude: number;
    /**
     * Latitude coordinate.
     * @since 1.0.32
     */
    latitude: number;
}
/**
 * Map marker for [[IDevice.showMap]] requests.
 * @since 1.0.32
 */
interface IMarker {
    /**
     * Coordinates for the marker.
     * @since 1.0.32
     */
    coordinates: IMapCoordinates;
    /**
     * The label of the marker.
     * @since 1.0.32
     */
    label: string;
}
/**
 * Request option for [[IDevice.showMap]] used to open navigation in the native Maps application.
 * @since 1.0.32
 */
interface IMapNavigationOptions {
    mapType: "navigation";
    /**
     * The starting coordinates for navigation.
     * @since 1.0.32
     */
    start?: IMapCoordinates;
    /**
     * The destination coordinates for navigation.
     * @since 1.0.32
     */
    destination: IMapCoordinates;
}
/**
 * Request option for [[IDevice.showMap]] used to open the native Maps application with markers.
 * @since 1.0.32
 */
interface IMapMarkerOptions {
    mapType: "marker";
    /**
     * Markers to be displayed on the map.
     * @since 1.0.32
     */
    markers: IMarker[];
}
/**
 * Request option for [[IDevice.showMap]] used to open the native Maps application, centered at a specific location.
 * @since 1.0.32
 */
interface IMapLocationOptions {
    mapType: "location";
    /**
     * Coordinates to where the map should be centered.
     * @since 1.0.32
     */
    coordinates: IMapCoordinates;
}
/**
 * Request option for [[IDevice.showMap]].
 * @since 1.0.32
 */
type IShowMapOptions = IMapNavigationOptions | IMapMarkerOptions | IMapLocationOptions;
/**
 * Response from [[IDevice.showMap]].
 * @since 1.0.32
 */
interface IShowMapResult {
}
/**
 * Request options for [[IDevice.readQRCode]].
 * @since 1.0.32
 * @deprecated use IReadBarcodeOptions instead
 */
interface IReadQRCodeOptions {
}
/**
 * Request options for [[IDevice.readQRCode]].
 * @since 1.0.32
 */
interface IReadBarCodeOptions extends IReadQRCodeOptions {
}
/**
 * Request options for [[IDevice.getNetwork]].
 * @since 1.0.32
 */
interface IGetNetworkOptions extends IWatchOption {
}
/**
 * Network connection type.
 * @since 1.0.32
 */
type NetworkConnectionType = "unknown" | "wifi" | "mobile";
/**
 * Network connection state.
 * @since 1.0.32
 */
type NetworkConnectionState = "online" | "offline";
/**
 * Response from [[IDevice.getNetwork]].
 * @since 1.0.32
 */
interface IGetNetworkResult {
    /**
     * Network connection state
     * @since 1.0.32
     */
    readonly connectionState: NetworkConnectionState;
    /**
     * Network connection type
     * @since 1.0.32
     */
    readonly connectionType: NetworkConnectionType;
}
interface IGetSensorsOptions extends IWatchOption {
}
/**
 * Acceleration data for [[IDevice.getSensors]] responses.
 * @since 1.0.36
 */
interface IAccelerationData {
    x: number;
    y: number;
    z: number;
}
/**
 * Gyroscope data for [[IDevice.getSensors]] responses.
 * @since 1.0.36
 */
interface IGyroscopeData {
    x: number;
    y: number;
    z: number;
}
/**
 * Response from [[IDevice.getSensors]].
 * @since 1.0.32
 */
interface IGetSensorsResult {
    /**
     * Accelerometer data
     * @since 1.0.32
     */
    readonly acceleration: IAccelerationData;
    /**
     * Gyroscope data
     * @since 1.0.32
     */
    readonly gyroscope: IGyroscopeData;
}
/**
 * Response from [[IDevice.readQRCode]].
 * @since 1.0.32
 * @deprecated use IReadBarcodeResult instead
 */
interface IReadQRCodeResult {
    /**
     * Decoded textual value of the QR Code
     * @since 1.0.32
     */
    readonly text: string;
}
/**
 * Response from [[IDevice.readBarcode]].
 * @since 1.0.47
 */
interface IReadBarcodeResult extends IReadQRCodeResult {
    /**
     * Decoded textual value of the barcode
     * @since 1.0.47
     */
    readonly text: string;
}
/**
 * Request options for [[IDevice.openExternalLink]]
 * @since 1.0.32
 */
interface IOpenLinkOptions {
    /**
     * URL to an external site or application
     * @since 1.0.32
     */
    url: string;
}
/**
 * Response from [[IDevice.openExternalLink]]
 * @since 1.0.32
 */
interface IOpenLinkResult {
}
/**
 * Request options for [[IDevice.openDocument]]
 * @since 1.0.45
 */
interface IOpenDocumentOptions {
    /**
     * MIME Type of the document, e.g "application/pdf"
     * @since 1.0.45
     */
    type: string;
    /**
     * Name of the document, e.g "test.pdf"
     * @since 1.0.45
     */
    name: string;
    /**
     * Base64-encoded document data
     * @since 1.0.45
     */
    data: string;
}
/**
 * Response from [[IDevice.openDocument]]
 * @since 1.0.45
 */
interface IOpenDocumentResult {
}
/**
 * Represents the size of a widget in the number of columns and rows it spans on a page (cols 1-4, rows 1-2).
 * Response as an observable from [[IWidgetContext.getSize]]
 *
 * @since 2.3.0
 */
interface IWidgetSize {
    cols: number;
    rows: number;
}
/**
 * Portal V2 Search Spotlight
 *
 * @deprecated Federated Search and the related Spotlight API is not available.
 */
interface ISpotlight {
    /**
     * Data that is sent to the widget when a result is selected.
     */
    data$: Observable<ISpotlightData>;
}
interface ISpotlightData {
    /**
     * Misc. metadata about the result/repository
     */
    metadata: {
        repository: {
            name: string;
            displayName: string;
        };
    };
    /**
     * The properties that comes with the search result.
     */
    properties: Record<string, unknown>;
    /**
     * The field data that is resolved based on the `widgetData` repository property.
     */
    fields?: Array<{
        label: string;
        value: string;
    }>;
}
/**
 * Gets the Angular injection token for the widget context.
 * Use this when injecting the widget context in an Angular component constructor.
 *
 * @since 1.0.22
 */
declare const widgetContextInjectionToken: InjectionToken<IWidgetContext>;
/**
 * Gets the Angular injection token for the widget instance.
 * Use this when injecting the widget instance in an Angular component constructor.
 *
 * @since 1.0.22
 */
declare const widgetInstanceInjectionToken: InjectionToken<IWidgetInstance>;
/**
 * Represents a content translation item.
 * @since 1.0.32
 */
interface ITranslationItem {
    /**
     * Gets or sets the label of the item to translate.
     */
    label: string;
    /**
     * Sets the property name of the item.
     *
     * This property will be used in the translation data dictionary.
     * This property is optional in the single item format.
     */
    name: string;
    /**
     * Gets or sets the max length of the translated string.
     */
    maxLength: number;
    /**
     * Gets or sets a value that indicates if the item should be displayed in a text area.
     * The default is a single line input field.
     */
    isTextArea?: boolean;
    /**
     * Gets or sets a value that indicates if the item should be displayed in a markdown component.
     *
     * @since 2.3.0
     */
    isMarkdown?: boolean;
    /**
     * Gets or sets the default value that will be used when a translation is missing.
     * This value will be used as a hint text in the content translation dialog.
     */
    defaultValue?: string;
    /**
     * Gets or sets a unique label ID.
     */
    labelId?: string;
    /**
     * Gets or sets a unique input / text area ID.
     */
    valueId?: string;
    /**
     * Gets or sets the required property, which is used in the translations UI.
     * It is used to indicate to the user that translation of this item is required.
     * This value is true by default. If true, this item must be translated.
     * If all item translations are optional for a given language, at least one must be translated.
     */
    isRequired?: boolean;
}
/**
 * Represents content translation options.
 * @since 1.0.22
 */
interface ITranslationOptions {
    /**
     * Gets or sets the parent view for the content translation dialog.
     * This property is mandatory in most cases.
     */
    view?: ViewContainerRef;
    /**
     * Gets or sets an item to translate.
     * This property cannot be used in combination with the items property.
     */
    item?: ITranslationItem;
    /**
     * Gets or sets an array of items to translate.
     * This property cannot be used in combination with the item property.
     */
    items?: ITranslationItem[];
    /**
     * Gets or sets the data to translate.
     *
     * The data should be dictionary in one of two formats.
     * Single item format is language code -> translated string
     * Multi item format is language code -> translated string dictionary
     *
     * Use single item format in combination with the item property.
     * Use multi item format in combination with the items property.
     */
    data?: any;
}
/**
 * Represents a content translation result.
 * @since 1.0.22
 */
interface ITranslationResult {
    data?: any;
}
/**
 * Represents the content translation service.
 * @since 1.0.22
 */
interface ITranslationService {
    isEnabled(): boolean;
    translate(options: ITranslationOptions): Observable<ITranslationResult>;
    getLanguage(): string;
}
/**
 * Content translation service.
 * @since 1.0.22
 */
declare class TranslationService implements ITranslationService {
    private instance;
    initialize(instance: ITranslationService): void;
    /**
     * Gets a value that indicates if content translation is enabled.
     * This function must be called before translation is enabled in a widget.
     */
    isEnabled(): boolean;
    /**
     * Shows a dialog for content translation.
     * @param options dialog options
     * @returns an Observable that will be resolved to an ITranslationResult if the user
     * closes the dialog with OK or rejected if the user closes the dialog with cancel.
     */
    translate(options: ITranslationOptions): Observable<ITranslationResult>;
    /**
     * Gets the current language code, or null if the Translation Service is unavailable.
     */
    getLanguage(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<TranslationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TranslationService>;
}
/**
 * Defines the different modes the widget can be executing in. The widget will start in one mode
 * that cannot changed during the entire session.
 * @since 1.0.34
 */
declare enum Mode {
    Default = 0,
    Mobile = 1,
    ContextApp = 2
}
/**
 * Defines a sub mode if applicable. The widget will start in one mode
 * that cannot change during the entire session. Currently, there is only sub modes for the Mobile mode when a widget
 * can be part of a page or in a single view mode which is called MobileSingle.
 * @since 1.0.34
 */
declare enum SubMode {
    Default = 0,
    MobilePage = 1,
    MobileSingle = 2
}
/**
 * Defines the options that are able to be set in state Options.
 */
interface BusyStateOptions {
    position?: BusyStatePosition;
}
/**
 * Defines which positions are allowed to be set for BusyStatePosition.
 * See BusyStateOptions.
 */
type BusyStatePosition = "center" | "bottom";
type GlobalInfor = {
    lime: {
        version: string;
        ResourcesKeys: any;
        language: string;
        locale: string;
        log: any;
        getWidgetCacheArg: (id: string) => string;
    };
    companyon: {
        client: {
            /**
             * Send "prepareApplicationDrillback" message to handle the drillback execution
             */
            sendPrepareDrillbackMessage: (link: string) => void;
            /**
             * Send "prepareFavoriteContext" message to handle the shortcut execution
             */
            sendPrepareFavoritesMessage: (link: string) => void;
            sendMessage: (name: string, data: any) => void;
            registerMessageHandler: (name: string, handler: Function, namespace?: string) => void;
            unRegisterMessageHandler: (name: string, namespace?: string) => void;
        };
    };
};
declare global {
    interface Window {
        infor: GlobalInfor;
    }
    var infor: GlobalInfor;
    /**
     * This makes TypeScript understand things like `document.createElement("ids-button")`
     * and `document.querySelector("ids-button")`.
     *
     * Note: This should be provided by IDS, as the component list and names
     * will need to be updated. But this should work in the meantime.
     */
    interface HTMLElementTagNameMap {
        "ids-about": IdsAbout;
        "ids-accordion": IdsAccordion;
        "ids-accordion-header": IdsAccordionHeader;
        "ids-accordion-panel": IdsAccordionPanel;
        "ids-accordion-section": IdsAccordionSection;
        "ids-action-panel": IdsActionPanel;
        "ids-action-sheet": IdsActionSheet;
        "ids-alert": IdsAlert;
        "ids-app-menu": IdsAppMenu;
        "ids-app-menu-container": IdsAppMenuContainer;
        "ids-area-chart": IdsAreaChart;
        "ids-avatar": IdsAvatar;
        "ids-axis-chart": IdsAxisChart;
        "ids-badge": IdsBadge;
        "ids-bar-chart": IdsBarChart;
        "ids-block-grid": IdsBlockGrid;
        "ids-block-grid-item": IdsBlockGridItem;
        "ids-box": IdsBox;
        "ids-breadcrumb": IdsBreadcrumb;
        "ids-button": IdsButton;
        "ids-button-group": IdsButtonGroup;
        "ids-button-group-section": IdsButtonGroupSection;
        "ids-calendar": IdsCalendar;
        "ids-calendar-event": IdsCalendarEvent;
        "ids-card": IdsCard;
        "ids-card-action": IdsCardAction;
        "ids-checkbox": IdsCheckbox;
        "ids-checkbox-group": IdsCheckboxGroup;
        "ids-color": IdsColor;
        "ids-color-picker": IdsColorPicker;
        "ids-container": IdsContainer;
        "ids-counts": IdsCounts;
        "ids-data-grid": IdsDataGrid;
        "ids-data-grid-cell": IdsDataGridCell;
        "ids-data-grid-header": IdsDataGridHeader;
        "ids-data-grid-row": IdsDataGridRow;
        "ids-data-label": IdsDataLabel;
        "ids-date-picker": IdsDatePicker;
        "ids-date-picker-popup": IdsDatePickerPopup;
        "ids-draggable": IdsDraggable;
        "ids-drawer": IdsDrawer;
        "ids-dropdown": IdsDropdown;
        "ids-dropdown-list": IdsDropdownList;
        "ids-editor": IdsEditor;
        "ids-empty-message": IdsEmptyMessage;
        "ids-error-page": IdsErrorPage;
        "ids-expandable-area": IdsExpandableArea;
        "ids-fieldset": IdsFieldset;
        "ids-filter-field": IdsFilterField;
        "ids-form": IdsForm;
        "ids-header": IdsHeader;
        "ids-hidden": IdsHidden;
        "ids-hierarchy": IdsHierarchy;
        "ids-hierarchy-item": IdsHierarchyItem;
        "ids-hierarchy-legend": IdsHierarchyLegend;
        "ids-hierarchy-legend-item": IdsHierarchyLegendItem;
        "ids-home-page": IdsHomePage;
        "ids-hyperlink": IdsHyperlink;
        "ids-icon": IdsIcon;
        "ids-image": IdsImage;
        "ids-input": IdsInput;
        "ids-input-group": IdsInputGroup;
        "ids-kpi": IdsKpi;
        "ids-layout-flex": IdsLayoutFlex;
        "ids-layout-flex-item": IdsLayoutFlexItem;
        "ids-layout-grid": IdsLayoutGrid;
        "ids-layout-grid-cell": IdsLayoutGridCell;
        "ids-line-chart": IdsLineChart;
        "ids-link-list": IdsLinkList;
        "ids-list-box": IdsListBox;
        "ids-list-box-option": IdsListBoxOption;
        "ids-list-builder": IdsListBuilder;
        "ids-list-view": IdsListView;
        "ids-list-view-group-header": IdsListViewGroupHeader;
        "ids-list-view-item": IdsListViewItem;
        "ids-loading-indicator": IdsLoadingIndicator;
        "ids-lookup": IdsLookup;
        "ids-masthead": IdsMasthead;
        "ids-media-gallery": IdsMediaGallery;
        "ids-media-viewer": IdsMediaViewer;
        "ids-menu": IdsMenu;
        "ids-menu-button": IdsMenuButton;
        "ids-menu-group": IdsMenuGroup;
        "ids-menu-header": IdsMenuHeader;
        "ids-menu-item": IdsMenuItem;
        "ids-message": IdsMessage;
        "ids-modal": IdsModal;
        "ids-modal-button": IdsModalButton;
        "ids-module-nav": IdsModuleNav;
        "ids-module-nav-bar": IdsModuleNavBar;
        "ids-module-nav-button": IdsModuleNavButton;
        "ids-module-nav-content": IdsModuleNavContent;
        "ids-module-nav-item": IdsModuleNavItem;
        "ids-module-nav-settings": IdsModuleNavSettings;
        "ids-module-nav-switcher": IdsModuleNavSwitcher;
        "ids-module-nav-user": IdsModuleNavUser;
        "ids-month-view": IdsMonthView;
        "ids-month-year-picklist": IdsMonthYearPicklist;
        "ids-multiselect": IdsMultiselect;
        "ids-notification-banner": IdsNotificationBanner;
        "ids-overlay": IdsOverlay;
        "ids-pager": IdsPager;
        "ids-pager-button": IdsPagerButton;
        "ids-pager-dropdown": IdsPagerDropdown;
        "ids-pager-input": IdsPagerInput;
        "ids-pager-number-list": IdsPagerNumberList;
        "ids-picker-popup": IdsPickerPopup;
        "ids-pie-chart": IdsPieChart;
        "ids-popup": IdsPopup;
        "ids-popup-menu": IdsPopupMenu;
        "ids-process-indicator": IdsProcessIndicator;
        "ids-process-indicator-step": IdsProcessIndicatorStep;
        "ids-progress-bar": IdsProgressBar;
        "ids-progress-chart": IdsProgressChart;
        "ids-radio": IdsRadio;
        "ids-radio-group": IdsRadioGroup;
        "ids-rating": IdsRating;
        "ids-scroll-container": IdsScrollContainer;
        "ids-scroll-view": IdsScrollView;
        "ids-search-field": IdsSearchField;
        "ids-segmented-control": IdsSegmentedControl;
        "ids-separator": IdsSeparator;
        "ids-skip-link": IdsSkipLink;
        "ids-slider": IdsSlider;
        "ids-spinbox": IdsSpinbox;
        "ids-splitter": IdsSplitter;
        "ids-splitter-pane": IdsSplitterPane;
        "ids-stats": IdsStats;
        "ids-step-chart": IdsStepChart;
        "ids-sub-tab": IdsSubTab;
        "ids-sub-tabs": IdsSubTabs;
        "ids-swaplist": IdsSwaplist;
        "ids-swappable": IdsSwappable;
        "ids-swappable-item": IdsSwappableItem;
        "ids-swipe-action": IdsSwipeAction;
        "ids-switch": IdsSwitch;
        "ids-tab": IdsTab;
        "ids-tab-content": IdsTabContent;
        "ids-tab-divider": IdsTabDivider;
        "ids-tab-more": IdsTabMore;
        "ids-tabs": IdsTabs;
        "ids-tabs-context": IdsTabsContext;
        "ids-tag": IdsTag;
        "ids-tag-list": IdsTagList;
        "ids-text": IdsText;
        "ids-textarea": IdsTextarea;
        "ids-theme-switcher": IdsThemeSwitcher;
        "ids-time-picker": IdsTimePicker;
        "ids-time-picker-popup": IdsTimePickerPopup;
        "ids-toast": IdsToast;
        "ids-toast-message": IdsToastMessage;
        "ids-toggle-button": IdsToggleButton;
        "ids-toolbar": IdsToolbar;
        "ids-toolbar-more-actions": IdsToolbarMoreActions;
        "ids-toolbar-section": IdsToolbarSection;
        "ids-tooltip": IdsTooltip;
        "ids-tree": IdsTree;
        "ids-tree-node": IdsTreeNode;
        "ids-treemap": IdsTreemap;
        "ids-trigger-button": IdsTriggerButton;
        "ids-trigger-field": IdsTriggerField;
        "ids-upload": IdsUpload;
        "ids-upload-advanced": IdsUploadAdvanced;
        "ids-upload-advanced-file": IdsUploadAdvancedFile;
        "ids-virtual-scroll": IdsVirtualScroll;
        "ids-week-view": IdsWeekView;
        "ids-widget": IdsWidget;
        "ids-wizard": IdsWizard;
        "ids-wizard-step": IdsWizardStep;
    }
}

/**
 * Represents options for number formatting.
 *
 * @since 1.0
 */
interface INumberFormatOptions {
    /**
     * Gets or sets the decimal separator character.
     */
    separator?: string;
}
/**
 * Represents options for sort functions in the [[ArrayUtil]] class.
 *
 * @since 1.0
 */
interface ISortOptions {
    /**
     * Gets or sets a value that indicates if sorting should ignore case.
     * The default value is false. If this setting is set to true all values will be converted to strings when sorting.
     */
    ignoreCase?: boolean;
    /**
     * Options for LocaleCompare sorting
     * (https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/localeCompare).
     * If set, sorting will be based on locale. Set as empty object for default settings.
     * @since 1.0.30
     */
    localeOptions?: ILocaleSortOptions;
}
/**
 * Locale specific sort options.
 * @since 1.0.30
 */
interface ILocaleSortOptions {
    /**
     * BCP 47 compliant locale string.
     * If omitted, the configured Ming.le locale will be used.
     */
    locale?: string;
    /**
     * The locale matching algorithm to use. Possible values are "lookup" and "best fit"; the default is "best fit".
     */
    localeMatcher?: "lookup" | "best fit";
    /**
     * Whether the comparison is for sorting or for searching for matching strings.
     * Possible values are "sort" and "search"; the default is "sort".
     */
    usage?: "sort" | "search";
    /**
     * Which differences in the strings should lead to non-zero result values.
     *
     * Possible values are:
     * "base": Only strings that differ in base letters compare as unequal. Examples: a ≠ b, a = á, a = A.
     * "accent": Only strings that differ in base letters or accents and other diacritic marks compare as unequal.
     * Examples: a ≠ b, a ≠ á, a = A.
     * "case": Only strings that differ in base letters or case compare as unequal. Examples: a ≠ b, a = á, a ≠ A.
     * "variant": Strings that differ in base letters, accents and other diacritic marks, or case compare as unequal.
     * Other differences may also be taken into consideration.
     * Examples: a ≠ b, a ≠ á, a ≠ A.
     * The default is "variant" for usage "sort"; it's locale dependent for usage "search".
     */
    sensitivity?: "base" | "accent" | "case" | "variant";
    /**
     * Whether punctuation should be ignored. Possible values are true and false; the default is false.
     */
    ignorePunctuation?: boolean;
    /**
     * Whether numeric collation should be used, such that "1" < "2" < "10".
     * Possible values are true and false; the default is false.
     * This option can be set through an options property or through a Unicode extension key; if both are provided,
     * the options property takes precedence. Implementations are not required to support this property.
     */
    numeric?: boolean;
    /**
     * Whether upper case or lower case should sort first.
     * Possible values are "upper", "lower", or "false" (use the locale's default); the default is "false".
     * This option can be set through an options property or through a Unicode extension key; if both are provided,
     * the options property takes precedence. Implementations are not required to support this property.
     */
    caseFirst?: "upper" | "lower" | "false";
}
/**
 * Utility class for array operations.
 *
 * @since 1.0
 */
declare class ArrayUtil {
    /**
     * Checks if an item exists in an array.
     * @returns True if an item exists.
     */
    static contains(array: any[], value: any): boolean;
    /**
     * Gets the index of a value in an array.
     * @param array Array to get value index from.
     * @param value Value to get index of.
     * @returns index of value.
     */
    static indexOf(array: any[], value: any): number;
    /**
     * Sorts the array in ascending order of the given property.
     * @param array Array to sort.
     * @param property Property to sort array by.
     * @param options Optional options for controlling the sorting.
     * @returns The sorted array.
     */
    static sortByProperty(array: any[], property: string, options?: ISortOptions): any[];
    /**
     * Removes an item in an array.
     */
    static remove(array: any[], item: any): void;
    /**
     * Removes an item in an array by matching the value of a specific property.
     *
     * @param array the array to remove an item from
     * @param name the name of the propery
     * @param value that value that the property should match
     * @returns the removed item or null if the item could not be found
     */
    static removeByProperty<T>(array: T[], name: string, value: any): T;
    /**
     * Removes the first item in an array that matches a predicate function.
     *
     * @param array the array to remove an item from
     * @param predicate a predicate function that returns true for a matching item in the array
     * @returns the removed item or null if the item could not be found
     */
    static removeByPredicate<T>(array: T[], predicate: (item: T) => boolean): T;
    /**
     * Finds the index of an item in an array that matches a predicate function.
     *
     * @param array the arrary to find an item in
     * @param predicate a predicate function that returns true for a matching item in the array
     * @returns the index of the item or -1 if the item could not be found
     */
    static indexByPredicate<T>(array: T[], predicate: (item: T) => boolean): number;
    /**
     * Gets the index of an item in an array by matching the value of a specific property.
     */
    static indexByProperty<T>(array: T[], name: string, value: any): number;
    /**
     * Gets the item in an array by matching the value of a specific property.
     */
    static itemByProperty<T = any>(array: any[], name: string, value: any): T;
    /**
     * Gets the item matching the predicate.
     */
    static itemByPredicate<T>(array: T[], predicate: (item: T) => Object): T;
    /**
     * Filters an array based on a predicate.
     */
    static filterByPredicate<T>(array: T[], predicate: (item: T) => Object): T[];
    /**
     * Checks if an item exists in an array by matching the value of a specific property.
     * @ returns True if an item with the property and value exists.
     */
    static containsByProperty(array: any[], name: string, value: any): boolean;
    /**
     * Gets the last item in an array.
     * @returns The last item or null if the array is null or empty.
     */
    static last(array: any[]): any;
    /**
     * Finds the first item in the array that matches the conditions defined in the predicate function.
     * @param array An array of items to search.
     * @param predicate A predicate function that should return true if the item parameter matches the predicate condition.
     */
    static find<T>(array: T[], predicate: (item: T) => boolean): T;
    /**
     * Finds all items in the array that matches the conditions defined in the predicate function.
     * @param array An array of items to search.
     * @param predicate A predicate function that should return true if the item parameter matches the predicate condition.
     */
    static findAll<T>(array: T[], predicate: (item: T) => boolean): T[];
    /**
     * Creates an array of n entries with the specified default value.
     * @params n            Number of entries.
     * @params defaultValue The default values of the entries.
     * @returns Array.
     */
    static array<T>(n: number, defaultValue?: T): T[];
    /**
     * Creates a matrix (two-dimensional array) with specified default values.
     * @param rows     The number of rows in the matrix.
     * @param columns The number of columns in the matrix.
     * @param defaultValue Optional default value.
     * @returns matrix.
     */
    static matrix<T>(rows: number, columns: number, defaultValue?: T): T[][];
    /**
     * Moves an object in an array to another index.
     */
    static move(array: any[], index: number, newIndex: number): void;
    /**
     * Swaps two items in an array.
     *
     * @param items the array
     * @param index1 the index of the first item
     * @param index2 the index of the second item
     *
     * @since 1.0.17
     */
    static swap(items: any[], index1: number, index2: number): void;
    /**
     * Safely concatenates two arrays.
     *
     * @param items the first array
     * @param items2 the second array
     *
     * @since 1.0.27
     */
    static concat<T>(items: T[], items2: T[]): T[];
    /**
     * Rotate array to the left a given number of clicks.
     * @example
     * rotateArray([1,2,3,4], 1) // [2,3,4,1]
     * @param array An array
     * @param clicks A positive integer
     *
     * @since 1.0.34
     */
    static rotateLeft<T>(array: T[], clicks: number): T[];
}
/**
 * Number utility functions.
 *
 * @since 1.0
 */
declare class NumUtil {
    private static defaultSeparator;
    private static defaultOptions;
    /**
     * Gets the default options used by the functions in the class.
     * @returns The default options.
     */
    static getDefaultOptions(): INumberFormatOptions;
    /**
     * Sets the default options used by the functions in the class.
     * @options The default options.
     */
    static setDefaultOptions(options: INumberFormatOptions): void;
    /**
     * Gets a values that indicates if the parameter is a number.
     *
     * The value is considered to be a number if it can be parsed as a float, it is a number and it is finite.
     * @param n The value to check.
     * @returns True if the value is a number.
     */
    static isNumber(n: any): boolean;
    /**
     * Gets an integer value from a string.
     * @param s The string to parse.
     * @param defaultValue Optional default value to return if the string cannot be parsed. The default is zero.
     * @returns An integer parsed from the string or the default value.
     */
    static getInt(s: string, defaultValue?: number): number;
    /**
     * Formats a number or string using default or specified formatting options.
     *
     * This function currently only supports formatting using a specified decimal separator.
     * The value to format is expected to be either a number or a string containing a number where any
     * decimal separator is dot (.). If the value is a string it may not contain any thousand separators
     * or other formatting characters.
     *
     * @param value The value to format which can be a number or a number in string format.
     * @param options Optional formatting options.
     */
    static format(value: any, options?: INumberFormatOptions): string;
    /**
     * Pads a number with leading zeroes up to the specified length.
     * @param num The number to pad.
     * @param length The length of the string.
     */
    static pad(num: number, length: number): string;
    /**
     * Gets a value that indicates if the string contains only integers (1234567890).
     * @param s The string value to check.
     * @returns True if string contains only integers.
     */
    static hasOnlyIntegers(s: string): boolean;
    /**
     * Calculate the remainder between the dividend and the divisor. (dividend mod divisor)
     * @param dividend
     * @param divisor
     *
     * @since 1.0.32
     */
    static mod(dividend: number, divisor: number): number;
    /**
     * Gets a random integer between the min and max values.
     * @param min The min integer value
     * @param max The max integer value
     * @returns A random integer.
     *
     * @since 2.0.0
     */
    static randomInt(min: number, max: number): number;
    private static getLocaleSeparator;
}
/**
 * Common Utility functions.
 *
 * @since 1.0
 */
declare class CommonUtil {
    private static chars;
    /**
     * Copies an object using JSON stringify and parse.
     *
     * The object to copy must be valid as JSON. Note the limitations with Date object
     * JSON serialization (avoid using this function with Date if unsure).
     *
     * @param value the object to copy
     * @returns	a copy of the input object
     *
     * @since 1.0.22
     */
    static copyJson<T>(value: T): T;
    /**
     * Gets the local date string.
     * Options can be used to set the formatting, for example: { date: "short" } or { pattern: "yyyy-MM-dd HH:mm" }.
     * @params dateString Date string.
     * @params options    Options for fromatting.
     * @returns string    Formatted date.
     */
    static getLocaleDateString(value: string | Date, options?: any): string;
    /**
     * Delets a property of an object.
     * @param object   Object of which to delete a property.
     * @param property Property to delete.
     */
    static deleteProperty(object: any, property: string): void;
    /**
     * Converts a boolean from a string.
     * @param s A string to convert.
     * @param defaultValue Default return value if string can't be used.
     */
    static getBoolean(s: string, defaultValue?: boolean): boolean;
    /**
     * @deprecated This function should not be used and will be removed in a later version.
     * @since 1.0.28
     */
    static getUuid(prefix: string): string;
    /**
     * Checks for undefined. Returns true if the object has a value, eg not undefined and not null.
     * @param anyObject Any object
     * @since 1.0.28
     */
    static hasValue(anyObject: any): boolean;
    /**
     * Checks if undefined. Returns true if undefined.
     * @param anyObject Any object
     * @since 1.0.28
     */
    static isUndefined(anyObject: any): boolean;
    /**
     * Checks if the object is a boolean.
     * @param anyObject Any object
     * @since 1.0.28
     */
    static isBoolean(anyObject: any): boolean;
    /**
     * Checks if an arbitrary object has a specific function defined or not.
     * @param anyObject An object to check.
     * @param functionName The name of the function to check.
     */
    static hasFunction(anyObject: any, functionName: string): boolean;
    /**
     * Creates a string with random uppercase letters and numbers.
     * The default length is 16 if the stringLength parameter is omitted.
     */
    static random(stringLength?: number): string;
    /**
     * Gets a value that indicates if the current window is an IFrame or not.
     */
    static isIframe(): boolean;
    /**
     * Returns the client's date as yyyy-mm-ddThh:mm
     * Ex: 2015-01-20T21:20
     */
    static getClientDate(): string;
    /**
     * @deprecated This method should not be used and will be removed in a later version.
     */
    static detectBrowser(): void;
}
/**
 * HTML utility functions for creating and manipulating HTML elements.
 *
 * @since 1.0
 */
declare class HtmlUtil {
    private static readonly log;
    /**
     * Creates an iframe element without borders and the sandbox attribute set.
     */
    static iframe(url?: string, name?: string): JQuery;
    static destroyIFrame(iframe: JQuery): void;
    /**
     * Returns a string that has been escaped so it can safely be used within an HTML element.
     * Use this method to avoid XSS when inserting untrusted content into HTML elements.
     * Read more at https://www.owasp.org/index.php/XSS_(Cross_Site_Scripting)_Prevention_Cheat_Sheet#RULE_.231_-_HTML_Escape_Before_Inserting_Untrusted_Data_into_HTML_Element_Content.
     * @param content String to be escaped
     * @returns Escaped content
     */
    static escapeStringForHtml(content: string): string;
    /**
     * Escapes all properties of the given object that are strings, so it can safely be used within an HTML element.
     * @param obj Object to be escaped
     * @returns Escaped content
     */
    static escapeObjectStringsForHtml(obj: Object): Object;
}
/**
 * String utility functions.
 *
 * @since 1.0
 */
declare class StringUtil {
    /**
     * Gets a value that indicates if the string is null, undefined, empty or contains only whitespace.
     * @param value The string to check.
     * @returns True if the string is null, undefined, empty or contains only whitespace.
     */
    static isNullOrWhitespace(value: string): boolean;
    /**
     * Returns true if the value is a string.
     * @param value An object that needs to be checked if it is a String or not
     */
    static isString(value: any): boolean;
    /**
     * Gets a value that indicates if a string starts with a specified value.
     * @param value The string value to check.
     * @param prefix The value that the string should start with.
     * @returns True if the string starts with the specified prefix value.
     */
    static startsWith(value: string, prefix: string): boolean;
    static replaceParameters(template: string, resolveFunction: Function): string;
    /**
     * Gets a value that indicates if a string ends with a specified value.
     * @param value The string value to check.
     * @param suffix The value that the string should end with.
     * @returns True if the string ends with the specified suffix value.
     */
    static endsWith(value: string, suffix: string): boolean;
    /**
     * Trims whitespace from the end of a string.
     * @param value The value to trim.
     * @returns The trimmed value.
     */
    static trimEnd(value: string): string;
    /**
     * Replaces all occurrences of a string in a string.
     * @param value the string to replace strings in
     * @param find the string to find
     * @param replace the string to replace
     *
     * @since 1.0.29
     */
    static replaceAll(value: string, find: string, replace: string): string;
    static format(...args: any[]): string;
    static splitTagString(value: string): string;
    static splitAndInsert(value: string, splitChar: string, insertChar: string): string;
    /**
     * Joins an array of object using a predicate and returns a string.
     * @param array An array of objects
     * @param predicate A predicate to select the string from the object that should be used in the join
     * @param splitChar Optional separator, default is comma.
     * @since 1.0.30
     */
    static join<T>(array: T[], predicate: (item: T) => string, splitChar?: string): string;
}

/**
 * Interface for custom log appender callback functions.
 *
 * A log appender function can be used to get all logs from the Log class for the current log level.
 *
 * @since 1.0
 */
interface ILogAppender {
    (level: number, text: string, ex?: any): any;
}
/**
 * Log text messages and exceptions on different log levels to the browser console and optional custom log appenders.
 *
 * **Example:**
 *
 * import Log = require("log");
 * Log.info("Application initialized");
 *
 * @since 1.0
 */
declare class Log {
    /**
     * Fatal log level. Severe errors that prevents the application from functioning.
     */
    static levelFatal: number;
    /**
     * Error log level.
     */
    static levelError: number;
    /**
     * Warning log level.
     */
    static levelWarning: number;
    /**
     * Information log level.
     */
    static levelInfo: number;
    /**
     * Debug log level. Detailed information for debug purposes.
     */
    static levelDebug: number;
    /**
     * Trace log level. Most detailed information for debug purposes.
     */
    static levelTrace: number;
    /**
     * Gets or sets the current log level. The default log level is information.
     */
    static level: number;
    /**
     * Gets or sets a value that indicates if logging to the browser console is enabled.
     * The default value is true.
     */
    static isConsoleLogEnabled: boolean;
    private static prefixes;
    private static appenders;
    /**
     * Adds a new log appender that will receive log entries for the current log level.
     * @param appender A log appender
     */
    static addAppender(appender: ILogAppender): void;
    /**
     * Removes an existing log appender.
     * @param appender An existing appender to remove.
     */
    static removeAppender(appender: ILogAppender): void;
    /**
     * Gets a formatted log entry.
     * @param level The log level.
     * @param text The log message text.
     * @param ex An optional exception object.
     */
    static getLogEntry(level: number, text: string, ex?: any): string;
    /**
     * Sets the default log level which is information.
     */
    static setDefault(): void;
    /**
     * Logs a text message and an optional exception on the fatal log level.
     * @param text A log message.
     * @param ex An optional exception object.
     */
    static fatal(text: string, ex?: any): void;
    /**
     * Logs a text message and an optional exception on the error log level.
     * @param text A log message.
     * @param ex An optional exception object.
     */
    static error(text: string, ex?: any): void;
    /**
     * Logs a text message and an optional exception on the warning log level.
     * @param text A log message.
     * @param ex An optional exception object.
     */
    static warning(text: string, ex?: any): void;
    /**
     * Logs a text message and an optional exception on the information log level.
     * @param text A log message.
     * @param ex An optional exception object.
     */
    static info(text: string, ex?: any): void;
    /**
     * Gets a value that indicates if the debug log level is enabled. Use this before logging large debug messages.
     *
     * @returns True if the debug log level is enabled
     */
    static isDebug(): boolean;
    /**
     * Sets the current log level to debug.
     */
    static setDebug(): void;
    /**
     * Logs a text message and an optional exception on the debug log level.
     * @param text A log message.
     * @param ex An optional exception object.
     */
    static debug(text: string, ex?: any): void;
    /**
     * Gets a value that indicates if the trace log level is enabled. Use this before logging large trace messages.
     *
     * @returns True if the trace log level is enabled
     */
    static isTrace(): boolean;
    /**
     * Sets the current log level to trace.
     */
    static setTrace(): void;
    /**
     * Logs a text message and an optional exception on the trace log level.
     * @param text A log message.
     * @param ex An optional exception object.
     */
    static trace(text: string, ex?: any): void;
    /**
     * Gets a military time string with hours, minutes, seconds and milliseconds on the format hh:mm:ss,ttt.
     * @returns A military time string.
     */
    private static getTime;
    private static log;
}

/**
 * Defines standard button combinations for a message dialog.
 *
 * @since 1.0
 */
declare enum StandardDialogButtons {
    /**
     * Shows an OK button (1).
     */
    Ok = 1,
    /**
     * Shows an OK button and a Cancel button (2).
     */
    OkCancel = 2,
    /**
     * Shows a Yes and a No button (3).
     */
    YesNo = 3,
    /**
     * Shows a Yes, No and a Cancel button (4).
     */
    YesNoCancel = 4
}
/**
 * Defines the different types of buttons that can be used in dialogs.
 *
 * @since 1.0
 */
declare enum DialogButtonType {
    /**
     * No button is used or the button is unknown (1).
     */
    None = 1,
    /**
     * OK button (2).
     */
    Ok = 2,
    /**
     * Cancel button (3).
     */
    Cancel = 3,
    /**
     * Yes button (4).
     */
    Yes = 4,
    /**
     * No button (5).
     */
    No = 5,
    /**
     * Custom button (6).
     */
    Custom = 6
}
/**
 * Represents the result from a closed dialog.
 *
 * @since 1.0
 */
interface IDialogResult {
    /**
     * Gets or sets the type of button clicked, defined in [[DialogButtonType]].
     *
     * This property might not be set depending on how the dialog was dismissed.
     */
    button?: DialogButtonType;
    /**
     * Gets or sets an optional result value.
     *
     * This property can be used for a result value object of any type in custom dialog scenarios.
     */
    value?: any;
}
/**
 * Represents options for a message dialog.
 *
 * Use either the buttons or standardButtons property.
 *
 * Example options for a message with the standrad buttons Yes and No:
 *
 *		var options: lm.IMessageDialogOptions = {
 *			title: "Confirm Delete",
 *			message: "Are you sure that you want to delete the selected item?",
 *			standardButtons: s.StandardDialogButtons.YesNo
 *		}
 *
 * Example options for a message with custom buttons:
 *
 *		var options: lm.IMessageDialogOptions = {
 *			title: "Remove Widget",
 *			message: "Are you sure that you want to remove the widget?",
 *			buttons: [{
 *				text: "Remove it!",
 *				value: "Yes",
 *				isDefault: true
 *			}, {
 *					text: "Keep it!",
 *					value: "No",
 *					isDefault: false
 *				}]
 *		}
 *
 * @since 1.0
 */
interface IMessageDialogOptions {
    /**
     * Gets or sets the dialog title.
     */
    title: string;
    /**
     * Gets or sets the dialog message.
     */
    message: string;
    /**
     * Gets or sets an optional array of dialog buttons.
     *
     * Use this property or the standardButtons property.
     */
    buttons?: IDialogButton[];
    /**
     * Gets or sets an optional standard button configuration.
     *
     * Use this property or the "buttons" property.
     */
    standardButtons?: StandardDialogButtons;
    /**
     * Gets or sets an optional value that indicates if this is an error message.
     *
     * If this property is set to true the message dialog title will be shown with the error styling.
     */
    isError?: boolean;
    /**
     * Sets css class on modal.
     */
    cssClass?: string;
    /**
     * Specifies wether or not to automatically set primary button styling.
     *
     * True is default.
     */
    hasPrimaryButton?: boolean;
}
/**
 * Represents a dialog button.
 *
 * @since 1.0
 */
interface IDialogButton {
    /**
     * Gets or sets the text to display on the button.
     */
    text: string;
    /**
     * Gets or sets the type of button defined in [[DialogButtonType]].
     */
    type?: any;
    /**
     * Gets or sets an optional value object that will be returned in the [[IDialogResult]] if set.
     */
    value?: any;
    /**
     * Gets or sets an optional ID for the button.
     */
    id?: string;
    /**
     * Gets or sets an optional value that indicates if the button is a link.
     */
    isLink?: boolean;
    /**
     * Gets or sets an optional value that indicates if the button is the default button.
     */
    isDefault?: boolean;
    /**
     * Gets or sets an optional svg icon path for the button
     */
    icon?: string;
    /**
     * Gets or sets an optional css class for the dialog button
     */
    cssClass?: string;
}
/**
 * Represents options for a toast message.
 *
 * @since 1.0
 */
interface IToastOptions {
    /**
     * Gets or sets the toast title.
     */
    title: string;
    /**
     * Gets or sets the toast message.
     */
    message: string;
    /**
     * Sting that stated where the toast should be displayed
     *
     * Possible values: top right, top left, bottom left, bottom right
     */
    position?: string;
    /**
     * States whether the notification should be audible only.
     */
    audibleOnly?: boolean;
    /**
     * States whether to display a progress bar.
     */
    progressBar?: boolean;
    /**
     * States for how long the toast should be visible (milliseconds).
     */
    timeout?: number;
}
/**
 * Represents options for a dialog.
 *
 * @since 1.0
 */
interface IDialogOptions {
    /**
     * Gets or sets the dialog title.
     */
    title: string;
    /**
     * Gets or sets an optional parameter.
     *
     * If this property is set when showing a dialog it will be available on the[[IDialog]] instance.
     */
    parameter?: any;
    /**
     * Gets or sets an optional array of dialog buttons.
     *
     * This property should not be set if custom buttons are added in the dialog template.
     */
    buttons?: IDialogButton[];
    /**
     * Gets or sets an optional style string that will be applied to the modal dialog instance.
     */
    style?: string;
    /**
     * Gets or sets an optional CSS class that will be applied to the modal dialog instance.
     */
    cssClass?: string;
    /**
     * Gets or sets an optional ID of the modal dialog instance.
     */
    id?: string;
    actionPanel?: boolean;
}
/**
 * Represents a dialog event.
 *
 * An instance of this type will be a parameter to the closing and closed events on the [[IDialog]].
 *
 * @since 1.0
 */
interface IDialogEvent {
    /**
     * Gets or sets the dialog instance that is the source of the event.
     */
    dialog: IDialog;
    /**
     * Gets or sets an optional value that indicates if the event should be cancelled.
     *
     * Note that only the closing event can currently be cancelled.
     */
    cancel?: boolean;
}
/**
 * Represents a modal dialog instance.
 *
 * The dialog instance can be retrieved from the scope in a dialog controller using the name "lmDialog".
 *
 * @since 1.0
 */
interface IDialog {
    /**
     * Gets or sets a function that will be called when the dialog is closing.
     *
     * The closing of the dialog can be cancelled by setting the cancel property to true on the event parameter.
     */
    closing: (e: IDialogEvent) => void;
    /**
     * Gets or sets a function that will be called when the dialog is closed.
     */
    closed: (e: IDialogEvent) => void;
    /**
     * Gets or sets a function that will be called when the dialog is opened.
     */
    opened: (e: IDialogEvent) => void;
    /**
     * Gets or sets an optional parameter.
     *
     * This property will have the value set on the [[IDialogOptions]] instance when showing the dialog.
     */
    parameter?: any;
    /**
     * Gets or sets the dialog result.
     */
    result?: IDialogResult;
    /**
     * Closes the dialog.
     *
     * @param result Optional dialog result. The result property will be set if a value is provided.
     */
    close(result?: IDialogResult): void;
}
/**
 * Represents options for the copy to clipboard function.
 *
 * @since 1.0
 */
interface ICopyToClipboardOptions {
    /**
     * Data to be copied or displayed in message modal if copying is not possible.
     */
    copyData: string;
    /**
     * If true, opens a dialog containing the string to be copied, regardless of direct copying is possible.
     */
    forceDialog?: boolean;
}
/**
 * Represent the dialog service that can be use to show standard message dialogs or dialogs with custom content.
 *
 * @since 1.0.17
 */
declare class DialogService {
    protected readonly messageService: SohoMessageService;
    private language;
    private messageFunction;
    constructor(messageService: SohoMessageService);
    /**
     * Shows a message dialog.
     *
     * @param options The message dialog options.
     * @returns An Observable that can be used to subscribe to the dialog result.
     */
    showMessage(options: IMessageDialogOptions): Observable<IDialogResult>;
    /**
     * Copies data to clipboard or opens a dialog with the data to copy if copying is not possible.
     * @param options The copy to clipboard options
     */
    copyToClipboard(options: ICopyToClipboardOptions): void;
    /**
     * Shows a toast notification with the specified options.
     *
     * Defaults position to "bottom right" and timeout to 3000 if not set.
     */
    showToast(options: IToastOptions): void;
    private setDefaultButtons;
    private setSpecificButtons;
    private resolveMessageDialog;
    static ɵfac: i0.ɵɵFactoryDeclaration<DialogService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DialogService>;
}

export { ArrayUtil, BadgeType, CommonUtil, DialogButtonType, DialogService, EmptyStateIcon, HtmlUtil, IWidgetContext, IWidgetInstance, IWidgetSettingsContext, IWidgetSettingsInstance, IonApiConstants, Log, Mode, NumUtil, StandardDialogButtons, StringUtil, SubMode, TrackEventType, TranslationService, WidgetActivationType, WidgetConstants, WidgetMessageType, WidgetSettingsType, WidgetState, widgetContextInjectionToken, widgetInstanceInjectionToken };
export type { BusyStateOptions, BusyStatePosition, EnvironmentInfo, EnvironmentInfoMap, IAccelerationData, IAngularWidgetConfig, IAngularWidgetConfig2, IApplication, IAutocompleteEntity, IBadgeOptions, ICopyToClipboardOptions, ICustomProperties, IDevice, IDialog, IDialogButton, IDialogEvent, IDialogOptions, IDialogResult, IEmptyStateButtonOptions, IEmptyStateOptions, IFindWidgetOptions, IGetAudioOptions, IGetAudioResult, IGetImageOptions, IGetImageResult, IGetLocationOptions, IGetLocationResult, IGetMediaResult, IGetNetworkOptions, IGetNetworkResult, IGetSensorsOptions, IGetSensorsResult, IGetVideoOptions, IGetVideoResult, IGyroscopeData, IIntervalOptions, IIonApiContext, IIonApiInfo, IIonApiInfoOptions, IIonApiOptions, IIonApiProduct, IIonApiRequestOptions, IIonApiResponse, ILanguage, ILaunchOptions, ILocaleSortOptions, ILogAppender, IMapCoordinates, IMapLocationOptions, IMapMarkerOptions, IMapNavigationOptions, IMarker, IMediaSource, IMessage, IMessageDialogOptions, IMessageOptions, INavigation, INavigationEvent, INavigationOptions, INumberFormatOptions, IOpenDocumentOptions, IOpenDocumentResult, IOpenLinkOptions, IOpenLinkResult, IPortalShell, IPortalUser, IReadBarCodeOptions, IReadBarcodeResult, IReadQRCodeOptions, IReadQRCodeResult, IShowMapOptions, IShowMapResult, IShowSettingsOptions, ISortOptions, ISpotlight, ISpotlightData, IToastOptions, ITrackEventOptions, ITrackViewOptions, ITrackingAttributes, ITranslationItem, ITranslationOptions, ITranslationResult, ITranslationService, ITrustedDomains, IValueItem, IVersionInfo, IViewUrlOptions, IWatchOption, IWebComponentWidgetConfig, IWidgetAction, IWidgetActionOption, IWidgetActivationArg, IWidgetComponent, IWidgetContext2, IWidgetDestroyArg, IWidgetInstance2, IWidgetInstanceInfo, IWidgetMessage, IWidgetModule, IWidgetModule2, IWidgetParentContext, IWidgetRefreshArg, IWidgetRestoreArg, IWidgetSettingMetadata, IWidgetSettings, IWidgetSettingsArg, IWidgetSettingsCloseArg, IWidgetSettingsComponent, IWidgetSettingsContext2, IWidgetSettingsInstance2, IWidgetShell, IWidgetSize, IWidgetStatus, IWorkspaceContextData, IWorkspaceSetting, IWorkspaceSettingRule, IWorkspaceSettingValue, IWorkspaceSettingsArg, IWorkspaceSettingsConfiguration, IWorkspaceSettingsContext, IWorkspaceSettingsData, IWorkspaceSettingsState, IWorkspaceSettingsValues, IWorkspaceShell, NetworkConnectionState, NetworkConnectionType, WorkspaceSettingRuleType, WorkspaceSettingSource, WorkspaceSettingType, WorkspaceSettingsEvent };
