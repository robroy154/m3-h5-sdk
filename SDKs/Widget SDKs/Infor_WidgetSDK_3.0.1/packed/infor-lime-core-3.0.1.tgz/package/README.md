# @infor-lime/core

This package includes core interfaces and utilities for widgets and other Portal-related components.
