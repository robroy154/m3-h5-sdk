# @infor-lime/eslint-plugin

ESLint plugin for Homepages widgets

## Install

```bash
# Install the package
npm install --save-dev <path-to-package.tgz>

# Install peer dependencies
npm install --save-dev eslint @typescript-eslint/parser @typescript-eslint/eslint-plugin
```

## Configure

Create a `.eslintrc` with the following content:

```json
{
	"extends": ["plugin:@infor-lime/eslint-plugin/recommended"]
}
```

...or add rules to an existing configuration:

```json
{
	"parser": "@typescript-eslint/parser",
	"parserOptions": {
		"sourceType": "module"
	},
	"plugins": ["@typescript-eslint", "@infor-lime/eslint-plugin"],
	"rules": {
		"lime/no-ajax": "error",
		"lime/no-companyon": "error",
		"lime/no-hardcoded-color": "warn",
		"lime/no-id": "error",
		"lime/no-temporary-interfaces": "warn",
		"lime/no-timers": "warn",
		"lime/no-legacy-imports": "error",
		"lime/no-locale": "error",
		"lime/no-browser-module": "error",
		"lime/style-encapsulation": "error",
		"lime/no-window-location": "error",
		"lime/no-ibc": "error"
	}
}
```

## Rules

| Name                           | Description                                                         |
| :----------------------------- | :------------------------------------------------------------------ |
| `lime/no-ajax`                 | Detect HTTP requests not made through ION API                       |
| `lime/no-browser-module`       | Detect imports of BrowserModule                                     |
| `lime/no-action-assignment`    | Detect when widget actions are reassigned outside the widgetFactory |
| `lime/no-companyon`            | Detect invalid usage of the Infor Companyon Client                  |
| `lime/no-hardcoded-color`      | Detect hardcoded color assignments to element styling               |
| `lime/no-id`                   | Detect non-scoped DOM ID:s                                          |
| `lime/no-temporary-interfaces` | Detect usage of interfaces that are no longer needed                |
| `lime/no-timers`               | Detect intervals and timeouts                                       |
| `lime/no-legacy-imports`       | Detect deprecated "lime" imports                                    |
| `lime/no-locale`               | Detect when trying to set Soho.Locale                               |
| `lime/style-encapsulation`     | Detects usage of shadow-breaking styles                             |
| `lime/no-window-location`      | Detects usage of window.location                                    |
| `lime/no-ibc`                  | Detects usage of send("inforBusinessContext")                       |
