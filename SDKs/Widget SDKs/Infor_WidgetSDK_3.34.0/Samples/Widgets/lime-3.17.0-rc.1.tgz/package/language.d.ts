﻿/**
 * Represents the lime framework language constants.
 */
interface ILanguageLime {
	format(...args: any[]): string;
	get(name: string): string;
	/**
	 * Cancel
	 */
	cancel: string;
	/**
	 * OK
	 */
	ok: string;
	/**
	 * My Pages
	 */
	myPages: string;
	/**
	 * Page Catalog
	 */
	pageCatalog: string;
	/**
	 * Widget Catalog
	 */
	widgetCatalog: string;
	/**
	 * Add
	 */
	add: string;
	/**
	 * Close
	 */
	close: string;
	/**
	 * Are you sure that you want to remove the page '{0}'? The page will still be available in the Page Catalog.
	 */
	confirmRemovePublicPage: string;
	/**
	 * Duplicate Page...
	 */
	duplicatePageEllipsis: string;
	/**
	 * Create
	 */
	create: string;
	/**
	 * Delete Widget
	 */
	deleteWidget: string;
	/**
	 * Import
	 */
	importAction: string;
	/**
	 * Import Page
	 */
	importPage: string;
	/**
	 * New Page
	 */
	newPage: string;
	/**
	 * No
	 */
	no: string;
	/**
	 * Page Settings
	 */
	pageSettings: string;
	/**
	 * Page Settings...
	 */
	pageSettingsEllipsis: string;
	/**
	 * Publish
	 */
	publish: string;
	/**
	 * Read Only
	 */
	readOnly: string;
	/**
	 * Refresh
	 */
	refresh: string;
	/**
	 * Remove Page
	 */
	removePage: string;
	/**
	 * Remove Page...
	 */
	removePageEllipsis: string;
	/**
	 * Save
	 */
	save: string;
	/**
	 * Select
	 */
	select: string;
	/**
	 * Settings
	 */
	settings: string;
	/**
	 * Title
	 */
	title: string;
	/**
	 * Used by {0}
	 */
	usedByCount: string;
	/**
	 * Application Widgets
	 */
	widgetCategoryApplication: string;
	/**
	 * Business Intelligence Widgets
	 */
	widgetCategoryBI: string;
	/**
	 * Business Process Widgets
	 */
	widgetCategoryProcess: string;
	/**
	 * Social Widgets
	 */
	widgetCategorySocial: string;
	/**
	 * Utility Widgets
	 */
	widgetCategoryUtility: string;
	/**
	 * All
	 */
	categoryAll: string;
	/**
	 * Application
	 */
	categoryApplication: string;
	/**
	 * Business Intelligence
	 */
	categoryBI: string;
	/**
	 * Business Process
	 */
	categoryProcess: string;
	/**
	 * Social
	 */
	categorySocial: string;
	/**
	 * Utilities
	 */
	categoryUtilities: string;
	/**
	 * Yes
	 */
	yes: string;
	/**
	 * Add Page
	 */
	addPage: string;
	/**
	 * by {0}
	 */
	byUser: string;
	/**
	 * Last edited by {0}
	 */
	lastEditedBy: string;
	/**
	 * Mandatory
	 */
	mandatory: string;
	/**
	 * Private
	 */
	private: string;
	/**
	 * Owner
	 */
	owner: string;
	/**
	 * Sort by
	 */
	sortBy: string;
	/**
	 * Newest
	 */
	sortNewest: string;
	/**
	 * Oldest
	 */
	sortOldest: string;
	/**
	 * Title A-Z
	 */
	sortTitleAsc: string;
	/**
	 * Title Z-A
	 */
	sortTitleDesc: string;
	/**
	 * Add Widget
	 */
	addWidget: string;
	/**
	 * The widget is not available.
	 */
	brokenWidget: string;
	/**
	 * Are you sure that you want to remove the page '{0}'?
	 */
	confirmRemovePage: string;
	/**
	 * Are you sure that you want to delete the page '{0}'? It will be deleted for all users.
	 */
	confirmDeletePublicPage: string;
	/**
	 * Published
	 */
	publishedWidgetTag: string;
	/**
	 * Standard
	 */
	standardPage: string;
	/**
	 * Standard
	 */
	standardWidget: string;
	/**
	 * Tenant
	 */
	tenantWidget: string;
	/**
	 * Delete Page...
	 */
	deletePageEllipsis: string;
	/**
	 * Delete Widget...
	 */
	deleteWidgetEllipsis: string;
	/**
	 * Can Edit
	 */
	editAccess: string;
	/**
	 * Edit Page Layout
	 */
	editPageLayout: string;
	/**
	 * Enable settings
	 */
	enableSettings: string;
	/**
	 * Export Page...
	 */
	exportPageEllipsis: string;
	/**
	 * Import Page...
	 */
	importPageEllipsis: string;
	/**
	 * Language
	 */
	language: string;
	/**
	 * You can only add {0} pages. You must remove a page in My Pages to be able to add another page.
	 */
	maxPageCountMessage: string;
	/**
	 * You have reached your maximum number of pages. You must remove a page in My Pages to be able to add another page.
	 */
	maxPageMessage: string;
	/**
	 * New Page...
	 */
	newPageEllipsis: string;
	/**
	 * The Page Already Exists
	 */
	pageExists: string;
	/**
	 * You already have the page '{0}' in My Pages.
	 */
	pageExistsMessage: string;
	/**
	 * Preview
	 */
	preview: string;
	/**
	 * Publishing
	 */
	publishWidget: string;
	/**
	 * Publishing
	 */
	publishPage: string;
	/**
	 * Publish Page...
	 */
	publishPageEllipsis: string;
	/**
	 * Publish...
	 */
	publishWidgetEllipsis: string;
	/**
	 * Remove...
	 */
	removeEllipsis: string;
	/**
	 * Set as Homepage
	 */
	setAsHomepage: string;
	/**
	 * Tags
	 */
	tags: string;
	/**
	 * Unable to Add Page
	 */
	unableToAddPage: string;
	/**
	 * View Only
	 */
	viewAccess: string;
	/**
	 * Configure...
	 */
	widgetSettingsEllipsis: string;
	/**
	 * Are you sure that you want to delete the widget '{0}'? It will be deleted for all users.
	 */
	confirmDeleteCustomWidget: string;
	/**
	 * Duplicate Page
	 */
	duplicatePage: string;
	/**
	 * {0} - Copy
	 */
	pageCopyTitle: string;
	/**
	 * Add Translation
	 */
	addTranslation: string;
	/**
	 * Edit Translation
	 */
	editTranslation: string;
	/**
	 * Advanced
	 */
	advanced: string;
	/**
	 * Back
	 */
	back: string;
	/**
	 * Basic
	 */
	basic: string;
	/**
	 * Configure Widget
	 */
	widgetSettings: string;
	/**
	 * Translations
	 */
	translations: string;
	/**
	 * Description
	 */
	description: string;
	/**
	 * Last edited
	 */
	lastEdited: string;
	/**
	 * Remove
	 */
	remove: string;
	/**
	 * Update
	 */
	update: string;
	/**
	 * The page could not be added.
	 */
	unableToAddPageMesssage: string;
	/**
	 * Duplicate Widget
	 */
	duplicateWidget: string;
	/**
	 * Administration
	 */
	administration: string;
	/**
	 * Publishing Widget Copy
	 */
	publishWidgetCopy: string;
	/**
	 * Republish
	 */
	republish: string;
	/**
	 * Republishing
	 */
	republishPage: string;
	/**
	 * Republishing
	 */
	republishWidget: string;
	/**
	 * About
	 */
	about: string;
	/**
	 * Access Level
	 */
	accessLevel: string;
	/**
	 * Edit Published Page
	 */
	editPublishedPage: string;
	/**
	 * Publish the current page to the Page Catalog to share it with other users.
	 */
	publishPageDescription: string;
	/**
	 * Apply
	 */
	apply: string;
	/**
	 * Create New Page
	 */
	createNewPage: string;
	/**
	 * Editing
	 */
	editingPageLayout: string;
	/**
	 * Edit Layout
	 */
	editLayout: string;
	/**
	 * Edit Publishing Configuration...
	 */
	editPublishConfigurationEllipsis: string;
	/**
	 * Edit Published
	 */
	editPublishedWidget: string;
	/**
	 * By adding widgets you can create a page that fits your specific needs.
	 */
	emptyPageDescription: string;
	/**
	 * This page is currently empty
	 */
	emptyPageTitle: string;
	/**
	 * Enabled
	 */
	enabled: string;
	/**
	 * Publish Copy...
	 */
	publishWidgetCopyEllipsis: string;
	/**
	 * Visible
	 */
	visible: string;
	/**
	 * Welcome to Infor Ming.le™
	 */
	welcomeMessage: string;
	/**
	 * Based on
	 */
	basedOn: string;
	/**
	 * Show published
	 */
	showPublished: string;
	/**
	 * Version
	 */
	version: string;
	/**
	 * Add User or Group
	 */
	addUserOrGroup: string;
	/**
	 * All users will be given view access to this page if no specific access rights are set.
	 */
	pageAccessDescription: string;
	/**
	 * Search for user or group...
	 */
	principalSearchPlaceholder: string;
	/**
	 * Access Levels
	 */
	accessLevels: string;
	/**
	 * Based on widget {0}
	 */
	basedOnWidgetX: string;
	/**
	 * Edit Publishing Configuration
	 */
	editPublishConfiguration: string;
	/**
	 * Please refresh Homepages or try again later, contact your system administrator if the problem persists.
	 */
	contactAdminRetry: string;
	/**
	 * The action could not be performed.
	 */
	errorGeneric: string;
	/**
	 * The entity could not be found.
	 */
	errorNotFound: string;
	/**
	 * The action could not be performed in time.
	 */
	errorTimeout: string;
	/**
	 * You are not authorized to perform this action.
	 */
	errorUnauthorized: string;
	/**
	 * The service is currently unavailable.
	 */
	errorUnavailable: string;
	/**
	 * All
	 */
	widgetCategoryAll: string;
	/**
	 * Application
	 */
	application: string;
	/**
	 * Default
	 */
	defaultSelection: string;
	/**
	 * Reset to Default
	 */
	resetToDefault: string;
	/**
	 * Clear Publish Configuration...
	 */
	clearConfigEllipsis: string;
	/**
	 * Only details provided in 'Edit Publish Configuration' will be cleared. All other configurations will remain unchanged. Press 'Yes' to confirm.
	 */
	clearConfigMessage: string;
	/**
	 * Clear Publishing Configuration
	 */
	ConfirmClearConfig: string;
	/**
	 * Copy Widget
	 */
	copyWidget: string;
	/**
	 * Move Left
	 */
	moveLeft: string;
	/**
	 * Move Right
	 */
	moveRight: string;
	/**
	 * Paste Widget
	 */
	pasteWidget: string;
	/**
	 * Previewing {0}
	 */
	previewingPage: string;
	/**
	 * Preview Page
	 */
	previewPage: string;
	/**
	 * Delete
	 */
	delete: string;
	/**
	 * Edit
	 */
	edit: string;
	/**
	 * URL
	 */
	url: string;
	/**
	 * Unable to save. The data exceeds the maximum allowed size.
	 */
	exceedsMaxSize: string;
	/**
	 * Delete Page
	 */
	deletePage: string;
	/**
	 * Choose File
	 */
	chooseFile: string;
	/**
	 * Confirm
	 */
	confirmCancel: string;
	/**
	 * Each tag must be unique
	 */
	duplicateTag: string;
	/**
	 * Translate widget, page title and description
	 */
	enableContentTranslation: string;
	/**
	 * Access the Page Catalog
	 */
	enablePageCatalog: string;
	/**
	 * Export pages
	 */
	enablePageExport: string;
	/**
	 * Import pages
	 */
	enablePageImport: string;
	/**
	 * Publish pages to the Page Catalog
	 */
	enablePagePublish: string;
	/**
	 * Create private pages
	 */
	enablePrivatePages: string;
	/**
	 * Add a page from the Page Catalog
	 */
	enablePublicPageAdd: string;
	/**
	 * Duplicate a page from the Page Catalog
	 */
	enablePublicPageCopy: string;
	/**
	 * Access the Widget Catalog
	 */
	enableWidgetCatalog: string;
	/**
	 * Publish widgets to the Widget Catalog
	 */
	enableWidgetPublish: string;
	/**
	 * Homepages currently not available
	 */
	homepagesUnavailable: string;
	/**
	 * A tag must have at least two characters (excluding #).
	 */
	invalidTagMinLength: string;
	/**
	 * Invalid Input
	 */
	invalidInfput: string;
	/**
	 * The file extension is invalid.
	 */
	invalidFile: string;
	/**
	 * Only {0} tags are allowed.
	 */
	maxCountTag: string;
	/**
	 * You can have a maximum of {0} pages
	 */
	maxUserPages: string;
	/**
	 * Missing Information
	 */
	missingInformation: string;
	/**
	 * Title or description is missing.
	 */
	noTitleOrDescription: string;
	/**
	 * Search
	 */
	search: string;
	/**
	 * Unable to open page settings.
	 */
	unableOpenPageSettings: string;
	/**
	 * Cancel without saving changes?
	 */
	confirmCancelMessage: string;
	/**
	 * Used by
	 */
	usedbyHeader: string;
	/**
	 * Confirm
	 */
	confirmReset: string;
	/**
	 * Are you sure that you want to reset the configuration for this widget?
	 */
	confirmResetMessage: string;
	/**
	 * There are no pages in the Page Catalog.
	 */
	noPages: string;
	/**
	 * No pages were found to match your search.
	 */
	noPagesFound: string;
	/**
	 * There are no widgets in the Widget Catalog.
	 */
	noWidgets: string;
	/**
	 * No widgets were found to match your search.
	 */
	noWidgetsFound: string;
	/**
	 * User Permissions
	 */
	userPermissions: string;
	/**
	 * Permissions
	 */
	permissions: string;
	/**
	 * Name
	 */
	name: string;
	/**
	 * More Homepages
	 */
	moreHomepages: string;
	/**
	 * No widgets were found in the selected category.
	 */
	noWidgetsCategory: string;
	/**
	 * Page added
	 */
	pageAdded: string;
	/**
	 * '{0}' was added.
	 */
	titleAddedMessage: string;
	/**
	 * Widget Added
	 */
	widgetAdded: string;
	/**
	 * Unable to Add Widget
	 */
	unableToAddWidget: string;
	/**
	 * The page does not exist.
	 */
	pageNotExist: string;
	/**
	 * Unable to Save
	 */
	unableToSave: string;
	/**
	 * You are not authorized to view this page.
	 */
	errorUnauthorizedPage: string;
	/**
	 * Page not found
	 */
	pageNotFound: string;
	/**
	 * Selection of Homepage
	 */
	selectionOfHomepage: string;
	/**
	 * Copy to Clipboard
	 */
	copyToClipboard: string;
	/**
	 * Some browsers will block URLs that are not loaded using "HTTPS".
	 */
	httpUrlWarning: string;
	/**
	 * The page is not available.
	 */
	brokenPage: string;
	/**
	 * Pages are not available.
	 */
	pagesNotAvailable: string;
	/**
	 * You don't have permissions to view this page.
	 */
	noPageAccess: string;
	/**
	 * You are not authorized to view this widget.
	 */
	noWidgetAccess: string;
	/**
	 * Text
	 */
	text: string;
	/**
	 * View User Permissions
	 */
	viewUserPermissions: string;
	/**
	 * Use Widget Catalog title as widget title
	 */
	isCatalogWidgetLabel: string;
	/**
	 * Help
	 */
	help: string;
	/**
	 * Something went wrong. Please sign out and restart your browser.
	 */
	errorSignOut: string;
	/**
	 * Unable to publish the page. The maximum number of published pages has been reached.
	 */
	exceedsMaxPageCount: string;
	/**
	 * Unable to publish the widget. The maximum number of published widgets has been reached.
	 */
	exceedsMaxWidgetCount: string;
	/**
	 * Page color
	 */
	pageColor: string;
	/**
	 * Deselect Homepage
	 */
	deselectHomepage: string;
	/**
	 * Move to Bottom
	 */
	moveBottom: string;
	/**
	 * Move to Top
	 */
	moveTop: string;
	/**
	 * The widget is not configured
	 */
	widgetNotConfigured: string;
	/**
	 * Changes made when republishing will affect everyone using this page.
	 */
	pageChangeAffectAll: string;
	/**
	 * Changes made when republishing will affect everyone using this widget.
	 */
	widgetChangeAffectAll: string;
	/**
	 * Widget Configuration
	 */
	widgetConfiguration: string;
	/**
	 * Current Homepage
	 */
	currentHomepage: string;
	/**
	 * Add Banner widget
	 */
	addHeroWidget: string;
	/**
	 * Delete Banner widget
	 */
	deleteHeroWidget: string;
	/**
	 * Manage Quick Links
	 */
	manageQuickLinks: string;
	/**
	 * My Quick Links
	 */
	myQuickLinks: string;
	/**
	 * Clear
	 */
	clear: string;
	/**
	 * Move down
	 */
	moveDown: string;
	/**
	 * Move up
	 */
	moveUp: string;
	/**
	 * Private pages
	 */
	privatePages: string;
	/**
	 * Select the page you want to add the widget to
	 */
	selectPageAddWidget: string;
	/**
	 * Select Page
	 */
	selectPage: string;
	/**
	 * Add Link
	 */
	addLink: string;
	/**
	 * Private pages are not enabled.
	 */
	privatePagesNotEnabled: string;
	/**
	 * Add from Bookmark
	 */
	addfromBookmark: string;
	/**
	 * No bookmarks to show.
	 */
	noBookmarks: string;
	/**
	 * Failed to retrieve bookmarks.
	 */
	noBookmarksError: string;
	/**
	 * Distribution group
	 */
	distributionGroup: string;
	/**
	 * Role
	 */
	role: string;
	/**
	 * User
	 */
	user: string;
	/**
	 * Application
	 */
	applicationDependency: string;
	/**
	 * Available Languages
	 */
	availableLanguages: string;
	/**
	 * Category
	 */
	category: string;
	/**
	 * Widget ID
	 */
	widgetId: string;
	/**
	 * Featured Widget
	 */
	featuredWidget: string;
	/**
	 * Set as Featured
	 */
	setFeatured: string;
	/**
	 * Unset Featured
	 */
	unsetFeatured: string;
	/**
	 * My Recent
	 */
	categoryMyRecent: string;
	/**
	 * New & Updated
	 */
	categoryNewUpdated: string;
	/**
	 * Statistics & Usage
	 */
	categoryStatistics: string;
	/**
	 * Failed to retrieve details.
	 */
	noDetailsError: string;
	/**
	 * Categories
	 */
	categories: string;
	/**
	 * Created by
	 */
	createdBy: string;
	/**
	 * Created by '{0}'
	 */
	createdByName: string;
	/**
	 * Filters
	 */
	filters: string;
	/**
	 * Include published
	 */
	includePublished: string;
	/**
	 * Include standard
	 */
	includeStandard: string;
	/**
	 * My Filters
	 */
	myViews: string;
	/**
	 * Refine by
	 */
	refineBy: string;
	/**
	 * Save Filter
	 */
	saveView: string;
	/**
	 * Everyone
	 */
	everyone: string;
	/**
	 * Disabled
	 */
	disabled: string;
	/**
	 * Type
	 */
	type: string;
	/**
	 * Featured Page
	 */
	featuredPage: string;
	/**
	 * All pages
	 */
	allPages: string;
	/**
	 * All widgets
	 */
	allWidgets: string;
	/**
	 * Open in Catalog
	 */
	openInCatalog: string;
	/**
	 * Czech
	 */
	langcsCZ: string;
	/**
	 * Afrikaans
	 */
	langafZA: string;
	/**
	 * Arabic
	 */
	langarSA: string;
	/**
	 * Danish
	 */
	langdaDK: string;
	/**
	 * German
	 */
	langdeDE: string;
	/**
	 * Greek
	 */
	langelGR: string;
	/**
	 * English (United States)
	 */
	langenUS: string;
	/**
	 * English (United Kingdom)
	 */
	langenGB: string;
	/**
	 * Spanish (Argentina)
	 */
	langesAR: string;
	/**
	 * Spanish (Spain)
	 */
	langesES: string;
	/**
	 * Finnish
	 */
	langfiFI: string;
	/**
	 * French (France)
	 */
	langfrFR: string;
	/**
	 * Hebrew
	 */
	langheIL: string;
	/**
	 * Hungarian
	 */
	langhuHU: string;
	/**
	 * Italian
	 */
	langitIT: string;
	/**
	 * Japanese
	 */
	langjaJP: string;
	/**
	 * Norwegian
	 */
	langnbNO: string;
	/**
	 * Dutch
	 */
	langnlNL: string;
	/**
	 * Polish
	 */
	langplPL: string;
	/**
	 * Portuguese (Brazil)
	 */
	langptBR: string;
	/**
	 * Portuguese (Portugal)
	 */
	langptPT: string;
	/**
	 * Russian
	 */
	langruRU: string;
	/**
	 * Thai
	 */
	langthTH: string;
	/**
	 * Turkish
	 */
	langtrTR: string;
	/**
	 * Ukranian
	 */
	langukUA: string;
	/**
	 * Vietnamese
	 */
	langviVN: string;
	/**
	 * Chinese (China)
	 */
	langzhCN: string;
	/**
	 * Chinese (Taiwan)
	 */
	langzhTW: string;
	/**
	 * Swedish
	 */
	langsvSE: string;
	/**
	 * Croatian
	 */
	langhrHR: string;
	/**
	 * Filipino (Philippines)
	 */
	langtlPH: string;
	/**
	 * None
	 */
	none: string;
	/**
	 * {0} users
	 */
	nrOfUsers: string;
	/**
	 * More
	 */
	more: string;
	/**
	 * Show all {0} languages
	 */
	showAllLanguages: string;
	/**
	 * Anyone
	 */
	anyone: string;
	/**
	 * Filters:
	 */
	filtersWithColon: string;
	/**
	 * Last edited by
	 */
	lastEditedByHeader: string;
	/**
	 * View Details
	 */
	viewDetails: string;
	/**
	 * Item has been set as Featured
	 */
	messageSetFeatured: string;
	/**
	 * Item has been unset as Featured
	 */
	messageUnsetFeatured: string;
	/**
	 * Added tags
	 */
	addedTags: string;
	/**
	 * Related Tags
	 */
	relatedTags: string;
	/**
	 * My pages
	 */
	myPagesFilter: string;
	/**
	 * My widgets
	 */
	myWidgetsFilter: string;
	/**
	 * Owned by
	 */
	ownedBy: string;
	/**
	 * Owned by {0}
	 */
	ownedByName: string;
	/**
	 * Published only
	 */
	publishedOnly: string;
	/**
	 * Standard only
	 */
	standardOnly: string;
	/**
	 * This request took too long. Please use filters to narrow down the search.
	 */
	catalogTimeout: string;
	/**
	 * Unable to complete in time
	 */
	catalogRequestCancelled: string;
	/**
	 * Unable to load data
	 */
	unableToLoad: string;
	/**
	 * Are you sure that you want to delete the filter '{0}'?
	 */
	confirmDeleteSavedCatalogView: string;
	/**
	 * Delete Filter
	 */
	deleteSavedCatalogView: string;
	/**
	 * Add Bookmarks
	 */
	addBookmarks: string;
	/**
	 * Edit Link
	 */
	editLink: string;
	/**
	 * All
	 */
	typeAll: string;
	/**
	 * Configure
	 */
	configure: string;
	/**
	 * Romanian
	 */
	langroRO: string;
	/**
	 * Export
	 */
	export: string;
	/**
	 * Export Options
	 */
	exportOptions: string;
	/**
	 * This page contains one or more published widgets.
	 */
	exportPageInfoPublished: string;
	/**
	 * You need to select how to export the page:
	 */
	exportPageInfoSelect: string;
	/**
	 * Convert to standard widgets.
	 */
	exportPageOptionConvertStandard: string;
	/**
	 * Convert to standard widgets with publish configuration.
	 */
	exportPageOptionConvert: string;
	/**
	 * Keep references to published widgets. This page can only be used in this environment.
	 */
	exportPageOptionKeep: string;
	/**
	 * Import
	 */
	import: string;
	/**
	 * Import Translations
	 */
	importTranslations: string;
	/**
	 * Translations imported
	 */
	importTranslationsSuccessTitle: string;
	/**
	 * The translations were successfully imported.
	 */
	importTranslationsSuccessMessage: string;
	/**
	 * Page published
	 */
	pagePublished: string;
	/**
	 * '{0}' was published to the catalog.
	 */
	pagePublishedMessage: string;
	/**
	 * Widget Copied
	 */
	widgetCopied: string;
	/**
	 * '{0}' was copied.
	 */
	widgetCopiedMessage: string;
	/**
	 * Widget Published
	 */
	widgetPublished: string;
	/**
	 * '{0}' was published to the catalog.
	 */
	widgetPublishedMessage: string;
	/**
	 * Owned by me
	 */
	ownedByMe: string;
	/**
	 * You have no bookmarks.
	 */
	noBookmarksMessage: string;
	/**
	 * Widget Reset Options
	 */
	restoreOptions: string;
	/**
	 * The widget is published with user settings enabled. You need to select how to reset the widget:
	 */
	restoreWidgetInfo: string;
	/**
	 * Remove all configuration and reset to default.
	 */
	restoreWidgetOptionStandardWidget: string;
	/**
	 * Remove the user settings and reset to Widget Catalog settings.
	 */
	restoreWidgetOptionUserSettings: string;
	/**
	 * Banner Widget Catalog
	 */
	bannerWidgetCatalog: string;
	/**
	 * Managing banner widgets is only possible in a 4 column layout.
	 */
	bannerEditDisabled1: string;
	/**
	 * Resize or zoom out your browser window to enable adding, resizing, reordering and removal of widgets in the banner widget area.
	 */
	bannerEditDisabled2: string;
	/**
	 * You can only add 4 banner widgets. Remove a widget from the banner area to be able to add another widget.
	 */
	maxBannerCountMessage: string;
	/**
	 * Unable to open the requested page
	 */
	unableToOpenPage: string;
	/**
	 * Verify the link used to open Homepages.
	 */
	drillbackErrorMessage: string;
	/**
	 * Banner enabled
	 */
	bannedEnabled: string;
	/**
	 * Yes (Banner only)
	 */
	bannerEnabledYesOnly: string;
	/**
	 * Featured
	 */
	featured: string;
	/**
	 * Screenshots
	 */
	screenshots: string;
	/**
	 * Has restrictions
	 */
	hasRestrictions: string;
	/**
	 * Groups
	 */
	groups: string;
	/**
	 * Roles
	 */
	roles: string;
	/**
	 * Users
	 */
	users: string;
	/**
	 * Clear all
	 */
	clearAll: string;
	/**
	 * Owner filter in Catalogs
	 */
	ownerFilterInCatalogs: string;
	/**
	 * Home
	 */
	home: string;
	/**
	 * Right-click the link below and select "Download Linked File" to download the page.
	 */
	pageDownloadMsg: string;
	/**
	 * Hidden in Catalog
	 */
	hiddenInCatalog: string;
	/**
	 * You can have a maximum of {0} widgets on a page
	 */
	maxWidgetsOnPage: string;
	/**
	 * Unable to add widget. You have reached the maximum number of allowed widgets on a page.
	 */
	maxWidgetsOnPageMessage: string;
	/**
	 * Unable to perform action. The page exceeds the maximum number of allowed widgets.
	 */
	exceedsMaxWidgetsOnPageCount: string;
	/**
	 * You are not authorized to edit the banner widget area.
	 */
	bannerEditUnauthorized: string;
	/**
	 * Edit banner widgets
	 */
	editBannerWidgets: string;
	/**
	 * Author
	 */
	author: string;
	/**
	 * Can Publish
	 */
	canPublish: string;
	/**
	 * A user with the HOMEPAGES-Administrator or HOMEPAGES-ContentAdministrator role will always have full permission to published content.
	 */
	roleAdminMessage: string;
	/**
	 * Import as
	 */
	importAs: string;
	/**
	 * Private page
	 */
	privatePage: string;
	/**
	 * Published page
	 */
	publishedPage: string;
	/**
	 * Show page link
	 */
	showPageLink: string;
	/**
	 * Page link title
	 */
	pageLinkTitle: string;
	/**
	 * Page link URL
	 */
	pageLinkUrl: string;
	/**
	 * Display restricted widgets on a page
	 */
	enableRestrictedWidgetsOnPage: string;
	/**
	 * Details
	 */
	details: string;
	/**
	 * The widget is unavailable since it has been deleted from the Widget Catalog.
	 */
	widgetUnavailableDeleted: string;
	/**
	 * The widget is unavailable since the widget it is based on has been deleted from the Widget Catalog.
	 */
	widgetUnavailableParentDeleted: string;
	/**
	 * The widget is unavailable since you are not authorized to view the widget it is based on.
	 */
	widgetUnavailableParentUnathorized: string;
	/**
	 * The widget is unavailable since you are not authorized to view the widget.
	 */
	widgetUnavailableUnathorized: string;
	/**
	 * Drop banner widget
	 */
	dropBanner: string;
	/**
	 * Maximum size
	 */
	maxSize: string;
	/**
	 * Paste Banner Widget
	 */
	pasteBannerWidget: string;
	/**
	 * Standard size
	 */
	standardSize: string;
	/**
	 * Bulgarian
	 */
	langbgBG: string;
	/**
	 * Estonian
	 */
	langetEE: string;
	/**
	 * French (Canada)
	 */
	langfrCA: string;
	/**
	 * Hindi
	 */
	langhiIN: string;
	/**
	 * Korean
	 */
	langkoKR: string;
	/**
	 * Lithuanian
	 */
	langltLT: string;
	/**
	 * Latvian
	 */
	langlvLV: string;
	/**
	 * Slovak
	 */
	langskSK: string;
	/**
	 * Slovenian
	 */
	langslSI: string;
	/**
	 * View and Publish pages for Infor Go
	 */
	mobilePages: string;
	/**
	 * View and Publish widgets for Infor Go
	 */
	mobileWidgets: string;
	/**
	 * Select to allow the widget to be available in Infor Go.
	 */
	publishMobileDescription: string;
	/**
	 * Enable for Infor Go
	 */
	publishMobileLabel: string;
	/**
	 * Switch to Homepages Administration
	 */
	switchToAdministration: string;
	/**
	 * Unable to get your user properties.
	 */
	messageUserAttributeError: string;
	/**
	 * Unable to get your distribution groups.
	 */
	messageUserDistributionGroupError: string;
	/**
	 * Page not complete
	 */
	headerPageNotComplete: string;
	/**
	 * Unable to evaluate permissions
	 */
	headerPermissionCheck: string;
	/**
	 * Secured content is not displayed.
	 */
	messageUnverifiedContent: string;
	/**
	 * Select a widget from the menu.
	 */
	selectWidget: string;
	/**
	 * No content available.
	 */
	noContent: string;
	/**
	 * Widgets
	 */
	widgets: string;
	/**
	 * This is the default language and no translation is needed.
	 */
	defaultLanguageDescription: string;
	/**
	 * Show announcements below page header
	 */
	showAnnouncements: string;
	/**
	 * Built for Homepages
	 */
	nativeBadgeTitle: string;
	/**
	 * This widget is specifically built for Homepages.
	 */
	nativeBadgeDescription: string;
	/**
	 * Early access
	 */
	earlyAccess: string;
	/**
	 * Early access widgets are beta software and not publicly released.
	 */
	earlyAccessDescription: string;
	/**
	 * Slide duration (seconds)
	 */
	slideDuration: string;
	/**
	 * Page '{0}' has been deleted.
	 */
	pageDeleted: string;
	/**
	 * Widget '{0}' has been deleted.
	 */
	widgetDeleted: string;
	/**
	 * Mobile widget
	 */
	mobileWidget: string;
	/**
	 * This widget is enabled for mobile devices.
	 */
	mobileWidgetDescription: string;
	/**
	 * Camera
	 */
	camera: string;
	/**
	 * Video Recorder
	 */
	videoRecorder: string;
	/**
	 * Audio Recorder
	 */
	audioRecorder: string;
	/**
	 * Select Source
	 */
	selectSource: string;
	/**
	 * Start Recording
	 */
	startRecording: string;
	/**
	 * Stop Recording
	 */
	stopRecording: string;
	/**
	 * Take Picture
	 */
	takePicture: string;
	/**
	 * Capture Device
	 */
	captureDevice: string;
	/**
	 * A media capture device, such as a camera or microphone
	 */
	captureDeviceTooltip: string;
	/**
	 * File System
	 */
	fileSystem: string;
	/**
	 * Select a media file from the file system
	 */
	fileSystemTooltip: string;
	/**
	 * Waiting for camera/microphone
	 */
	waitingForDevice: string;
	/**
	 * Homepages update
	 */
	homepagesUpdate: string;
	/**
	 * Homepages has been updated and needs to be reloaded. Click 'Yes' to reload now or 'No' to reload later.
	 */
	homepagesUpdateMessage: string;
	/**
	 * Animate announcements
	 */
	animateAnnouncements: string;
	/**
	 * Off
	 */
	off: string;
	/**
	 * Homepages is not performing at its best due to server response issues.
	 */
	systemMessageGeneric: string;
	/**
	 * Click {0} for more information.
	 */
	clickForMoreInformation: string;
	/**
	 * here
	 */
	readMoreLink: string;
	/**
	 * Unable to get your security roles.
	 */
	messageUserSecurityRolesError: string;
	/**
	 * Unable to communicate with ION APIs.
	 */
	messageIonApiError: string;
	/**
	 * Degraded Performance
	 */
	degradedPerformance: string;
	/**
	 * System Messages
	 */
	systemMessages: string;
	/**
	 * This widget has been deprecated and will soon be removed.
	 */
	deprecatedWidget: string;
	/**
	 * This widget is based on a widget that has been deprecated.
	 */
	deprecatedParentWidget: string;
	/**
	 * You need to stop using this widget.
	 */
	deprecatedAction: string;
	/**
	 * Unable to import page
	 */
	unableImportPage: string;
	/**
	 * The file is not a valid page. Please verify that the selected file is a JSON file that contains a page. Zip files are not supported.
	 */
	unableImportPageMessage: string;
	/**
	 * Don't show this announcement again
	 */
	dontShowAgain: string;
	/**
	 * Don't show these announcements again
	 */
	dontShowAgainMultiple: string;
	/**
	 * Critical Announcement
	 */
	criticalAnnouncement: string;
	/**
	 * Critical Announcements
	 */
	criticalAnnouncements: string;
	/**
	 * Next
	 */
	next: string;
	/**
	 * Previous
	 */
	previous: string;
	/**
	 * ION API Configuration is required.
	 */
	ionApiConfig: string;
	/**
	 * Unable to call ION API Endpoint.
	 */
	unableToCallEndpoint: string;
	/**
	 * Unknown
	 */
	unknown: string;
	/**
	 * Homepages is running in Safe mode and not all widgets will be loaded.
	 */
	safemodeMessage: string;
	/**
	 * Homepages is running in Safe mode and tenant widgets are not loaded.
	 */
	safemodeMessageTenant: string;
	/**
	 * Safe Mode
	 */
	safemode: string;
	/**
	 * Safe mode, widget not loaded.
	 */
	safemodeWidgetMessage: string;
	/**
	 * Context Application
	 */
	contextApplication: string;
	/**
	 * Announcements
	 */
	announcements: string;
	/**
	 * Select to allow the widget to be available in the Banner Widget Catalog.
	 */
	publishBannerDescription: string;
	/**
	 * Enable for banner area
	 */
	publishBannerLabel: string;
	/**
	 * Select to allow the widget to be available in the Widget Catalog.
	 */
	publishNormalDescription: string;
	/**
	 * Enable for normal usage
	 */
	publishNormalLabel: string;
	/**
	 * At least one target of the published widget has to be enabled.
	 */
	targetMissingMessage: string;
	/**
	 * Target
	 */
	selectTargetInfo: string;
	/**
	 * If enabled the page will be visible in Infor Go as long as the setting to allow pages in Infor Go is also enabled.
	 */
	publishMobilePageDescription: string;
	/**
	 * Visible in Infor Go
	 */
	visibleMobile: string;
}
