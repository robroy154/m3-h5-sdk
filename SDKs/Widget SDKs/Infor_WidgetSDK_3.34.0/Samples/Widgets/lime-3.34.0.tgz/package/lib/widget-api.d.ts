/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="jquery" />
/// <reference types="jquery" />
import { InjectionToken } from "@angular/core";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
/**
 * Represents configuration data for an application in Ming.le.
 *
 * @since 1.0
 */
export interface IApplication {
    /**
     * Gets a value that indicates if this application instance is the default one.
     */
    isDefault: boolean;
    /**
     * Gets the application version.
     */
    version: string;
    /**
     * Gets the product name.
     */
    productName: string;
    /**
     * Gets the tenant ID.
     */
    tenantId: string;
    /**
     * Gets the logical ID prefix.
     */
    logicalIdPrefix: string;
    /**
     * Get the logical ID for the application instance.
     */
    logicalId: string;
    /**
     * Gets the hostname.
     */
    hostname: string;
    /**
     * Get the URL context.
     */
    context: string;
    /**
     * Gets the port number.
     */
    port: number;
    /**
     * Gets a value that indicates if HTTPS should be used.
     */
    useHttps: boolean;
    /**
     * Gets the custom properties from Ming.le.
     * This is only available for widgets that have an application
     * dependency and has enableCustomProperties set in the manifest.
     * If not propterties are available customProperties is null.
     * @since 1.0.11
     */
    customProperties: ICustomProperties;
}
/**
 * Represents custom properties from the Application in Ming.le.
 */
export interface ICustomProperties {
    [key: string]: any;
}
/**
 * Represents localized language constants.
 * @since 1.0
 */
export interface ILanguage<T = null> extends ISharedLanguage {
    /**
     * Gets a language constant with the given ID.
     * @param id The language constant ID.
     * @return Gets the language constant or null if it does not exist.
     */
    get(id: T extends null ? string : keyof (T & ISharedLanguage)): string;
    /**
     * Formats a localization string by replacing `{0}` with the value parameter
     * @param text The string containing replacement variable `{0}`
     * @param value The value to be inserted at `{0}`
     * @return Returns the formatted text string.
     */
    format(text: string, value: string): string;
}
/**
 * Shared lime language constants.
 *
 * The following language constants will always be available to use from the widget.
 * Constants listed here does not have to be specified & localized in the widget manifest.
 */
interface ISharedLanguage {
    /**
     * OK
     */
    ok: string;
    /**
     * Cancel
     */
    cancel: string;
    /**
     * Yes
     */
    yes: string;
    /**
     * No
     */
    no: string;
    /**
     * Refresh
     */
    refresh: string;
    /**
     * Add
     */
    add: string;
    /**
     * Save
     */
    save: string;
    /**
     * Delete
     */
    delete: string;
    /**
     * Name
     */
    name: string;
    /**
     * Url
     */
    url: string;
    /**
     * Edit
     */
    edit: string;
    /**
     * Translations
     * @since 1.0.22
     */
    translations: string;
}
/**
 * Represents an item in the map with environment information returned by
 * the Companyon client function getEnvironmentInformation.
 */
export interface EnvironmentInfo {
    LogicalId: string;
    ApplicationName: string;
    DisplayName: string;
    ApplicationVersion: string;
    IconUrl: string;
}
/**
 * Represents the map with environment information returned by
 * the Companyon client function getEnvironmentInformation.
 */
export interface EnvironmentInfoMap {
    [key: string]: EnvironmentInfo;
}
/**
 * Options for {@link IWidgetContext.showBadge}. The count value must be a number between 0 and 99.
 *
 * @since 3.8.0
 */
export interface IBadgeOptions {
    count: number;
    type?: BadgeType;
}
/**
 * Badge type controlling the background color of the badge.
 *
 * @since 3.8.0
 */
export declare enum BadgeType {
    Info = 0,
    Alert = 1,
    Error = 2,
    Good = 3
}
/**
 * Options for {@link IWidgetContext.setEmptyState}.
 *
 * @since 3.11.0
 */
export interface IEmptyStateOptions {
    title: string;
    icon: EmptyStateIcon;
    description?: string;
    button?: IEmptyStateButtonOptions;
}
/**
 * Options for {@link IWidgetContext.trackEvent}
 *
 * @since 3.11.0
 */
export interface ITrackEventOptions {
    /**
     * Name of the event, e.g "Add Item", "Save", "Launch Drillback".
     */
    name: string;
    type: TrackEventType;
}
export declare enum TrackEventType {
    Click = "click"
}
export interface ITrackViewOptions {
    /**
     * Name of the view, e.g "Home", "Settings", "Details".
     */
    name: string;
}
/**
 * Options for the button in the empty state message shown by {@link IWidgetContext.setEmptyState}.
 *
 * @since 3.11.0
 */
export interface IEmptyStateButtonOptions {
    text: string;
    click?: Function;
}
/**
 * Icon to be used in the empty state message shown by {@link IWidgetContext.setEmptyState}.
 *
 * @since 3.11.0
 */
export declare enum EmptyStateIcon {
    ErrorLoading = "empty-error-loading",
    Generic = "empty-generic",
    NewProject = "empty-new-project",
    NoAlerts = "empty-no-alerts",
    NoAnalytics = "empty-no-analytics",
    NoBudget = "empty-no-budget",
    NoData = "empty-no-data",
    NoEvents = "empty-no-events",
    NoNotes = "empty-no-notes",
    NoOrders = "empty-no-orders",
    NoTasks = "empty-no-tasks",
    NoUsers = "empty-no-users",
    SearchData = "empty-search-data"
}
/**
 * Defines sources for messages.
 * The "default" message source is used for normal messages.
 * The "push" message source is used for push notifications.
 * Note that Push notifications are only supported in Portal, which can be checked with widgetContext.isPortal().
 *
 * @since 3.10.0
 */
type MessageSource = "default" | "push";
/**
 * Options used to register for messages.
 *
 * @since 3.10.0
 */
export interface IMessageOptions {
    /**
     * The message type.
     * This property is mandatory.
     */
    messageType: string;
    /**
     * An optional message namespace.
     * A unique namespace will be automatically generated when necessary if not provided.
     */
    namespace?: string;
    /**
     * An optional message source.
     * This property is mandatory when subscribing to push notifications.
     * Note that Push notifications are only supported in Portal, which can be checked with widgetContext.isPortal().
     */
    source?: MessageSource;
    /**
     * An application name.
     * This property should only be used for push notifications and in that case it is mandatory.
     */
    application?: string;
    /**
     * A context ID.
     * Used for push notifications.
     */
    contextId?: string;
}
/**
 * Represents a widget module.
 *
 * A widget module must implement a widget factory function called widgetFactory.
 * The function signature of the widget factory function is defined in this interface.
 * @since 1.0
 */
export interface IWidgetModule {
    /**
     * Creates a new widget instance.
     *
     * @param context The widget context.
     * @returns An object representing the widget instance.
     */
    widgetFactory(context: IWidgetContext): IWidgetInstance;
}
/**
 * Represents a widget module.
 *
 * A widget module must implement a widget factory function called widgetFactory.
 * The function signature of the widget factory function is defined in this interface.
 * @since 1.0.17
 */
export interface IWidgetModule2 extends IWidgetModule {
}
/**
 * Defines widget states.
 * @since 1.0
 */
export declare class WidgetState {
    /**
     * Running state.
     *
     * The running state is the default widget state.
     */
    static running: string;
    /**
     * Busy state.
     *
     * The busy state can be used to indicate that the widget is busy performing an operation
     * such as a server request.
     */
    static busy: string;
    /**
     * Error state.
     *
     * The error state indicates that the widget is broken in some way and is not functioning properly.
     * There could be different reasons for this such as missing settings
     * or that a backend service cannot be reached for example.
     */
    static error: string;
}
/**
 * Represents a widget activation or deactivation.
 * @since 1.0
 */
export interface IWidgetActivationArg {
    /**
     * Gets the type of activation.
     *
     * Activation types are defined in {@link WidgetActivationType}.
     */
    type: string;
    /**
     * Gets a value that indicates if the widget is new.
     *
     * A widget is considered to be new if it has been added from the widget library.
     */
    isNew?: boolean;
}
/**
 * Represents a widget destroy event.
 *
 * @since 1.0.28
 */
export interface IWidgetDestroyArg {
}
/**
 * Represents the widget settings close event.
 *
 * @since 1.0
 */
export interface IWidgetSettingsCloseArg {
    /**
     * Gets a value that indicates if the widget settings was saved.
     *
     * If the value is false the settings were cancelled.
     */
    isSave: boolean;
}
/**
 * Defines widget activation and deactivation types.
 *
 * The activation types indicates what caused a widget to be activated or deactivated.
 * Most types can be used for both activation and deactivation but close for example can only be used in deactivation.
 *
 * @since 1.0
 */
export declare class WidgetActivationType {
    /**
     * The widget visibility has been changed.
     */
    static visibility: string;
    /**
     * The "close" type has been deprecated since it was never raised.
     * If it was raised it would only happen just before the widget is destroyed which serves no purpose.
     *
     * Usage is deprected from version 2.0.0 and the property may be removed in future versions.
     *
     * @deprecated
     */
    static close: string;
    /**
     * The widget settings dialog has been opened or closed.
     */
    static settings: string;
    /**
     * The widget has entered or exited edit mode.
     */
    static edit: string;
}
/**
 * Represents the configuration for a widget implemented using Angular.
 *
 * When this configuration is used the framework will create the widget UI using an Angular module and
 * a component type or a component selector.
 *
 * The widget factory should not modify the parent DOM element directly when IAngularWidgetConfig is used.
 *
 * @since 1.0
 */
export interface IAngularWidgetConfig {
    /**
     * Gets or sets an Angular module type that has at least one component.
     *
     * This property is mandatory for a JIT widget, but optional for a widget settings component.
     */
    moduleType?: any;
    /**
     * Gets or sets the Angular AOT module factory.
     *
     * This property is mandatory for an AOT widget.
     * @since 1.0.22
     */
    moduleFactory?: any;
    /**
     * Gets or sets an Angular component type used to find the Angular component factory for the widget component.
     */
    componentType?: any;
}
/**
 * Represents the configuration for a widget implemented using Angular.
 *
 * When this configuration is used the framework will create the widget UI using an Angular module and
 * a component type or a component selector.
 *
 * The widget factory should not modify the parent DOM element directly when IAngularWidgetConfig2 is used.
 *
 * @since 1.0.17
 */
export interface IAngularWidgetConfig2 extends IAngularWidgetConfig {
}
/**
 * Represents the configuration for a widget implemented using web components.
 *
 * When this configuration is used the framework will register and create
 * the element for the widget using a component type.
 *
 * The widget factory should not modify the parent DOM element directly when IWebComponentWidgetConfig is used.
 *
 * @since 3.33.0
 */
export interface IWebComponentWidgetConfig {
    /**
     * Gets or sets a web component type used to create the widget component.
     */
    componentType?: CustomElementConstructor & {
        new (...params: any[]): IWidgetComponent;
    };
}
/**
 * Represents a custom widget action.
 *
 * Custom widget action will be displayed in the widget menu.
 *
 * @since 1.0
 */
export interface IWidgetAction {
    /**
     * Gets or sets the text to display for the action.
     */
    text?: string;
    /**
     * Gets or sets a function that will be called when the action is executed by the user.
     */
    execute?: Function;
    /**
     * Gets or sets a value that indicates if the action is enabled or not.
     *
     * The default value is true.
     */
    isEnabled?: boolean;
    /**
     * Gets or sets a value that indicates if the action should be available
     * even if the widget is not configured.
     *
     * Actions are normally not available when a widget that requires configuration is not configured.
     * This property can be used to override this behavior for specific actions that can still be used
     * when the widget is not configured.
     *
     * The default value is false.
     *
     * @since 1.0.34
     */
    isEnabledNotConfigured?: boolean;
    /**
     * Gets or sets a value that indicates if the action is visible or not.
     *
     * The default value is true.
     */
    isVisible?: boolean;
    /**
     * Gets or sets a value that indicates if the action represents a separator or not.
     *
     * The default value is false.
     */
    isSeparator?: boolean;
    /**
     * Gets or sets a value that indicates if the action represents a submenu or not.
     *
     * The default value is false.
     *
     * @since 1.0.13
     */
    isSubmenu?: boolean;
    /**
     * Gets or sets a value that indicates if the action is primary and should be shown in the widget header.
     * If an action is primary, it has to be set on the widget instance before it's returned from the widget factory
     */
    isPrimary?: boolean;
    /**
     * Gets or sets a SoHo Xi icon name to use if it is a primary widget header action (ex. "#icon-delete").
     *
     */
    standardIconName?: string;
    /**
     * Gets or sets a custom svg icon name to use if it is a primary widget header action.
     *
     */
    customIconName?: string;
    /**
     * Gets or sets submenu items to the widget menu, use with isSubmenu.
     *
     * @since 1.0.13
     */
    submenuItems?: IWidgetAction[];
}
/**
 * A message type used to display inline widget messages.
 *
 * @since 1.0
 */
export interface IWidgetMessage {
    /**
     * The plain text message to display
     */
    message: string;
    /**
     * Type defines severity and how the message looks like.
     */
    type: WidgetMessageType;
    /**
     * Text used for a clickable link. The link will only show if onLinkClick is set as well.
     * @since 3.10.0
     */
    linkText?: string;
    /**
     * Override logic for the X (Close) button on the message
     * If used, the message needs to be removed using IWidgetContext.removeWidgetMessage().
     */
    onClose?: () => void;
    /**
     * Callback when the link is clicked, if set.
     * @since 3.10.0
     */
    onLinkClick?: () => void;
}
/**
 * A widget status.
 *
 * @since 2.5.0
 */
export interface IWidgetStatus {
    message?: string;
    /**
     * A number between 1 and 99.
     */
    count?: number;
}
/**
 * Used to define severity in IWidgetMessage.
 *
 * @since 1.0
 */
export declare enum WidgetMessageType {
    /**
     * Information message.
     */
    Info = 0,
    /**
     * Alert message.
     */
    Alert = 1,
    /**
     * Error message.
     */
    Error = 2,
    /**
     * Success message.
     * @since 3.10.0
     */
    Success = 3
}
/**
 * Represents a widget instance.
 *
 * An object of this type should be returned by the widgetFactory function in the widget module.
 * All properties in this interface are optional however so it is OK to return an empty object.
 *
 * A widget implementation may choose which properties to set depending on what types of callbacks the widget requires.
 *
 * @since 1.0
 */
export declare abstract class IWidgetInstance {
    /**
     * Optional event function that will be called when the widget is activated.
     *
     * A widget is activated when it is shown after being hidden,
     * the settings dialog is closed or the widget is no longer in edit mode.
     *
     * Note that the activated function is not called when a widget is created.
     * A newly created widget is always considered activated.
     * The activated function will only be called after the widget has been deactivated at least once.
     */
    abstract activated?: (arg: IWidgetActivationArg) => void;
    /**
     * Optional event function that will be called when the widget is deactivated.
     *
     * A widget is deactivated when it is not visible, the settings dialog is open or the widget is in edit mode.
     */
    abstract deactivated?: (arg: IWidgetActivationArg) => void;
    /**
     * Optional event function that will be called when the widget is destroyed.
     *
     * This function should be implemented by widgets that need to do special cleanup such
     * as removing IFrames etc. Most Angular widgets can just rely on the OnDestroy interface and do not
     * need to implement this function.
     *
     * @since 1.0.28
     */
    abstract destroy?: (arg: IWidgetDestroyArg) => void;
    /**
     * Optional event function that will be called before the settings dialog for a widget is opened.
     */
    abstract settingsOpening?: (arg: IWidgetSettingsArg) => void;
    /**
     * Optional event function that will be called when settings are saved for a widget.
     */
    abstract settingsSaved?: (arg: IWidgetSettingsArg) => void;
    /**
     * Optional event function that will be called when the widget is restored.
     * Restore is available in the widget menu and restore the widget to the default configuration.
     * If the title are set from api it will not be restored but the widget can choose to do so by adding
     * this restore function.
     */
    abstract restored?: (arg: IWidgetRestoreArg) => void;
    /**
     * Optional event function that will be called when a user has clicked the refresh button or the refresh menu item.
     *
     * This functionality requires that the enableRefresh manifest property is set to true.
     *
     * @since 1.0.21
     */
    abstract refreshed?: (arg: IWidgetRefreshArg) => void;
    /**
     * Optional event function that will be called when the parent page color is changed.
     *
     * A Banner widget may register this callback to be able to update styles based on the new banner container color
     * Function is called with the new color string as parameter, ex. "#0E5B52"
     * Function will not be called for widgets not used as Banners
     */
    abstract bannerBackgroundChanged?: (newBackgroundColor: string) => void;
    /**
     * Optional function that gets settings metadata for a widget with dynamic settings metadata.
     *
     * If this function returns an array with at least one item the existing settings metadata will be overridden.
     * This function will be called by the framework when settings metadata is required such as when opening the
     * settings dialog or publishing a widget. A widget that defines settings in the manifest should normally not
     * implement this function.
     *
     * @returns An array with metadata for each setting.
     */
    abstract getMetadata?: () => IWidgetSettingMetadata[];
    /**
     * Optional function that gets settings metadata asynchronously for a widget with dynamic settings metadata.
     *
     * This fuction is similar to the getMetadata function but allows the widget to call a server to get
     * the settings metadata. The Homepages UI will be blocked by a progress indicator while the widget loads the
     * settings metadata.
     *
     * @returns An Observable for the settings metadata.
     */
    abstract getMetadataAsync?: () => Observable<IWidgetSettingMetadata[]>;
    /**
     * Optional function that gets if the widget is properly configured
     *
     * This function may be implemented if the "requiresConfig" flag is set to true in the Manifest.
     * If not implemented, the configuration check is made by the Framework where the configuration is deemed valid if
     * at least one setting has an assigned value.
     * This function can be used if more advanced validation criterias are required.
     *
     * Function will get called when the widget is loaded, reset to default or when Configuration dialog is saved,
     * if requiresConfig flag is set to true in the Manifest
     *
     * @returns A boolean indicating if the widget is properly configured or not
     */
    abstract isConfigured?: (settings: IWidgetSettings) => boolean;
    /**
     * Optional function that will be called when the button in the empty state is clicked.
     * @since 1.0.32
     */
    abstract emptyConfigClicked?: () => void;
    /**
     * Optional event function that will be called when the widget enters edit mode.
     */
    abstract editing?: () => void;
    /**
     * Optional event function that will be called when the widget exits edit mode.
     */
    abstract edited?: () => void;
    /**
     * Gets or sets an optional event function that will be called when the widget enters publish widget mode.
     */
    abstract publishing?: () => void;
    /**
     * Gets or sets an optional configuration for a widget implemented using Angular.
     *
     * This property should not be used if content is added to the element property in IWidgetContext.
     */
    abstract angularConfig?: IAngularWidgetConfig;
    /**
     * Gets or sets an optional configuration for a widget implemented using web components.
     * This property is mandatory for widgets that specify framework as "webcomponent" in the widget manifest.
     *
     * @since 3.33.0
     */
    abstract webComponentConfig?: IWebComponentWidgetConfig;
    /**
     * Gets or sets an optional factory function for creating a custom settings UI.
     *
     * Set this function to create custom content in the widget settings dialog.
     * The custom content should contain everything except the save and cancel buttons that are are handled
     * by the framework. The custom dialog content can be created with Angular or with jQuery.
     *
     * To hande the complete dialog use the settingsOpening event and cancel the settings and then open your own dialog.
     */
    abstract widgetSettingsFactory?: (context: IWidgetSettingsContext) => IWidgetSettingsInstance;
    /**
     * Gets or sets an optional array of custom widget actions that will be displayed in the widget menu.
     */
    abstract actions?: IWidgetAction[];
    /**
     * Optional function to return the IFrame Name for Hybrid widgets that use IFrame to show the UI and that would like
     * to receive inforBusinessCOntext messages. This function must be
     * implemented for Context Application Widgets that subscribes to context messages to provide easy access to the
     * IFrame for message delivery but it optional for other types of widgets.
     * @since 2.5.0
     */
    abstract getIFrameName?: () => string;
    static ɵfac: i0.ɵɵFactoryDeclaration<IWidgetInstance, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<IWidgetInstance>;
}
/**
 * Represents a widget instance.
 *
 * An object of this type should be returned by the widgetFactory function in the widget module.
 * Most properties in this interface are optional so it is OK to return an empty object for jQuery widgets
 * but the angularConfig is required for Angular widgets.
 *
 * A widget implementation may choose which properties to set depending on what types of callbacks the widget requires.
 *
 * @since 1.0.17
 */
export interface IWidgetInstance2 extends IWidgetInstance {
}
/**
 * Represent event arguments for the restored event function defined in {@link IWidgetInstance}.
 * Needs to be implemented if title is set via setTitle by the widget itself.
 *
 * This event is called after the framework has updated the settings.
 *
 * @since 1.0.12
 */
export interface IWidgetRestoreArg {
    /**
     * Remove any user settings from a published widget and restore the widget to the configuration it
     * has when it is first added from the catalog.
     */
    userSettings?: boolean;
    /**
     * Remove any configuration and restore to the default values from the standard widget.
     */
    settings?: boolean;
}
/**
 * Represent event arguments for the refreshed event function defined in {@link IWidgetInstance}.
 *
 * @since 1.0.21
 */
export interface IWidgetRefreshArg {
    /**
     * Gets the time when the last refresh event occurred expressed in milliseconds since the epoch (new Date().getTime()).
     * The value will be zero for the first refresh.
     */
    lastRefresh: number;
}
/**
 * Represent options for the settingsOpening and settingsSaved event functions defined in {@link IWidgetInstance}.
 *
 * @since 1.0
 */
export interface IWidgetSettingsArg {
    /**
     * Gets the widget settings.
     *
     * These are the same settings that are available on the {@link IWidgetContext}.
     */
    settings: IWidgetSettings;
    /**
     * Gets an optional data parameter.
     *
     * This property will only be available if the settings were opened using
     * the showSettings function on the {@link IWidgetContext} and a data parameter was set on the {@link IShowSettingsOptions}.
     */
    data?: any;
    /**
     * Gets a value that indicates that the standard settings dialog should be cancelled.
     *
     * The default value is false.
     *
     * This property can be set to true by widgets that have a completely custom settings UI including dialog management.
     */
    cancel?: boolean;
}
/**
 * Represents metadata for a widget setting.
 *
 * @since 1.0
 */
export interface IWidgetSettingMetadata {
    /**
     * Gets or sets the name of the setting.
     */
    name: string;
    type?: string;
    /**
     * Gets or sets the default value for the setting if not changed.
     */
    defaultValue?: string;
    /**
     * Gets or sets the ID of a label to translate.
     * If no translation is found the text will be used. Label for settings UI.
     */
    labelId?: string;
    /**
     * Gets or sets a value that indicates if the setting should be visible in the widget settings UI.
     * The default value is true. The value of this property will not have any effect if the isHidden property
     * is set to true.
     */
    isVisible?: boolean;
    /**
     * Gets or sets a value that indicates if the setting is hidden. The default value is false.
     * A setting that is hidden will always be hidden and setting the isVisible property will not have any effect.
     * When a setting is hidden it will not be possible to configure the setting visibility when publishing a widget.
     */
    isHidden?: boolean;
    /**
     * Gets or sets a value that indicates if the setting is enabled. The default value is true.
     * A setting might be disabled for a published widget or a widget on a published page.
     * Settings will always be enabled on a private page.
     */
    isEnabled?: boolean;
    /**
     * Gets or sets a value that indicates if the setting is enabled when publishing/published. The default value is true.
     *
     * @since 1.0.19
     */
    isEnabledWhenPublished?: boolean;
    /**
     * Gets or sets a value that indicates if the setting is mandatory. The default value is false.
     *
     * @since 1.0.21
     */
    isMandatory?: boolean;
    /**
     * Gets or sets a value that indicates if the setting is intendend as an end user setting. The default value is false.
     *
     * This property can be used for non-critical settings that the end user should be allowed to change in
     * most cases. Examples of this could be the default sorting order or filter in a list.
     *
     * Setting this property to true will be a hint to the framework but what effect it actually has
     * depends on the context. There are always be ways to override this behavior, when publishing a widget
     * for example, so there is no guarantee that a user will be able to change a setting even if this property
     * is set to true.
     *
     * @since 2.0.5
     */
    isUser?: boolean;
    /**
     * Gets or sets the maximum length for string values.
     */
    maxLength?: number;
    /**
     * Gets or sets an array of values for a selector type setting.
     */
    values?: IValueItem[];
}
/**
 * Represents the different types of widget settings.
 * All except the object type are supported in the metadata settings UI.
 *
 * @since 1.0
 */
export declare class WidgetSettingsType {
    static stringType: string;
    static numberType: string;
    static booleanType: string;
    static selectorType: string;
    static radioType: string;
    static objectType: string;
}
/**
 * An entity optimized for usage with the autocomplete control.
 * @since 1.0
 */
export interface IAutocompleteEntity {
    /**
     * The visible text.
     */
    label: string;
    /**
     * An optional value of the item.
     */
    value?: any;
    /**
     * An optional secondary string.
     */
    info?: string;
    /**
     * Additional optional property to separate different types.
     */
    type?: any;
}
/**
 * Represents an item for a selector setting.
 *
 * @since 1.0
 */
export interface IValueItem {
    /**
     * Gets or sets a language constant ID for the item text.
     *
     * Use this property or the text property, not both.
     */
    textId?: string;
    /**
     * Gets or sets the item text.
     *
     * Use this property or the textId property, not both.
     */
    text?: string;
    /**
     * Gets or sets the value.
     */
    value: string;
}
/**
 * Represents options for a widget settings dialog.
 *
 * @since 1.0
 */
export interface IShowSettingsOptions {
    /**
     * Gets or sets an optional data object.
     */
    data?: any;
}
/**
 * Represents options for getting an application view URL.
 *
 * @since 1.0
 */
export interface IViewUrlOptions {
    /**
     * Gets or sets the view ID.
     */
    viewId: string;
    /**
     * Gets or sets an optional application logical ID or logical ID prefix.
     *
     * If no value is specified the default application is used.
     */
    logicalId?: string;
    /**
     * Gets or sets a value that indicates if the URL template should be resolved by replacing values.
     *
     * The default value is true.
     * This property can be set to false to get the original URL template without replacing values.
     */
    resolve?: boolean;
}
/**
 * Options for IWidgetContext.interval
 *
 * @since 3.9.0
 */
export interface IIntervalOptions {
    /**
     * Period, in milliseconds
     *
     * NOTE: Setting a number under 1000 (1 second) will throw an error.
     *
     * @since 3.9.0
     */
    period: number;
}
/**
 * Defines ION API constants.
 *
 * @since 1.0.17
 */
export declare class IonApiConstants {
    /**
     * Gets the name of the header used to specify the platform that is calling ION API.
     * The header value should always be "homepages", specified in the platformHeaderValue property.
     */
    static platformHeaderName: string;
    /**
     * Gets the ION API platform header value to use in Homepages.
     */
    static platformHeaderValue: string;
    /**
     * Gets the name of the header used to specify the source that is calling ION API.
     * The value should be the standard widget ID of the calling widget.
     */
    static sourceHeaderName: string;
}
/**
 * Represents options used when getting an IonApiContext.
 *
 * @since 1.0
 */
export interface IIonApiOptions {
    /**
     * Gets or sets an optional value that indicates if the ION API token should be refreshed or not.
     *
     * The default value is false. This property should only be set to true if the current token is invalid.
     * An ION API call will return HTTP 401 when the token is invalid.
     */
    refresh?: boolean;
}
/**
 * Represents options when executing an ION API HTTP request.
 *
 * Note that the url property should be set to a relative URL (absolute URLs are not supported).
 * The ION API base URL will be automatically prepended to the url property to create an absolute URL before
 * the request is executed.
 *
 * The OAuth authorization header will also be automatically added to the headers map.
 */
export interface IIonApiRequestOptions {
    /**
     * Gets or sets the HTTP method ('GET', 'POST', etc).
     */
    method: string;
    /**
     * Gets or sets the absolute or relative URL of the resource that is being requested.
     */
    url: string;
    /**
     * Gets or sets a map of strings which will be turned to ?key1=value1&key2=value2 after the url.
     */
    params?: any;
    /**
     * Gets or sets the data to be sent as the request message data `{string|Object}`.
     */
    data?: any;
    /**
     * Gets or sets the response type ('arraybuffer'|'blob'|'json'|'text').
     */
    responseType?: string;
    /**
     * Gets or sets optional HTTP headers.
     */
    headers?: {
        [requestType: string]: any;
    };
    /**
     * If caching is enabled.
     */
    cache?: boolean;
    /**
     * Gets or sets an optional value that indicates if a request should be retried if the ION API returns
     * a 401 HTTP response code.
     *
     * A 401 response code usually means that the OAuth token has expired and must be renewed. A 401 response code
     * could also mean that the user cannot be authorized at all.
     *
     * The default value is true.
     */
    ionApiRetry?: boolean;
    /**
     * Gets or sets a value that indicates if the request should be executed using a web worker.
     * The default value is false.
     *
     * @since  1.0.23
     */
    enableWorker?: boolean;
    /**
     * Gets or sets a value that indicates if the base URL should automatically have tenant added to the URL.
     * Only enable for calls to ION API Metdata service where the context root should not be the tenantid as
     * the tenantid is included later in the URL. For all standard ION API calls this property should be false.
     * The default value is false.
     * @since  nextVersion
     */
    enableNonTenantUrl?: boolean;
}
/**
 * Represents the response from an ION API HTTP request.
 *
 * @since 1.0.17
 */
export interface IIonApiResponse<T> {
    data: T;
    status: number;
    statusText: string;
}
/**
 * Represents the ION API context which contains values required when making ION API HTTP requests.
 *
 * To call an ION API a client must construct an absolute URL using the ION API base URL returned by
 * the getUrl function. Each HTTP request to an ION API must include an authorization header with
 * an OAuth 2.0 bearer token. The authorization header name and value can be retrieved using the
 * getHeaderName and getHeaderValue functions. It is also possible to get just the OAuth token using
 * the getToken function.
 *
 * Refer to the documentation for the API used to make HTTP calls for information about how to add
 * a header to a request.
 *
 * Authorization header example: "Authorization: Bearer yg06wrbaBoutluM8Rdb9v4YH0ztx"
 *
 * @since 1.0
 */
export interface IIonApiContext {
    /**
     * Gets the ION API base URL.
     * @return a URL
     */
    getUrl(): string;
    /**
     * Gets an OAUth token.
     *
     * The OAuth token must be provided in an Authorization header for each ION API call.
     * @return an OAuth token
     */
    getToken(): string;
    /**
     * Gets the name of the HTTP Authorization header (Authorization).
     * @return the authorization header name
     */
    getHeaderName(): string;
    /**
     * Gets the value for the HTTP authorization header including the OAuth token.
     *
     * The returned value is an Authorization Request Header Field for an OAuth 2.0 Bearar Token
     * according to https://tools.ietf.org/html/rfc6750#section-2.1
     *
     * Example return value: "Bearer yg06wrbaBoutluM8Rdb9v4YH0ztx"
     *
     * @return the authorization header value
     */
    getHeaderValue(): string;
    /**
     * Gets the ION API customer context.
     *
     * The ION API customer context must be used in the ION API URL for applications that are not Infor provisioned.
     * Applications that are provisioned in the cloud and is using the standard ION API suite name should not add
     * the customer context to the ION API URL. In most other cases such as on-premise and when using
     * a non-standard ION API suite name the customer context must be added to the ION API URL. There are a
     * few exceptions to this for Infor Tech products that are always Infor provisioned both in cloud and on-premise.
     *
     * The default value for the ION API customer context is "CustomerApi" but the value can be configured
     * so it cannot be hardcoded.
     *
     * Example (M3 application with standard API suite provisioned in cloud):
     * https://ionapiserver:54321/ACME_AX1/M3/
     *
     * Example (Application with custom API suite in cloud or on-premise):
     * https://ionapiserver:54321/ACME_AX1/CustomerApi/MyApp/
     *
     * @returns The ION API customer context
     *
     * @since 1.0.1
     */
    getCustomerContext(): string;
}
/**
 * Options for calling the ION API meta data service to check for ION API registrations for the product
 * that you are using. Not all endpoints will be returned but this options object can be used to check for
 * existance of a suite or product.
 * @since 2.4
 */
export interface IIonApiInfoOptions {
    /**
     * The logical id prefix for a product. Will check for metadata based on the logicalId prefix.
     * Endpoint: `​/products​/{logicalIdPrefix}`
     *
     * Example: infor.m3
     */
    productLogicalId?: string;
    /**
     * The suite context. This is the ION API context.
     * Endpoint: `/apisuites/{suiteContext}`
     *
     * Exaxmple: M3, Mingle
     */
    suiteContext?: string;
}
/**
 * Metadata result object for calling ION API Metadata APIs. It can represent a product but also a suite.
 * @since 2.4
 */
export interface IIonApiInfo {
    /**
     * A list of products. If the list is empty there are no products.
     */
    ionApiProducts: IIonApiProduct[];
    /**
     * Indicates if there are products.
     */
    hasProducts: boolean;
    /**
     *  The type of suite or product, for example "INFORNONPROVISIONED" or "INFORPROVISIONED".
     */
    typeName?: string;
    /**
     * The error message that should be used when no product is found.
     * The string will be "ION API Configuration is required." in the user's language.
     * The message will only be returned when there are no products found.
     */
    configurationRequiredMessage?: string;
    /**
     * Error message potentially set by framework.
     */
    errorMessage?: string;
}
/**
 * Representation of metadata for a suite or product from ION API.
 * @since 2.4
 */
export interface IIonApiProduct {
    /**
     * Logical Id prefix without lid://
     */
    logicalIdPrefix: string;
    /**
     * Description.
     */
    description: string;
    /**
     * Name
     */
    name: string;
    /**
     * The suite context for example M3 for the M3 suite
     */
    suiteContext: string;
    /**
     * The type of product or suite. For example "INFORPROVISIONED" or "INFORNONPORVISIONED".
     */
    typeName: string;
}
/**
 * Represents version numbers for Homepages.
 *
 * @since 3.1.0
 */
export interface IVersionInfo {
    /**
     * Gets the full Homepages release version number.
     *
     * The version includes numbers for major, minor, release and build separated by dots.
     *
     * Example. 12.0.44.25
     */
    version: string;
    /**
     * Gets the Homepages release version number exluding the build number.
     *
     * The version includes numbers for major, minor, release separated by dots.
     *
     * Example. 12.0.44
     */
    releaseVersion: string;
    /**
     * Gets the Homepages display version number.
     *
     * The display version includes numbers for year and month separated by dash.
     *
     * Example: 2020-10
     */
    displayVersion: any;
    /**
     * Gets the Homepages client framework version number.
     *
     * The framework version follows semantic versioning with numbers for major, minor and patch separated by dots.
     * This version can be used to check if a specific client API is available in the framework.
     *
     * Example: 3.1.0
     */
    frameworkVersion: string;
}
/**
 * Represents the context for a widget in runtime.
 *
 * The context is received as a parameter to the widgetFactory function in the widget module.
 *
 * The context provides a widget instance with data, settings, the DOM element etc and
 * functions that can be used to interact with the framework.
 *
 * @since 1.0
 */
export declare abstract class IWidgetContext {
    /**
     * Gets a value that indicates if the widget is running in Portal.
     *
     * @since 3.10.0
     */
    abstract isPortal(): boolean;
    /**
     * Gets a value that indicates if the widget is running in Homepages.
     *
     * @since 3.10.0
     */
    abstract isHomepages(): boolean;
    /**
     * Gets the widget ID.
     *
     * This ID will be a either a standard widget ID or a published widget ID for a published widget.
     */
    abstract getId(): string;
    /**
     * Gets the widget settings.
     *
     * If the widget defines settings in the widget manifest the settings will contain default values when
     * a widget is added to a page. If a widget use ad-hoc settings or do not use settings at all the settings
     * object might be empty.
     */
    abstract getSettings(): IWidgetSettings;
    abstract getSettings<T>(): IWidgetSettings<T>;
    /**
     * Gets the widget language object for the current user language.
     * @return A language object.
     */
    abstract getLanguage(): ILanguage;
    abstract getLanguage<T extends ILanguage<T>>(): T;
    /**
     * Gets the widget DOM element wrapped in a JQuery object.
     *
     * A widget may add content to this element and for widgets not implemented using AngularJS
     * this is the only option for adding content.
     *
     * Note that a widget is only allowed to add content as children to this element.
     * A widget is not allowed to explicitly add elements to other parts of the DOM. The only exceptions
     * are when elements are added implicitly using modal dialogs, popups etc.
     *
     * AngularJS widgets may add compiled content to this element.
     * The angularContext property contains the the scope and the compile service required for compiling
     * AngularJS elements.
     *
     * AngularJS widgets that uses one of the template properties defined on the
     * angularContext property ({@link IAngularWidgetConfig}) in {@link IWidgetInstance} should ignore this property.
     * In this case the framework will add content to the element automatically.
     */
    abstract getElement(): JQuery;
    /**
     * Gets a URL to the widget folder or a resource in the wiget directory.
     *
     * A widget must use an API such as this to get the URL to the widget directory since the widget directory location
     * is an implementation detail that might change in future versions.
     *
     * **Example:**
     * var iconUrl = widgetContext.getUrl("images/icon.png");
     * var baseUrl = widgetContext.getUrl();
     *
     * @param path An optional relative path that will be appended to the widget directory URL.
     * If this parameter is omitted or is blank the URL to the widget directory will be returned.
     * @returns A URL to the widget directory or a resource in the wiget directory.
     */
    abstract getUrl(path?: string): string;
    /**
     * Get the device, which should primarily be used to access native features of the mobile device that is
     * running the widget.
     * @since 1.0.32
     */
    abstract getDevice(): Observable<IDevice>;
    /**
     * Gets an object with Homepages version numbers.
     *
     * @returns A version object.
     * @since 3.1.0
     */
    abstract getVersionInfo(): IVersionInfo;
    /**
     * Starts an interval similar to setInterval.
     * The interval will only be triggered while the widget is active,
     * and it will complete when the widget is destroyed.
     *
     * @since 3.9.0
     */
    abstract interval(options: IIntervalOptions): Observable<unknown>;
    /**
     * Gets a value that indicates if the widget is active.
     *
     * A widget is considered to be active if it is visible,
     * the settings dialog is not open and the widget is not in edit mode.
     *
     * @returns True if the widget is active.
     */
    abstract isActive(): boolean;
    /**
     * Gets a value that indicates if the widget is visible.
     *
     * A widget is considered to be visible if the widget is part of the current page.
     *
     * @returns True if the widget is visible.
     */
    abstract isVisible(): boolean;
    /**
     * Gets a value that indicates if the widget is a published widget or if the widget is on a published page.
     *
     * @returns True is the widget is pubished.
     */
    abstract isPublished(): boolean;
    /**
     * Gets a value that indicates if the widget is running in the development environment.
     */
    abstract isDev(): boolean;
    /**
     * Get a value that indicates if the widget is running in the banner part of a page.
     */
    abstract isBanner(): boolean;
    /**
     * Notifies the framework that the widget data has been changed and that the widget needs to be saved.
     *
     * This function can be used explicity save widget data or settings, only if settings are enabled.
     * There is no need to call this function when the widget settings dialog is used since the framework saves
     * automatically in that case. This function should only be used if the widget modifies data or settings
     * that the framework is not aware of.
     *
     * The widget data is saved as part of the current page and this is asynchronous so there is
     * no guarantee exactly when the data is saved. There might be a delay and frequent calls to this function might
     * not result in the same number of server calls.
     */
    abstract save(): void;
    /**
     * Sets the widget state and options.
     *
     * See {@link WidgetState}
     * See {@link BusyStateOptions}
     * @param state The new widget state.
     * @param options The widget state options.
     */
    abstract setState(state: string, options?: BusyStateOptions): void;
    /**
     * Gets the current widget state.
     *
     * See {@link WidgetState}
     *
     * @returns A widget state.
     */
    abstract getState(): string;
    /**
     * Gets the current widget title.
     *
     * @returns A widget title.
     */
    abstract getTitle(): string;
    /**
     * Gets the standard widget title as defined in the widget manifest.
     *
     * @returns A widget title.
     */
    abstract getStandardTitle(): string;
    /**
     * Gets a resolved widget title for a locked or unlocked title.
     *
     * This function is intended for widgets with a custom settings UI that want to support
     * locked titles in the same way as the standard metadata settings UI. When the widget title
     * is locked is should revert back to a default title which can be retrieved by calling this function with true.
     *
     * @param isTitleLocked True if the widget is locked.
     * @returns A widget title.
     * @since 1.0.2
     */
    abstract getResolvedTitle(isTitleLocked: boolean): string;
    /**
     * Sets the widget title.
     *
     * This function will override the default title or a title set by the user and
     * should only be used by special widgets where the title is dependent on the configuration or
     * the current data for example. If the widget is configured to have the same title as in the widget catalog
     * calling this method will have no effect.
     *
     * @param title The title to set.
     */
    abstract setTitle(title: string): void;
    /**
     * Resets the widget title so it reverts to the widget standardtitle.
     *
     * This function will revert all changes to the title. Should only be used by widgets which uses
     * the setTitle method and needs to revert the title to the definition standard title. If the widget is configured
     * to have the same title as in the widget catalog calling this method will have no effect.
     */
    abstract setStandardTitle(): void;
    /**
     * Enables or disables the possibility for the user to edit the widget title.
     * @param isEnabled True to enable title editing, False to disable.
     */
    abstract enableTitleEdit(isEnabled: boolean): void;
    /**
     * Gets a value that indicates if the user is allowed to edit the widget title.
     * @return True if title editing is enabled.
     */
    abstract isTitleEditEnabled(): boolean;
    /**
     * Gets a value that indicates if the widget title is currently locked.
     *
     * The widget title can be locked explicitly by the user or implicitly if the widget catalog
     * title is used for a published widget. The isTitleUnlockable function can be used to check if
     * the widget title can be unlocked. The title can also be locked using the setTitleLocked function.
     *
     * @returns True if the widget title is locked.
     */
    abstract isTitleLocked(): boolean;
    /**
     * Gets a value that indicates if the widget title can be unlocked.
     *
     * The widget title may not be possible to unlock if the widget catalog title is used for a published widget.
     * There may also be other reasons in future versions for why the widget title cannot be unlocked.
     *
     * @returns True if the widget title can be unlocked.
     */
    abstract isTitleUnlockable(): boolean;
    /**
     * Sets a value that indicates if the widget title should be locked or not.
     *
     * Note that calls to this function may be ignored if the widget catalog title is used for a published widget.
     * If the isTitleUnlockable function returns false calling this function will not have any effect.
     *
     * @param isLocked True to lock the title, false to unlock.
     */
    abstract setTitleLocked(isLocked: boolean): void;
    /**
     * Resolves a key by searching for the key in the following order:
     *
     * <ul>
     * <li>Widget Settings</li>
     * <li>Ad-hoc properties</li>
     * <li>Application configuration in Ming.le.</li>
     * </ul>
     *
     * A key can contain any of the following reserved prefixes (followed by .) for accessing the key directly
     * intead of using the search order:  widget, property, application. For example application.hostname
     * to get the hostname from the application's configuration.
     *
     * The key is case sensitive.
     *
     * Ad-hoc properties are defined by an administrator and can be useful if an installation has multiple links
     * to another on-premise system.
     *
     * This is only available if the widget has an application dependency defined in the Manifest
     * by specifying applicationLogicalId and applicationVersion.
     *
     * Note that for this to work with Ming.le configuration when using the Test Container, configuration data
     * needs to be provided by setting dev-configuration. See the developers guide or sample for more information.
     *
     * @param Key is the name of the value that should be resolved. It might contain a prefix(e.g. application.xxxx)
     * @return The value for the key or null if no value is found.
     */
    abstract resolve(key: string): string;
    /**
     * Resolves a URL template with replacement variables in curly brachets.
     *
     * For example: `http://{application.host}:{application.port}/root/{resource}?view={selectedView}`
     *
     * By default all replacement variables will be encoded with the encodeURI function.
     *
     * It is possible to add extra information in the expression to specify the encoding method that should be used and
     * a default value if the value is null or empty.
     *
     * For example: `{selectedView|encode:component}`
     *
     * The encode takes three different options:
     * - none - no encoding `{selectedView|encode:none}`
     * - uri - encodeURI `{selectedView|encode:uri}`
     * - component - encodeURIComponent `{selectedView|encode:component}`
     *
     * Another option is to specify a default value, for example: `{selectedView|default:standard}`. If the selectedView
     * cannot be resolved standard would be the fallback.
     *
     * Note that for this to work with Ming.le configuration when using the Test Container, configuration data
     * needs to be provided by setting dev-configuration. See the developers guide or sample for more information.
     *
     *
     * @param A template with substitution variables. `http://{external.server.test}/info/test/{selected}`.
     * @return The resolved template with all substitution variables replaced (or removed if they can't be resolved).
     */
    abstract resolveAndReplace(template: string): string;
    /**
     * Gets the default application instance.
     *
     * If there are more than one instance of the application the one that is considered
     * to be default by the framework will be returned.
     *
     * Note that for this to work when using the Test Container, configuration data needs to be provided
     * by setting dev-configuration. See the developers guide or sample for more information.
     *
     * @returns The default application instance or null if the widget does not belong to an application.
     */
    abstract getApplication(): IApplication;
    /**
     * Gets an array with all application instances.
     *
     * If there is only a single appliction instance the result will be an array with one element.
     *
     * Note that for this to work when using the Test Container, configuration data needs to be provided
     * by setting dev-configuration.  See the developers guide or sample for more information.
     *
     * @returns An array of application instances or an empty array if the widgets does not belong to an application.
     */
    abstract getApplications(): IApplication[];
    /**
     * Gets the logical ID.
     * @returns The logical ID or null if the widget does not belong to an application.
     */
    abstract getLogicalId(): string;
    /**
     * Sets the logical ID. This function can be called by widgets that supports multiple application instances
     * to change the default application instance.
     *
     * Calling this function will only have an effect if the widget belongs to an application.
     *
     * @param logicalId The logical ID.
     */
    abstract setLogicalId(logicalId: string): void;
    /**
     * Gets the Ming.le application settings for a specified application.
     *
     * If a logical ID is specified it must match exactly with an existing application instance.
     * If a logical ID prefix is specified the default application instance will be returned.
     *
     * Note that for this to work when using the Test Container, configuration data needs to be provided
     * by setting dev-configuration. See the developers guide or sample for more information.
     *
     * @param logicalId The logical ID or logical ID prefix for the application to get.
     * @returns A promise that will be resolved when the application settings are available.
     */
    abstract getApplicationAsync(logicalId: string): Observable<IApplication>;
    /**
     * Gets the Ming.le application settings for all instances of the specified application.
     *
     * If a logical ID is specified it must match exactly with an existing application instance.
     * If a logical ID prefix is specified the default application instance will be returned.
     *
     * Note that all instances of an application will be returned even if the logical ID for
     * a specific instance is specified.
     *
     * Note that for this to work when using the Test Container, configuration data needs to be provided
     * by setting dev-configuration. See the developers guide or sample for more information.
     *
     * @param logicalId The logical ID or logical ID prefix for the application to get.
     * @returns A promise that will be resolved when the application settings are available.
     */
    abstract getApplicationsAsync(logicalId: string): Observable<IApplication[]>;
    /**
     * Resolves a URL template with replacement variables in curly brackets using values from a Ming.le application.
     *
     * If a logical ID is specified it must match exactly with an existing application instance.
     * If a logical ID prefix is not specified the default application instance will be used when resolving values.
     *
     * @param logicalId The logical ID prefix for the application to use when resolving values.
     * @returns A promise that will be resolved when the template has been resolved.
     */
    abstract resolveAndReplaceAsync(template: string, logicalId?: string): Observable<string>;
    /**
     * Gets an application view URL.
     *
     * The default behavior of this function is to get the view URL template for the current default application,
     * replace values in the template and return the URL. It is possible to specify another application and to
     * prevent variable replacement by using additional properties on the options object.
     *
     * @param options Used to specifiy the view to get and other options.
     * @returns A promise that will be resolved when the URL is available. The promise will be rejected
     * if the application or the view does not exist or if some other error occurs.
     */
    abstract getViewUrlAsync(options: IViewUrlOptions): Observable<string>;
    /**
     * Gets the ION API customer context.
     *
     * The ION API customer context must be used in the ION API URL for applications that are not Infor provisioned.
     * Applications that are provisioned in the cloud and is using the standard ION API suite name should not add
     * the customer context to the ION API URL.
     *
     * There are a few exceptions to this for Infor Tech products that are always Infor provisioned
     * both in cloud and on-premise.
     *
     * The default value for the ION API customer context is "CustomerApi" but the value can be configured
     * so it cannot be hardcoded.
     *
     * Example (M3 application with standard API suite provisioned in cloud):
     * https://ionapiserver:54321/ACME_AX1/M3/
     *
     *
     * Example (M3 application with custom API suite in cloud or on-premise):
     * https://ionapiserver:54321/ACME_AX1/CustomerApi/M3_CUSTOM/
     *
     * @returns The ION API customer context.
     */
    abstract getIonApiCustomerContext(): string;
    /**
     * Gets an ION API context required when making ION API HTTP requests.
     *
     * This function is asynchronous since a server request might be required to get the OAuth token for ION API.
     *
     * In most cases an ION API request can be executed using the executeIonApiAsync function that will automatically
     * get the ION API context and retry requests when the OAuth token has expired. This function can be used when more
     * control is required when making the request or when the executeIonApiAsync fuction cannot be used
     * for some other reason.
     *
     * The OAuth token has a limited lifetime and will become invalid once it has timed out.
     * The OAuth token might be invalid if an ION API HTTP request returns 401.
     * A client can get a new ION API context with a new OAuth token by setting the refresh property to true
     * on the options parameter.
     *
     * @param options Optional object for specifying options when getting the context.
     * @return A promise that will be resolved when the ION API context is available.
     */
    abstract getIonApiContextAsync(options?: IIonApiOptions): Observable<IIonApiContext>;
    /**
     * Executes ION Metadata APIs to read information about products and suites.
     * All previous data is cached by the framework. If a new suite has been registered in ION API
     * a restart would be required.
     *
     * If a product call returns HTTP400 the cause can be that the Suite does not exists in ION API.
     * For such scenarios this method can be used to check if there are products related to the suite or
     * logicalId prefix in ION API.
     *
     * If not then use the configurationRequiredMessage and display that as an widget inline error message.
     * @since 2.4
     */
    abstract getIonApiInfoAsync(options: IIonApiInfoOptions): Observable<IIonApiInfo>;
    /**
     * Executes an ION API HTTP request.
     *
     * This function will automatically get the IonApiContext which contains the OAuth token necessary
     * to complete the request.
     *
     * If the url parameter is relative (which it should be in most cases) the ION API base URL will be prepended
     * to the URL before the request is executed.
     *
     * If the ION API HTTP request returns a 401 response code this function will perform a single retry.
     * The retry attempt will get a fresh OAuth token and repeat the same request. If the second request completes
     * without errors it will be transparent to the caller. If the second request fails the promise will be rejected.
     *
     * If more control is required when making the request the getIonApiContextAsync function can be used to
     * get the OAuth token and ION API base URL. In this case the retry for expired OAuth tokens must be handled manually.
     *
     * @param options An object that describes the request.
     * @returns An observable that can be subscribed to.
     */
    abstract executeIonApiAsync<T>(options: IIonApiRequestOptions): Observable<IIonApiResponse<T>>;
    /**
     * Gets a framework service.
     *
     * This function can be used to get access to framework services implemented in Angular from a widget that
     * is not implemented in Angular. The function can be used from an Angular widget as well if the
     * normal dependency injection cannot be used for some reason.
     *
     * The available services are documented in the API documentation.
     * Note that a widget is only allowed to request services that are part of the public API documentation.
     * Any other services that might be accessible could be removed or refactored at any time without prior notice.
     *
     * @param name The type of the service to get.
     * @returns A service instance or null if the service could not be found.
     */
    abstract getService<T>(serviceType: new (...args: any[]) => T): T;
    /**
     * Launches a URL or a drillback link.
     *
     * This function can be used to launch a link in the browser or send a companyon message to open a drillback link.
     * The launchOptions will control if replacement variables should be resolved automatically or not.
     * Default is true and any curly brackets would result in that for example `{lid://infor.m3}` would be resolved
     * to the for the Homepages default instance id for m3, eg `{lid://infor.m3.1}`. This is for example used in
     * the custom menu widget as it makes widget link configuration portable for the default application wihtout
     * having to update logical ids.
     *
     * The link can contain replacement variables for specific applications as well using the syntax
     * with the logicalId prefix.
     * `{lid://infor.homepages:Host}`
     *
     * Any url that starts with a slash or http or https would be considered a standard web link and will be
     * handled by the browser opening a new window or tab. All other url will be handled by Ming.le companyon.
     *
     * Note that for this to work when using the Test Container, configuration data needs to be provided
     * by setting dev-configuration. See the developers guide or sample for more information.
     *
     * @param launchOptions The launch options.
     */
    abstract launch(launchOptions: ILaunchOptions): void;
    /**
     * Displays a dismissable inline message in the widget.
     */
    abstract showWidgetMessage(message: IWidgetMessage): void;
    /**
     * Sets the current widget status. For example this can be used to show an indicator in the widget title bar in
     * Context Appliction mode when the widget is collapsed. This is to indicate that the widget has current content.
     *
     * @since 2.5.0
     */
    abstract setWidgetStatus(status: IWidgetStatus): void;
    /**
     * Clears any existing widget status.
     *
     * @since 2.5.0
     */
    abstract clearWidgetStatus(): void;
    /**
     * Removes the inline message in the widget.
     */
    abstract removeWidgetMessage(): void;
    /**
     * Returns the pageId of the parent page or null if the widget does not have a parent context at this time.
     */
    abstract getPageId(): string;
    /**
     * Returns the ID if the widget is a standard widget or the standard widget id the widget is based on.
     */
    abstract getStandardWidgetId(): string;
    /**
     * Returns the runtime instance id for the widget.
     */
    abstract getWidgetInstanceId(): string;
    /**
     * This method is deprecated and should not be used. There is no replacement. The method was for Infor Grid XFO parameter.
     * But the scenario was only for IE and it does not longer apply. This method will not work in OS Portal.
     *
     * Returns the container (top level) url in the form of schema://host, for example https://mingledev.infor.com if
     * Homepages is running withing Ming.le. This url should be used when implementing X-Frame-Options for widgets
     * that has IFrames. The replacement variable to use in templates is 'framework.containerurl'.
     * If Homepages is running standalone or in dev mode it will return the URL to the Hompages host.
     * @deprecated
     */
    abstract getContainerUrl(): string;
    /**
     * Gets a value that indicates if the Homepages server is running the cloud mode or on-premise mode.
     *
     * This function can be used by widgets that needs to have a different behavior in cloud mode compared to
     * on-premise mode. Please note that Single Tenant Cloud installations are running in on-premise mode.
     * isSingleTenantCloud has been added to check this, but it is a grid property that needs to
     * be set manually on those installations.
     *
     * @returns True if the server is running in cloud mode.
     */
    abstract isCloud(): boolean;
    /**
     * Gets a value that indicated if the Homepages server is running in Single Tenant Cloud mode. This is
     * an on-prem installation running in the cloud. This information is used by some widgets to differentiate
     * between on-prem in the cloud (eg. isCloud is false since that is true only for multitenant).
     * @returns True if the grid property Server.IsSingleTenantCloud is set to True.
     */
    abstract isSingleTenantCloud(): boolean;
    /**
     * Gets the tenant ID.
     * @returns the tenant ID
     */
    abstract getTenantId(): string;
    /**
     * Gets the user ID.
     * Be sure to never send this value to identify a user. It can only be used for non-priviliged scenarios.
     * @returns the user ID
     */
    abstract getUserId(): string;
    /**
     * Finds widgets that are part of the same page as the current widget.
     *
     * If no options are specified the function will find all widgets on the page except for the current widget.
     *
     * @param options Optional find options.
     * @returns An array of widgets or an empty array if no matching widgets can be found.
     */
    abstract findWidgetsOnPage(options?: IFindWidgetOptions): IWidgetInstanceInfo[];
    /**
     * Gets a value that indicates if one or more widgets exists on the same page as the current widget.
     *
     * @param options Options that defines which widget to find. At least one of the ID properties should be set.
     * @returns True if one or more widgets matching the options exists on the page.
     */
    abstract isWidgetOnPage(options: IFindWidgetOptions): boolean;
    /**
     * Gets the Infor time zone in raw format if available.
     * Example: (UTC-05:00)Eastern Time(US & Canada)
     *
     * This value can be also be resolved using the key "inforTimeZoneRaw".
     *
     * @returns time zone in raw format or null
     * @since 1.0.13
     */
    abstract getInforTimeZoneRaw(): string;
    /**
     * Gets the Infor time zone if available.
     * Example: UTC-05:00
     *
     * This value can be also be resolved using the key "inforTimeZone".
     *
     * @returns time zone or null
     * @since 1.0.13
     */
    abstract getInforTimeZone(): string;
    /**
     * Gets the standard Infor time zone if available.
     * Example: Europe/Berlin
     *
     * This value can be also be resolved using the key "inforStdTimeZone".
     *
     * @returns time zone or null
     * @since 1.0.34
     */
    abstract getInforStdTimeZone(): string;
    /**
     * Gets the Infor current language if available.
     *
     * This value can be also be resolved using the key "inforCurrentLanguage".
     *
     * @returns the Infor current language or null
     * @since 1.0.28
     */
    abstract getInforCurrentLanguage(): string;
    /**
     * Gets the Infor current locale if available.
     *
     * This value can be also be resolved using the key "inforCurrentLocale".
     *
     * @returns the Infor current locale or null
     * @since 1.0.28
     */
    abstract getInforCurrentLocale(): string;
    /**
     * Gets the Infor theme name if available.
     *
     * This value can be also be resolved using the key "inforThemeName".
     *
     * @returns the Infor theme name or null
     * @since 1.0.28
     */
    abstract getInforThemeName(): string;
    /**
     * Returns the current background color used for the banner widget(s) container.
     *
     * This method is useful for banner widget implementation only, for instance to
     * be able to apply specific styles that are coherent with the current background color
     *
     * Example: #0E5B52
     *
     * @returns Banner background color string or null if the widget does not have a parent context at this time
     */
    abstract getBannerBackgroundColor(): string;
    /**
     * Gets the value of a drillback/bookmark parameter.
     *
     * This method can be used if Homepages is opened via a drillback or bookmark, including one or
     * more parameters, that the widget needs to resolve value(s) for. Only string values can be resolved.
     *
     * Example drillback: ?LogicalId=lid://infor.homepages.1&param1=valuefromparameterone
     * Value for "param1" can be retrieved using this method
     *
     * @param parameter The name of the parameter.
     * @returns The value of the parameter, or null if no matching parameter is found.
     * @since 1.0.19
     */
    abstract getContextParameter(parameter: string): string;
    /**
     * Tells the framework that the widget's primary action needs to be reevaluated.
     *
     * This method can be used if the widget supports different primary actions, depending on e.g. state.
     * An example would be a widget that has one primary action that is only relevant when it is editable,
     * and a different action that should be primary if it is published.
     *
     * @since 1.0.23
     */
    abstract updatePrimaryAction(): void;
    /**
     * Gets the mode that the widget is executing in. The widget will start in one mode that cannot be
     * changed during the entire session.
     * @since 1.0.34
     */
    abstract getMode(): Mode;
    /**
     * Gets the sub mode that the widget is executing in. The widget will start in one sub mode
     * that cannot changed during the entire session.
     * @since 1.0.34
     */
    abstract getSubMode(): SubMode;
    /**
     * Send Mingle companyon messages like Business Context messages or custom application message. This method is
     * a wrapper for infor.companyon.client. Never access infor.companyon.client directly.
     *
     * This method can be used for widget to widget communication. To communicate with widgets on the same page
     * the @see GetPageId() that returns the page id can be used as message type prefix.
     *
     * @since 1.0.34
     * @param name Message name
     * @param data Message data
     */
    abstract send(name: string, data: unknown): void;
    /**
     * Receive Mingle companyon messages like Business Context messages or custom application messages that
     * are sent by applications or other widgets. This method is a wrapper for infor.companyon.client.
     * Use this method instead of using infor.companyon.client directly. Note that messages will be received
     * even when the widget is not currently active, but it is never allowed for a widget to load data unless the widget
     * is currently active.
     *
     * This method will unsubscribe automatically to messages if the widget is destroyed.
     *
     * This method can be used for widget to widget communication. To communicate with widgets on the same page
     * the @see GetPageId() that returns the page id can be used as message type prefix.
     *
     * @since 1.0.34, 3.10.0
     * @param options a message type or message options
     * @returns A stream of messages
     */
    abstract receive(options: string | IMessageOptions): Observable<unknown>;
    /**
     * Gets environment information from the top level parent application.
     *
     * This is equivalent to calling infor.companyon.client.getEnvironmentInformation which should
     * never be done directly.
     *
     * @since 3.7.0
     * @returns An observable for the environment information
     */
    abstract getEnvironmentInformation(): Observable<EnvironmentInfoMap>;
    /**
     * Gets the URL of the top level parent application.
     *
     * This is equivalent to calling infor.companyon.client.getInforMingleHomeUrl which should
     * never be done directly.
     *
     * @since 3.7.0
     * @returns An observable for the top level parent URL
     */
    abstract getParentUrl(): Observable<string>;
    /**
     * Receive the current size of the widget. Any time the size of the widget changes due to an edited layout or
     * browser window resize, the observable will emit a new value. The size information can be used for
     * responsive style & functionality of the widget.
     *
     * This method will unsubscribe automatically to size updates if the widget is destroyed.
     *
     * @since 2.3.0
     * @returns An {@link IWidgetSize} Observable
     */
    abstract getSize(): Observable<IWidgetSize>;
    /**
     * Shows an IDS badge next to the title in the widget header, containing a number between 0 and 99.
     *
     * @param options The options for the badge, including the value (count) and color (type).
     * @since 3.8.0
     */
    abstract showBadge(options: IBadgeOptions): void;
    /**
     * Removes the badge, shown by {@link showBadge}, from the widget header.
     *
     * @since 3.8.0
     */
    abstract removeBadge(): void;
    /**
     * Sets an empty state message in the widget.
     *
     * @param options The options for the message.
     * @since 3.11.0
     */
    abstract setEmptyState(options: IEmptyStateOptions): void;
    /**
     * Clears the empty state message, shown by {@link setEmptyState}.
     *
     * @since 3.11.0
     */
    abstract clearEmptyState(): void;
    /**
     * Tracks that an event (e.g a click) has happened.
     *
     * Used for analytics.
     * @param options
     *
     * @since 3.11.0
     */
    abstract trackEvent(options: ITrackEventOptions): void;
    /**
     * Tracks that a view is shown to the user.
     *
     * Note that this should only be called if the widget is visible on the page, and there is more than one "sub-view".
     * The widget itself is already tracked as a view, so this method should only be used for more detailed tracking.
     *
     * Used for analytics.
     *
     * @since 3.18.0
     */
    abstract trackView(options: ITrackViewOptions): void;
    /**
     * Portal V2 Spotlight widget API
     *
     * NOTE: This should not be used in normal Homepages widgets!
     *
     * @since 3.16.0
     */
    abstract getSpotlight(): ISpotlight;
    static ɵfac: i0.ɵɵFactoryDeclaration<IWidgetContext, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<IWidgetContext>;
}
/**
 * Represents the context for a widget in runtime.
 *
 * The context is received as a parameter to the widgetFactory function in the widget module.
 *
 * The context provides a widget instance with data, settings, the DOM element etc and
 * functions that can be used to interact with the framework.
 *
 * @since 1.0.17
 */
export interface IWidgetContext2 extends IWidgetContext {
}
/**
 * Represents a widget instance on a page.
 *
 * @since 1.0.11
 */
export interface IWidgetInstanceInfo {
    /**
     * Gets the unique widget instance ID.
     *
     * This ID is generated when a widget is added to a page.
     */
    instanceId: string;
    /**
     * Gets the widget ID.
     *
     * This ID will be a either a standard widget ID or a published widget ID for a published widget.
     */
    id: string;
    /**
     * Gets the standard widget ID.
     *
     * For a standard widget this property will have the same value as the id property.
     */
    standardWidgetId: string;
    /**
     * Gets the title of the widget.
     */
    title: string;
}
/**
 * Options for finding widgets on a page.
 *
 * @since 1.0.11
 */
export interface IFindWidgetOptions {
    /**
     * Gets or sets a value that indicates if the current widget instance should be included in the result.
     *
     * The default value is false.
     */
    includeSelf?: boolean;
    /**
     * Gets or sets a unique widget instance ID to search for.
     *
     * This ID is generated when a widget is added to a page.
     */
    instanceId?: string;
    /**
     * Gets or sets a widget ID to search for.
     *
     * This ID will be a either a standard widget ID or a published widget ID for a published widget.
     */
    id?: string;
    /**
     * Gets or sets a standard widget ID to search for.
     */
    standardWidgetId?: string;
}
/**
 * Launch options for the IWidgetContext launch method.
 *
 * @since 1.0
 */
export interface ILaunchOptions {
    /**
     * An url starting with slash, http, https or a Ming.le drillback link.
     */
    url: string;
    /**
     * If values should be automatically resolved using application context information. Either the link must
     * start with a logicalId prefix or logicalId or the logical Id should be set on this function.
     *
     * An example of a URL that can be replaces to link to Ming.le posts is:
     * `{lid://infor.social}{Scheme}://{Hostname}:{Port}/{TenantId}/webpart/posts`
     *
     * The logicalIdPrefix in the beginning of the link determines that the default social application will be
     * used to resolve the other values. It is also possible to have values in the link that is from
     * the widget settings or ad-Hoc properties.
     *
     * Another example to open a M3 program would be:
     * `{lid://infor.m3}?LogicalId={logicalId}&program=MMS001`
     *
     */
    resolve?: boolean;
}
/**
 * If A is null, cast to B. Otherwise cast to C.
 */
type Nullable<A, B = any, C = A> = A extends null ? B : C;
/**
 * Represents the widget settings.
 *
 * Note that all settings values must be possible to serialize to JSON.
 *
 * @since 1.0
 */
export interface IWidgetSettings<T = null> {
    /**
     * Gets the settings value object.
     *
     * This object can be used directly instead of using the get/set functions if necessary.
     *
     * @returns The settings value object.
     */
    getValues(): Nullable<T>;
    /**
     * Sets the settings value object.
     *
     * Note that calling this function will overwrite all existing setting values.
     *
     * @param values The settings value object.
     */
    setValues(values: Nullable<T>): void;
    /**
     * Gets the settings metadata.
     * @returns An array of metadata for each setting.
     */
    getMetadata(): IWidgetSettingMetadata[];
    /**
     * Sets the settings metadata
     *
     * Note that calling this function will overwrite all existing settings metadata.
     *
     * @param metadata An array of metadata for each setting.
     */
    setMetadata(metadata: IWidgetSettingMetadata[]): any;
    /**
     * Gets a property.
     *
     * @param name The name of the property. Must be a valid property name of T.
     * @param defaultValue Optional default value to return if the property is missing.
     * @returns The property value or the default value.
     */
    get<V extends NonNullable<T>, N extends keyof V & string>(name: N, defaultValue?: V[N]): V[N];
    /**
     * Gets a property of type RT.
     *
     * @param name The name of the property.
     * @param defaultValue Optional default value to return if the property is missing.
     * @returns The property value or the default value.
     */
    get<RT>(name: Nullable<T, string, never>, defaultValue?: RT): RT;
    /**
     * Sets a settings value.
     *
     * Note that the value must be possible to serialize to JSON.
     *
     * @param name The name of the setting.
     * @param value The setting value.
     */
    set<N extends keyof Nullable<T>>(name: Nullable<T, string, N>, value: Nullable<T>[N]): void;
    /**
     * Gets a string property.
     *
     * If the property value is not a string it will be converted to a string by this function.
     *
     * @param name The name of the property.
     * @param defaultValue Optional default value to return if the property is missing.
     * @returns The property value or the default value.
     */
    getString<N extends keyof Nullable<T>>(name: Nullable<T, string, N>, defaultValue?: string): string;
    /**
     * Shows the widget settings dialog.
     *
     * This function can be used to manually show the widget settings dialog.
     * The widget settings can be opened from the widget title bar menu but some widgets may
     * have some additional UI element that should also open the widget settings.
     *
     * @param options Optional settings options.
     */
    showSettings(options?: IShowSettingsOptions): void;
    /**
     * Gets a value that indicates if settings are currently enabled.
     * The value depends on the following factors: if settings are enabled in the definition,
     * if settings are enabled for a published widet, if the widget is in a publish / edit published state in the client.
     * This means that the value might change over time when working with a published widget.
     * @return True if settings are enabled.
     */
    isSettingsEnabled(): boolean;
    /**
     * Gets a value that indicates if the specified setting is enabled.
     *
     * A setting might be disabled for a published widget.
     * A widget implementation with custom settings management should check if a setting is enabled or not.
     *
     * @param name The name of the setting
     * @return True if the setting is enabled or if the setting is not recognized.
     * False if the setting is disabled or if all settings are disabled.
     */
    isSettingEnabled<N extends keyof Nullable<T>>(name: Nullable<T, string, N>): boolean;
    /**
     * Gets a value that indicates if the specified setting should be visible to the end user.
     *
     * A setting might be hidden for a published widget.
     * A widget implementation with custom settings management should check if a setting is hidden or not.
     *
     * @param name The name of the setting
     * @return  True if the setting is visible or if the setting is not recognized. False if the setting is hidden.
     */
    isSettingVisible<N extends keyof Nullable<T>>(name: Nullable<T, string, N>): boolean;
    /**
     * Sets if the Configure (Settings Menu) should be visible or not. Default is true if the widget has defined settings.
     * Intended for widgets that want to use the settings framework but not the standard Configure menu
     * that opens the settings dialog.
     * @param enabled If configure menu should be visible.
     */
    enableSettingsMenu(enabled: boolean): void;
    /**
     * @since 1.0.21
     */
    hasMandatory(): boolean;
    /**
     * @since 1.0.21
     */
    isMandatory<N extends keyof Nullable<T>>(name: Nullable<T, string, N>): boolean;
}
/**
 * Represents a custom widget settings instance.
 *
 * An object of this type should be set in IWidgetSettingsobject when settingsOpenings is called.
 *
 * A widget implementation may choose which properties to set depending on what types of callbacks the widget requires.
 *
 * @since 1.0
 */
export declare abstract class IWidgetSettingsInstance {
    /**
     * Gets or sets an optional event function that will be called when the Settings dialog is closing.
     */
    abstract closing?: (arg: IWidgetSettingsCloseArg) => void;
    /**
     * Gets or sets an optional angular configration for widgets implementing the settings UI with an Angular component.
     */
    abstract angularConfig?: IAngularWidgetConfig;
    /**
     * Gets or sets an optional angular configuration for widgets implementing the settings UI with a web component.
     *
     * @since 3.33.0
     */
    abstract webComponentConfig?: IWebComponentWidgetConfig;
    static ɵfac: i0.ɵɵFactoryDeclaration<IWidgetSettingsInstance, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<IWidgetSettingsInstance>;
}
/**
 * Represents a custom widget settings instance.
 *
 * An object of this type should be set in IWidgetSettingsobject when settingsOpenings is called.
 *
 * A widget implementation may choose which properties to set depending on what types of callbacks the widget requires.
 *
 * @since 1.0.17
 */
export interface IWidgetSettingsInstance2 extends IWidgetSettingsInstance {
}
/**
 * Represents the context for a custom settings UI implementation.
 *
 * @since 1.0
 */
export declare abstract class IWidgetSettingsContext {
    /**
     * Gets the widget context.
     *
     * @returns The widget context.
     */
    abstract getWidgetContext(): IWidgetContext;
    /**
     * Enables or disables save in the settings dialog.
     *
     * @param isEnabled A value that indicates if save should be enabled.
     */
    abstract enableSave(isEnabled: boolean): void;
    /**
     * Gets a value that indicates if save is enabled in the settings dialog.
     * @retruns True if save is enabled.
     */
    abstract isSaveEnabled(): boolean;
    /**
     * Gets the widget settings DOM element wrapped in a JQuery object.
     *
     * A widget may add settings UI content to this element and for widgets not implemented using AngularJS
     * this is the only option for adding custom settings content.
     *
     * Note that a widget is only allowed to add content as children to this element.
     * A widget is not allowed to explicitly add elements to other parts of the DOM. The only exceptions
     * are when elements are added impicitly using modal dialogs, popups etc.
     *
     * AngularJS widgets may add compiled content to this element.
     * The angularContext property contains the the scope and the compile service required for
     * compiling AngularJS elements.
     *
     * AngularJS widgets that uses one of the template properties defined on
     * the angularConfig property ({@link IAngularWidgetConfig}) in {@link IWidgetSettingsInstance} should ignore this property.
     * In this case the framework will add content to the element automatically.
     *
     * @returns The parent jQuery element.
     */
    abstract getElement(): JQuery;
    /**
     * Closes the settings dialog.
     * @param isSave A value that indicats if the settings should be saved or not.
     * The default value is false. See {@link IWidgetSettingsCloseArg}.
     */
    abstract close(isSave?: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<IWidgetSettingsContext, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<IWidgetSettingsContext>;
}
/**
 * Represents the context for a custom settings UI implementation.
 *
 * @since 1.0.17
 */
export interface IWidgetSettingsContext2 extends IWidgetSettingsContext {
}
/**
 * Defines widget constants.
 *
 * @since 1.0
 */
export declare class WidgetConstants {
    static widgetInstanceKey: string;
    static widgetContextKey: string;
    static widgetTitle: string;
    static widgetDescription: string;
}
/**
 * Represents a widget implemented as an Angular component.
 *
 * The widget should implement the properties in this interface as component inputs, @Input().
 * The framework will set the properties when the component is created so that they are
 * availble in the ngAfterViewInit function.
 *
 * @since 1.0.17
 */
export interface IWidgetComponent {
    /**
     * Gets or sets the widget context.
     */
    widgetContext: IWidgetContext;
    /**
     * Gets or sets the widget instance.
     */
    widgetInstance: IWidgetInstance;
}
/**
 *
 * @since 1.0.17
 */
export interface IWidgetSettingsComponent {
    widgetSettingsContext: IWidgetSettingsContext;
    widgetSettingsInstance: IWidgetSettingsInstance;
}
/**
 * The Device provides access to native functions on a mobile devide when the widget is running in InforGO.
 *
 * @since 1.0.32
 */
export interface IDevice {
    /**
     *
     * Get current geographic location of the device.
     * @param options
     * @since 1.0.32
     */
    getLocation(options?: IGetLocationOptions): Observable<IGetLocationResult>;
    /**
     *
     * Get an image from the device camera or photo library.
     * @param options
     * @since 1.0.32
     */
    getImage(options?: IGetImageOptions): Observable<IGetImageResult>;
    /**
     *
     * Get a video from the device camera or photo library.
     * @param options
     * @since 1.0.32
     */
    getVideo(options?: IGetVideoOptions): Observable<IGetVideoResult>;
    /**
     *
     * Get an audio clip from the device.
     * @param options
     * @since 1.0.32
     */
    getAudio(options?: IGetAudioOptions): Observable<IGetAudioResult>;
    /**
     *
     * Get motion sensor data from the device.
     * @param options
     * @since 1.0.32
     */
    getSensors(options?: IGetSensorsOptions): Observable<IGetSensorsResult>;
    /**
     *
     * Get connectivity status of the device.
     * @param options
     * @since 1.0.32
     */
    getNetwork(options?: IGetNetworkOptions): Observable<IGetNetworkResult>;
    /**
     *
     * Read a QR code from the device camera or photo library.
     * @param options
     * @since 1.0.32
     * @deprecated use readBarcode() instead
     */
    readQRCode(options?: IReadQRCodeOptions): Observable<IReadQRCodeResult>;
    /**
     *
     * Read a 1D or 2D barcode from the device camera or photo library.
     *
     * Has been tested to work with the following barcodes:
     *
     * - UPC-E
     * - Code 39
     * - Code 39 mod
     * - EAN-13
     * - EAN-8
     * - Code 93
     * - Code 128
     * - PDF417
     * - QR Codes
     * - Aztec
     * - Interleaved
     * - ITF14
     * - DataMatrix
     *
     * @param options
     * @since 1.0.47
     */
    readBarcode(options?: IReadBarcodeOptions): Observable<IReadBarcodeResult>;
    /**
     *
     * Open the native application for Maps.
     * @param options
     * @since 1.0.32
     */
    showMap(options?: IShowMapOptions): Observable<IShowMapResult>;
    /**
     *
     * Open a link to an external web site.
     * @param options
     * @since 1.0.32
     */
    openExternalLink(options: IOpenLinkOptions): Observable<IOpenLinkResult>;
    /**
     * Open a document.
     * @param options
     * @since 1.0.45
     */
    openDocument(options: IOpenDocumentOptions): Observable<IOpenDocumentResult>;
}
/**
 * Request options with this interface are intended for resources that can send continuous updates of data.
 * @since 1.0.32
 */
export interface IWatchOption {
    /**
     * Request continous updates of data, rather than a single request-response.
     * @since 1.0.32
     */
    watch?: boolean;
}
/**
 * Response from {@link IDevice.getLocation}.
 * @since 1.0.32
 */
export interface IGetLocationResult {
    /**
     * Latitude coordinate
     * @since 1.0.32
     */
    readonly latitude: number;
    /**
     * Longitude coordinate
     * @since 1.0.32
     */
    readonly longitude: number;
}
/**
 * Generic interface for {@link IDevice} responses with base64-encoded media.
 * @since 1.0.32
 */
export interface IGetMediaResult {
    /**
     * Base64-encoded media data
     * @since 1.0.32
     */
    readonly data: string;
}
/**
 * Response from {@link IDevice.getImage}.
 * @since 1.0.32
 */
export interface IGetImageResult extends IGetMediaResult {
}
/**
 * Response from {@link IDevice.getVideo}.
 * @since 1.0.32
 */
export interface IGetVideoResult extends IGetMediaResult {
}
/**
 * Response from {@link IDevice.getAudio}.
 * @since 1.0.32
 */
export interface IGetAudioResult extends IGetMediaResult {
}
/**
 * Request option for {@link IDevice.getLocation}.
 * @since 1.0.32
 */
export interface IGetLocationOptions extends IWatchOption {
}
/**
 * This type describes the different media sources for {@link IDevice} requests.
 * @since 1.0.32
 */
export type IMediaSource = "camera" | "library" | "all";
/**
 * Request option for {@link IDevice.getImage}.
 * @since 1.0.32
 */
export interface IGetImageOptions {
    /**
     * Set the source of the image.
     * @since 1.0.32
     */
    source: IMediaSource;
}
/**
 * Request option for {@link IDevice.getVideo}.
 * @since 1.0.32
 */
export interface IGetVideoOptions {
    /**
     * Set the source of the video.
     * @since 1.0.32
     */
    source: IMediaSource;
}
/**
 * Request option for {@link IDevice.getAudio}.
 * @since 1.0.32
 */
export interface IGetAudioOptions {
}
/**
 * Geographic coordinates {@link IDevice.getLocation} requests.
 * @since 1.0.32
 */
export interface IMapCoordinates {
    /**
     * Longitude coordinate.
     * @since 1.0.32
     */
    longitude: number;
    /**
     * Latitude coordinate.
     * @since 1.0.32
     */
    latitude: number;
}
/**
 * Map marker for {@link IDevice.showMap} requests.
 * @since 1.0.32
 */
export interface IMarker {
    /**
     * Coordinates for the marker.
     * @since 1.0.32
     */
    coordinates: IMapCoordinates;
    /**
     * The label of the marker.
     * @since 1.0.32
     */
    label: string;
}
/**
 * Request option for {@link IDevice.showMap} used to open navigation in the native Maps application.
 * @since 1.0.32
 */
export interface IMapNavigationOptions {
    mapType: "navigation";
    /**
     * The starting coordinates for navigation.
     * @since 1.0.32
     */
    start?: IMapCoordinates;
    /**
     * The destination coordinates for navigation.
     * @since 1.0.32
     */
    destination: IMapCoordinates;
}
/**
 * Request option for {@link IDevice.showMap} used to open the native Maps application with markers.
 * @since 1.0.32
 */
export interface IMapMarkerOptions {
    mapType: "marker";
    /**
     * Markers to be displayed on the map.
     * @since 1.0.32
     */
    markers: IMarker[];
}
/**
 * Request option for {@link IDevice.showMap} used to open the native Maps application, centered at a specific location.
 * @since 1.0.32
 */
export interface IMapLocationOptions {
    mapType: "location";
    /**
     * Coordinates to where the map should be centered.
     * @since 1.0.32
     */
    coordinates: IMapCoordinates;
}
/**
 * Request option for {@link IDevice.showMap}.
 * @since 1.0.32
 */
export type IShowMapOptions = IMapNavigationOptions | IMapMarkerOptions | IMapLocationOptions;
/**
 * Response from {@link IDevice.showMap}.
 * @since 1.0.32
 */
export interface IShowMapResult {
}
/**
 * Request options for {@link IDevice.readQRCode}.
 * @since 1.0.32
 * @deprecated use IReadBarcodeOptions instead
 */
export interface IReadQRCodeOptions {
}
export interface IReadBarcodeOptions extends IReadQRCodeOptions {
}
/**
 * Request options for {@link IDevice.getNetwork}.
 * @since 1.0.32
 */
export interface IGetNetworkOptions extends IWatchOption {
}
/**
 * Network connection type.
 * @since 1.0.32
 */
export type NetworkConnectionType = "unknown" | "wifi" | "mobile";
/**
 * Network connection state.
 * @since 1.0.32
 */
export type NetworkConnectionState = "online" | "offline";
/**
 * Response from {@link IDevice.getNetwork}.
 * @since 1.0.32
 */
export interface IGetNetworkResult {
    /**
     * Network connection state
     * @since 1.0.32
     */
    readonly connectionState: NetworkConnectionState;
    /**
     * Network connection type
     * @since 1.0.32
     */
    readonly connectionType: NetworkConnectionType;
}
export interface IGetSensorsOptions extends IWatchOption {
}
/**
 * Acceleration data for {@link IDevice.getSensors} responses.
 * @since 1.0.36
 */
export interface IAccelerationData {
    x: number;
    y: number;
    z: number;
}
/**
 * Gyroscope data for {@link IDevice.getSensors} responses.
 * @since 1.0.36
 */
export interface IGyroscopeData {
    x: number;
    y: number;
    z: number;
}
/**
 * Response from {@link IDevice.getSensors}.
 * @since 1.0.32
 */
export interface IGetSensorsResult {
    /**
     * Accelerometer data
     * @since 1.0.32
     */
    readonly acceleration: IAccelerationData;
    /**
     * Gyroscope data
     * @since 1.0.32
     */
    readonly gyroscope: IGyroscopeData;
}
/**
 * Response from {@link IDevice.readQRCode}.
 * @since 1.0.32
 * @deprecated use IReadBarcodeResult instead
 */
export interface IReadQRCodeResult {
    /**
     * Decoded textual value of the QR Code
     * @since 1.0.32
     */
    readonly text: string;
}
/**
 * Response from {@link IDevice.readBarcode}.
 * @since 1.0.47
 */
export interface IReadBarcodeResult extends IReadQRCodeResult {
    /**
     * Decoded textual value of the barcode
     * @since 1.0.47
     */
    readonly text: string;
}
/**
 * Request options for {@link IDevice.openExternalLink}
 * @since 1.0.32
 */
export interface IOpenLinkOptions {
    /**
     * URL to an external site or application
     * @since 1.0.32
     */
    url: string;
}
/**
 * Response from {@link IDevice.openExternalLink}
 * @since 1.0.32
 */
export interface IOpenLinkResult {
}
/**
 * Request options for {@link IDevice.openDocument}
 * @since 1.0.45
 */
export interface IOpenDocumentOptions {
    /**
     * MIME Type of the document, e.g "application/pdf"
     * @since 1.0.45
     */
    type: string;
    /**
     * Name of the document, e.g "test.pdf"
     * @since 1.0.45
     */
    name: string;
    /**
     * Base64-encoded document data
     * @since 1.0.45
     */
    data: string;
}
/**
 * Response from {@link IDevice.openDocument}
 * @since 1.0.45
 */
export interface IOpenDocumentResult {
}
/**
 * Represents the size of a widget in the number of columns and rows it spans on a page (cols 1-4, rows 1-2).
 * Response as an observable from {@link IWidgetContext.getSize}
 *
 * @since 2.3.0
 */
export interface IWidgetSize {
    cols: number;
    rows: number;
}
/**
 * Gets the Angular injection token for the widget context.
 * Use this when injecting the widget context in an Angular component constructor.
 *
 * @since 1.0.22
 */
export declare const widgetContextInjectionToken: InjectionToken<IWidgetContext>;
/**
 * Gets the Angular injection token for the widget instance.
 * Use this when injecting the widget instance in an Angular component constructor.
 *
 * @since 1.0.22
 */
export declare const widgetInstanceInjectionToken: InjectionToken<IWidgetInstance>;
/**
 * Defines the different modes the widget can be executing in. The widget will start in one mode
 * that cannot changed during the entire session.
 * @since 1.0.34
 */
export declare enum Mode {
    Default = 0,
    Mobile = 1,
    ContextApp = 2
}
/**
 * Defines a sub mode if applicable. The widget will start in one mode
 * that cannot changed during the entire session. Currently there is only sub modes for the Mobile mode when a widget
 * can be part of a page or in a single view mode which is called MobileSingle.
 * @since 1.0.34
 */
export declare enum SubMode {
    Default = 0,
    MobilePage = 1,
    MobileSingle = 2
}
/**
 * Defines the options that are able to be set in state Options.
 */
export interface BusyStateOptions {
    position?: BusyStatePosition;
}
/**
 * Defines which positions are allowed to be set for BusyStatePosition.
 * See BusyStateOptions.
 */
export type BusyStatePosition = "center" | "bottom";
/**
 * Portal V2 Search Spotlight
 */
export interface ISpotlight {
    /**
     * Data that is sent to the widget when a result is selected.
     */
    data$: Observable<ISpotlightData>;
}
export interface ISpotlightData {
    /**
     * Misc. metadata about the result/repository
     */
    metadata: {
        repository: {
            name: string;
            displayName: string;
        };
    };
    /**
     * The properties that comes with the search result.
     */
    properties: Record<string, unknown>;
    /**
     * The field data that is resolved based on the `widgetData` repository property.
     */
    fields?: Array<{
        label: string;
        value: string;
    }>;
}
export {};
