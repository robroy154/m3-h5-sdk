/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="ids-enterprise-typings" />
/// <reference types="jquery" />
/// <reference types="jquery" />
/**
 * Utility class for array operations.
 *
 * @since 1.0
 */
export declare class ArrayUtil {
    /**
     * Checks if an item exists in an array.
     * @returns True if an item exists.
     */
    static contains(array: any[], value: any): boolean;
    /**
     * Gets the index of a value in an array.
     * @param array Array to get value index from.
     * @param value Value to get index of.
     * @returns index of value.
     */
    static indexOf(array: any[], value: any): number;
    /**
     * Sorts the array in acending order of the given property.
     * @param array Array to sort.
     * @param property Property to sort array by.
     * @param options Optional options for controlling the sorting.
     * @returns The sorted array.
     */
    static sortByProperty(array: any[], property: string, options?: ISortOptions): any[];
    /**
     * Removes an item in an array.
     */
    static remove(array: any[], item: any): void;
    /**
     * Removes an item in an array by matching the value of a specific property.
     *
     * @param array the array to remove an item from
     * @param name the name of the propery
     * @param value that value that the property should match
     * @returns the removed item or null if the item could not be found
     */
    static removeByProperty<T>(array: T[], name: string, value: any): T;
    /**
     * Removes the first item in an array that matches a predicate function.
     *
     * @param array the array to remove an item from
     * @param predicate a predicate function that returns true for a matching item in the array
     * @returns the removed item or null if the item could not be found
     */
    static removeByPredicate<T>(array: T[], predicate: (item: T) => boolean): T;
    /**
     * Finds the index of an item in an array that matches a predicate function.
     *
     * @param array the arrary to find an item in
     * @param predicate a predicate function that returns true for a matching item in the array
     * @returns the index of the item or -1 if the item could not be found
     */
    static indexByPredicate<T>(array: T[], predicate: (item: T) => boolean): number;
    /**
     * Gets the index of an item in an array by matching the value of a specific property.
     */
    static indexByProperty<T>(array: T[], name: string, value: any): number;
    /**
     * Gets the item in an array by matching the value of a specific property.
     */
    static itemByProperty<T = any>(array: any[], name: string, value: any): T;
    /**
     * Gets the item matching the predicate.
     */
    static itemByPredicate<T>(array: T[], predicate: (item: T) => Object): T;
    /**
     * Filters an array based on a predicate.
     */
    static filterByPredicate<T>(array: T[], predicate: (item: T) => Object): T[];
    /**
     * Checks if an item exists in an array by matching the value of a specific property.
     * @ returns True if an item with the property and value exists.
     */
    static containsByProperty(array: any[], name: string, value: any): boolean;
    /**
     * Gets the last item in an array.
     * @returns The last item or null if the array is null or empty.
     */
    static last(array: any[]): any;
    /**
     * Finds the first item in the array that matches the conditions defined in the predicate function.
     * @param array An array of items to search.
     * @param predicate A predicate function that should return true if the item parameter matches the predicate condition.
     */
    static find<T>(array: T[], predicate: (item: T) => boolean): T;
    /**
     * Finds all items in the array that matches the conditions defined in the predicate function.
     * @param array An array of items to search.
     * @param predicate A predicate function that should return true if the item parameter matches the predicate condition.
     */
    static findAll<T>(array: T[], predicate: (item: T) => boolean): T[];
    /**
     * Creates an array of n entries with the specified default value.
     * @params n            Number of entries.
     * @params defaultValue The default values of the entries.
     * @returns Array.
     */
    static array<T>(n: number, defaultValue?: T): T[];
    /**
     * Creates a matrix (two dimensional array) with specified default values.
     * @param rows     The number of rows in the matrix.
     * @params columns The number of columns in the matrix.
     * @returns matrix.
     */
    static matrix<T>(rows: number, columns: number, defaultValue?: T): T[][];
    /**
     * Moves a object in an array to another index.
     */
    static move(array: any[], index: number, newIndex: number): void;
    /**
     * Swaps two items in an array
     *
     * @param items the array
     * @param index1 the index of the first item
     * @param index2 the index of the second item
     * @throws RangeError if either indices are out of bounds
     *
     * @since 1.0.17
     */
    static swap(items: any[], index1: number, index2: number): void;
    /**
     * Safely concatenates two arrays.
     *
     * @param items the first array
     * @param items2 the second array
     *
     * @since 1.0.27
     */
    static concat<T>(items: T[], items2: T[]): T[];
    /**
     * Rotate array to the left a given number of clicks.
     * @example
     * rotateArray([1,2,3,4], 1) // [2,3,4,1]
     * @param array An array
     * @param clicks A positive integer
     *
     * @since 1.0.34
     */
    static rotateLeft<T>(array: T[], clicks: number): T[];
}
/**
 * Number utility functions.
 *
 * @since 1.0
 */
export declare class NumUtil {
    private static defaultSeparator;
    private static defaultOptions;
    /**
     * Gets the default options used by the functions in the class.
     * @returns The default options.
     */
    static getDefaultOptions(): INumberFormatOptions;
    /**
     * Sets the default options used by the functions in the class.
     * @options The default options.
     */
    static setDefaultOptions(options: INumberFormatOptions): void;
    /**
     * Gets a values that indicates if the parameter is a number.
     *
     * The value is considered to be a number if it can be parsed as a float, it is a number and it is finite.
     * @param n The value to check.
     * @returns True if the value is a number.
     */
    static isNumber(n: any): boolean;
    /**
     * Gets an integer value from a string.
     * @param s The string to parse.
     * @param defaultValue Optional default value to return if the string cannot be parsed. The default is zero.
     * @returns An integer parsed from the string or the default value.
     */
    static getInt(s: string, defaultValue?: number): number;
    /**
     * Formats a number or string using default or specified formatting options.
     *
     * This function currently only supports formatting using a specified decimal separator.
     * The value to format is expected to be either a number or a string containing a number where any
     * decimal separator is dot (.). If the value is a string it may not contain any thousand separators
     * or other formatting characters.
     *
     * @param value The value to format which can be a number or a number in string format.
     * @param options Optional formatting options.
     */
    static format(value: any, options?: INumberFormatOptions): string;
    /**
     * Pads a number with leading zeroes up to the specified length.
     * @param num The number to pad.
     * @param length The length of the string.
     */
    static pad(num: number, length: number): string;
    /**
     * Gets a value that indicates if the string contains only integers (1234567890).
     * @param s The string value to check.
     * @returns True if string contains only integers.
     */
    static hasOnlyIntegers(s: string): boolean;
    /**
     * Calculate the remainder between the dividend and the divisor. (dividend mod divisor)
     * @param dividend
     * @param divisor
     *
     * @since 1.0.32
     */
    static mod(dividend: number, divisor: number): number;
    /**
     * Gets a random integer between the min and max values.
     * @param min The min integer value
     * @param max The max integer value
     * @returns A random integer.
     *
     * @since 2.0.0
     */
    static randomInt(min: number, max: number): number;
    private static getLocaleSeparator;
}
/**
 * Common Utility functions.
 *
 * @since 1.0
 */
export declare class CommonUtil {
    private static chars;
    /**
     * Copies an object using JSON stringify and parse.
     *
     * The object to copy must be valid as JSON. Note the limitations with Date object
     * JSON serialization (avoid using this function with Date if unsure).
     *
     * @param value the object to copy
     * @returns	a copy of the input object
     *
     * @since 1.0.22
     */
    static copyJson<T>(value: T): T;
    /**
     * Gets the local date string.
     * Options can be used to set the formatting, for example: `{ date: "short" }` or `{ pattern: "yyyy-MM-dd HH:mm" }`.
     * @params dateString Date string.
     * @params options    Options for fromatting.
     * @returns string    Formatted date.
     */
    static getLocaleDateString(dateString: string, options?: any): string;
    /**
     * Delets a property of an object.
     * @param object   Object of which to delete a property.
     * @param property Property to delete.
     */
    static deleteProperty(object: any, property: string): void;
    /**
     * Converts a boolean from a string.
     * @param string       String to convert.
     * @param defaultValue Default return value if string can't be used.
     */
    static getBoolean(s: string, defaultValue?: boolean): boolean;
    /**
     * @deprecated
     * @param prefix
     * @since 1.0.28
     */
    static getUuid(prefix: string): string;
    /**
     * Checks for undefined. Returns true if the object has a value, eg not undefined and not null.
     * @param anyObject Any object
     * @since 1.0.28
     */
    static hasValue(anyObject: any): boolean;
    /**
     * Checks if undefined. Returns true if undefined.
     * @param anyObject Any object
     * @since 1.0.28
     */
    static isUndefined(anyObject: any): boolean;
    /**
     * Checks if the object is a boolean.
     * @param anyObject Any object
     * @since 1.0.28
     */
    static isBoolean(anyObject: any): boolean;
    /**
     * Checks if an arbitrary object has a specific function defined or not.
     * @param anyObject
     * @param functionName
     */
    static hasFunction(anyObject: any, functionName: string): boolean;
    /**
     * Creates a string with random uppercase letters and numbers.
     * The default length is 16 if the stringLength parameter is omitted.
     */
    static random(stringLength?: number): string;
    /**
     * Gets a value that indicates if the current window is an IFrame or not.
     */
    static isIframe(): boolean;
    /**
     * Returns the client's date as yyyy-mm-ddThh:mm
     * Ex: 2015-01-20T21:20
     */
    static getClientDate(): string;
    /**
     * Detects IE version and sets it as a class on the html element.
     */
    static detectBrowser(): void;
}
/**
 * String utility functions.
 *
 * @since 1.0
 */
export declare class StringUtil {
    /**
     * Gets a value that indicates if the string is null, undefined, empty or contains only whitespace.
     * @param value The string to check.
     * @returns True if the string is null, undefined, empty or contains only whitespace.
     */
    static isNullOrWhitespace(value: string): boolean;
    /**
     * Returns true if the value is a string.
     * @param value An object that needs to be checked if it is a String or not
     */
    static isString(value: any): boolean;
    /**
     * Gets a value that indicates if a string starts with a specified value.
     * @param value The string value to check.
     * @param prefix The value that the string should start with.
     * @returns True if the string starts with the specified prefix value.
     */
    static startsWith(value: string, prefix: string): boolean;
    static replaceParameters(template: string, resolveFunction: Function): string;
    /**
     * Gets a value that indicates if a string ends with a specified value.
     * @param value The string value to check.
     * @param prefix The value that the string should end with.
     * @returns True if the string ends with the specified suffix value.
     */
    static endsWith(value: string, suffix: string): boolean;
    /**
     * Trims whitespace from the end of a string.
     * @param value The value to trim.
     * @returns The trimmed value.
     */
    static trimEnd(value: string): string;
    /**
     * Replaces all occurrences of a string in a string.
     * @param value the string to replace strings in
     * @param find the string to find
     * @param replace the string to replace
     *
     * @since 1.0.29
     */
    static replaceAll(value: string, find: string, replace: string): string;
    static format(...args: any[]): string;
    static splitTagString(value: string): string;
    static splitAndInsert(value: string, splitChar: string, insertChar: string): string;
    /**
     * Joins an array of object using a preticate and returns a string.
     * @param array An array of objects
     * @param predicate A predicate to select the string from the object that should be used in the join
     * @param splitChar Optional separator, default is comma.
     * @since 1.0.30
     */
    static join<T>(array: T[], predicate: (item: T) => string, splitChar?: string): string;
    /**
     * Removes all spaces " " in a text and inputs "-" instead. Also escapes the text
     * Used to format the text to be usable in id and name attribute.
     */
    static formatTextForId(text: string, defaultText: string): string;
}
/**
 * HTML utility functions for creating and manipulating HTML elements.
 *
 * @since 1.0
 */
export declare class HtmlUtil {
    /**
     * Creates an iframe element without borders and the sandbox attribute set.
     */
    static iframe(url?: string, name?: string): JQuery;
    static destroyIFrame(iframe: JQuery): void;
    /**
     * Returns a string that has been escaped so it can safely be used within an HTML element.
     * Use this method to avoid XSS when inserting untrusted content into HTML elements.
     * Read more at https://www.owasp.org/index.php/XSS_(Cross_Site_Scripting)_Prevention_Cheat_Sheet#RULE_.231_-_HTML_Escape_Before_Inserting_Untrusted_Data_into_HTML_Element_Content.
     * @param content String to be escaped
     * @returns Escaped content
     */
    static escapeStringForHtml(content: string): string;
    /**
     * Escapes all properties of the given object that are strings, so it can safely be used within an HTML element.
     * @param obj Object to be escaped
     * @returns Escaped content
     */
    static escapeObjectStringsForHtml(obj: Object): Object;
}
/**
 * Log text messages and exceptions on different log levels to the browser console and optional custom log appenders.
 *
 * **Example:**
 *
 * import Log = require("log");
 * Log.info("Application initialized");
 *
 * @since 1.0
 */
export declare class Log {
    /**
     * Fatal log level. Severe errors that prevents the application from functioning.
     */
    static levelFatal: number;
    /**
     * Error log level.
     */
    static levelError: number;
    /**
     * Warning log level.
     */
    static levelWarning: number;
    /**
     * Information log level.
     */
    static levelInfo: number;
    /**
     * Debug log level. Detailed information for debug purposes.
     */
    static levelDebug: number;
    /**
     * Trace log level. Most detailed information for debug purposes.
     */
    static levelTrace: number;
    /**
     * Gets or sets the current log level. The default log level is information.
     */
    static level: number;
    /**
     * Gets or sets a value that indicates if logging to the browser console is enabled.
     * The default value is true.
     */
    static isConsoleLogEnabled: boolean;
    private static prefixes;
    private static appenders;
    /**
     * Adds a new log appender that will receive log entries for the current log level.
     * @param A log appender.
     */
    static addAppender(appender: ILogAppender): void;
    /**
     * Removes an existing log appender.
     * @param appender An existing appender to remove.
     */
    static removeAppender(appender: ILogAppender): void;
    /**
     * Gets a formatted log entry.
     * @param level The log level.
     * @param ex An optional exception object.
     */
    static getLogEntry(level: number, text: string, ex?: any): string;
    /**
     * Sets the default log level which is information.
     */
    static setDefault(): void;
    /**
     * Logs a text message and an optional exception on the fatal log level.
     * @param text A log message.
     * @param ex An optional exception object.
     */
    static fatal(text: string, ex?: any): void;
    /**
     * Logs a text message and an optional exception on the error log level.
     * @param text A log message.
     * @param ex An optional exception object.
     */
    static error(text: string, ex?: any): void;
    /**
     * Logs a text message and an optional exception on the warning log level.
     * @param text A log message.
     * @param ex An optional exception object.
     */
    static warning(text: string, ex?: any): void;
    /**
     * Logs a text message and an optional exception on the information log level.
     * @param text A log message.
     * @param ex An optional exception object.
     */
    static info(text: string, ex?: any): void;
    /**
     * Gets a value that indicates if the debug log level is enabled. Use this before logging large debug messages.
     *
     * @returns True if the debug log level is enabled
     */
    static isDebug(): boolean;
    /**
     * Sets the current log level to debug.
     */
    static setDebug(): void;
    /**
     * Logs a text message and an optional exception on the debug log level.
     * @param text A log message.
     * @param ex An optional exception object.
     */
    static debug(text: string, ex?: any): void;
    /**
     * Gets a value that indicates if the trace log level is enabled. Use this before logging large trace messages.
     *
     * @returns True if the trace log level is enabled
     */
    static isTrace(): boolean;
    /**
     * Sets the current log level to trace.
     */
    static setTrace(): void;
    /**
     * Logs a text message and an optional exception on the trace log level.
     * @param text A log message.
     * @param ex An optional exception object.
     */
    static trace(text: string, ex?: any): void;
    /**
     * Gets a military time string with hours, minutes, seconds and milliseconds on the format hh:mm:ss,ttt.
     * @returns A military time string.
     */
    private static getTime;
    private static log;
}
/**
 * Interface for custom log appender callback functions.
 *
 * A log appender function can be used to get all logs from the Log class for the current log level.
 *
 * @since 1.0
 */
export interface ILogAppender {
    (level: number, text: string, ex?: any): any;
}
/**
 * Represents options for number formatting.
 *
 * @since 1.0
 */
export interface INumberFormatOptions {
    /**
     * Gets or sets the decimal separator character.
     */
    separator?: string;
}
/**
 * Represents options for sort functions in the {@link ArrayUtil} class.
 *
 * @since 1.0
 */
export interface ISortOptions {
    /**
     * Gets or sets a value that indicates if sorting should ignore case.
     * The default value is false. If this setting is set to true all values will be converted to strings when sorting.
     */
    ignoreCase?: boolean;
    /**
     * Options for LocaleCompare sorting
     * (https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/localeCompare).
     * If set, sorting will be based on locale. Set as empty object for default settings.
     * @since 1.0.30
     */
    localeOptions?: ILocaleSortOptions;
}
/**
 * Locale specific sort options.
 * @since 1.0.30
 */
export interface ILocaleSortOptions {
    /**
     * BCP 47 compliant locale string.
     * If omitted, the configured Ming.le locale will be used.
     */
    locale?: string;
    /**
     * The locale matching algorithm to use. Possible values are "lookup" and "best fit"; the default is "best fit".
     */
    localeMatcher?: "lookup" | "best fit";
    /**
     * Whether the comparison is for sorting or for searching for matching strings.
     * Possible values are "sort" and "search"; the default is "sort".
     */
    usage?: "sort" | "search";
    /**
     * Which differences in the strings should lead to non-zero result values.
     *
     * Possible values are:
     * "base": Only strings that differ in base letters compare as unequal. Examples: a ≠ b, a = á, a = A.
     * "accent": Only strings that differ in base letters or accents and other diacritic marks compare as unequal.
     * Examples: a ≠ b, a ≠ á, a = A.
     * "case": Only strings that differ in base letters or case compare as unequal. Examples: a ≠ b, a = á, a ≠ A.
     * "variant": Strings that differ in base letters, accents and other diacritic marks, or case compare as unequal.
     * Other differences may also be taken into consideration.
     * Examples: a ≠ b, a ≠ á, a ≠ A.
     * The default is "variant" for usage "sort"; it's locale dependent for usage "search".
     */
    sensitivity?: "base" | "accent" | "case" | "variant";
    /**
     * Whether punctuation should be ignored. Possible values are true and false; the default is false.
     */
    ignorePunctuation?: boolean;
    /**
     * Whether numeric collation should be used, such that "1" < "2" < "10".
     * Possible values are true and false; the default is false.
     * This option can be set through an options property or through a Unicode extension key; if both are provided,
     * the options property takes precedence. Implementations are not required to support this property.
     */
    numeric?: boolean;
    /**
     * Whether upper case or lower case should sort first.
     * Possible values are "upper", "lower", or "false" (use the locale's default); the default is "false".
     * This option can be set through an options property or through a Unicode extension key; if both are provided,
     * the options property takes precedence. Implementations are not required to support this property.
     */
    caseFirst?: "upper" | "lower" | "false";
}
