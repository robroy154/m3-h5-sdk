import { ViewContainerRef } from "@angular/core";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
/**
 * Represents the content translation service.
 * @since 1.0.22
 */
export interface ITranslationService {
    isEnabled(): boolean;
    translate(options: ITranslationOptions): Observable<ITranslationResult>;
    getLanguage(): string;
}
/**
 * Content translation service.
 * @since 1.0.22
 */
export declare class TranslationService implements ITranslationService {
    private instance;
    initialize(instance: ITranslationService): void;
    /**
     * Gets a value that indicates if content translation is enabled.
     * This function must be called before translation is enabled in a widget.
     */
    isEnabled(): boolean;
    /**
     * Shows a dialog for content translation.
     * @param options dialog options
     * @returns an Observable that will be resolved to an ITranslationResult if the user
     * closes the dialog with OK or rejected if the user closes the dialog with cancel.
     */
    translate(options: ITranslationOptions): Observable<ITranslationResult>;
    /**
     * Gets the current language code.
     */
    getLanguage(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<TranslationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TranslationService>;
}
/**
 * Represents content translation options.
 * @since 1.0.22
 */
export interface ITranslationOptions {
    /**
     * Gets or sets the parent view for the content translation dialog.
     * This property is mandatory in most cases.
     */
    view?: ViewContainerRef;
    /**
     * Gets or sets an item to translate.
     * This property cannot be used in combination with the items property.
     */
    item?: ITranslationItem;
    /**
     * Gets or sets an array of items to translate.
     * This property cannot be used in combination with the item property.
     */
    items?: ITranslationItem[];
    /**
     * Gets or sets the data to translate.
     *
     * The data should be dictionary in one of two formats.
     * Single item format is language code -> translated string
     * Multi item format is language code -> translated string dictionary
     *
     * Use single item format in combination with the item property.
     * Use multi item format in combination with the items property.
     */
    data?: any;
}
/**
 * Represents a content translation result.
 * @since 1.0.22
 */
export interface ITranslationResult {
    data?: any;
}
/**
 * Represents a content translation item.
 * @since 1.0.32
 */
export interface ITranslationItem {
    /**
     * Gets or sets the label of the item to translate.
     */
    label: string;
    /**
     * Sets the property name of the item.
     *
     * This property will be used in the translation data dictionary.
     * This property is optional in the single item format.
     */
    name: string;
    /**
     * Gets or sets the max lenght of the translated string.
     */
    maxLength: number;
    /**
     * Gets or sets a value that indicates if the item should be displayed in a text area.
     * The default is a single line input field.
     */
    isTextArea?: boolean;
    /**
     * Gets or sets a value that indicates if the item should be displayed in a markdown component.
     *
     * @since 2.3.0
     */
    isMarkdown?: boolean;
    /**
     * Gets or sets the default value that will be used when a translation is missing.
     * This value will be used as a hint text in the content translation dialog.
     */
    defaultValue?: string;
    /**
     * Gets or sets a unique label ID.
     */
    labelId?: string;
    /**
     * Gets or sets a unique input / text area ID.
     */
    valueId?: string;
    /**
     * Gets or sets the required property, which is used in the translations UI.
     * It is used to indicate to the user that translation of this item is required.
     * This value is true by default. If true, this item must be translated.
     * If all item translations are optional for a given language, at least one must be translated.
     */
    isRequired?: boolean;
}
