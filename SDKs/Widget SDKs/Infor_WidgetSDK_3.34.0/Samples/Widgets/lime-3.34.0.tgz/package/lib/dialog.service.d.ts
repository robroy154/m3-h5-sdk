import { SohoMessageService } from "ids-enterprise-ng";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
/**
 * Defines standard button combinations for a message dialog.
 *
 * @since 1.0
 */
export declare enum StandardDialogButtons {
    /**
     * Shows an OK button (1).
     */
    Ok = 1,
    /**
     * Shows an OK button and a Cancel button (2).
     */
    OkCancel = 2,
    /**
     * Shows a Yes and a No button (3).
     */
    YesNo = 3,
    /**
     * Shows a Yes, No and a Cancel button (4).
     */
    YesNoCancel = 4
}
/**
 * Defines the different types of buttons that can be used in dialogs.
 *
 * @since 1.0
 */
export declare enum DialogButtonType {
    /**
     * No button is used or the button is unknown (1).
     */
    None = 1,
    /**
     * OK button (2).
     */
    Ok = 2,
    /**
     * Cancel button (3).
     */
    Cancel = 3,
    /**
     * Yes button (4).
     */
    Yes = 4,
    /**
     * No button (5).
     */
    No = 5,
    /**
     * Custom button (6).
     */
    Custom = 6
}
/**
 * Represents the result from a closed dialog.
 *
 * @since 1.0
 */
export interface IDialogResult {
    /**
     * Gets or sets the type of button clicked, defined in {@link DialogButtonType}.
     *
     * This property might not be set depending on how the dialog was dismissed.
     */
    button?: DialogButtonType;
    /**
     * Gets or sets an optional result value.
     *
     * This property can be used for a result value object of any type in custom dialog scenarios.
     */
    value?: any;
}
/**
 * Represents options for a message dialog.
 *
 * Use either the buttons or standardButtons property.
 *
 * @example
 * Example options for a message with the standrad buttons Yes and No:
 * ```ts
 *		var options: lm.IMessageDialogOptions = {
 *			title: "Confirm Delete",
 *			message: "Are you sure that you want to delete the selected item?",
 *			standardButtons: s.StandardDialogButtons.YesNo
 *		}
 * ```
 *
 * @example
 * Example options for a message with custom buttons:
 * ```ts
 *		var options: lm.IMessageDialogOptions = {
 *			title: "Remove Widget",
 *			message: "Are you sure that you want to remove the widget?",
 *			buttons: [{
 *				text: "Remove it!",
 *				value: "Yes",
 *				isDefault: true
 *			}, {
 *					text: "Keep it!",
 *					value: "No",
 *					isDefault: false
 *			}]
 *		}
 * ```
 *
 * @since 1.0
 */
export interface IMessageDialogOptions {
    /**
     * Gets or sets the dialog title.
     */
    title: string;
    /**
     * Gets or sets the dialog message.
     */
    message: string;
    /**
     * Gets or sets an optional array of dialog buttons.
     *
     * Use this property or the standardButtons property.
     */
    buttons?: IDialogButton[];
    /**
     * Gets or sets an optional stanard button configuration.
     *
     * Use this property or the buttons property.
     */
    standardButtons?: StandardDialogButtons;
    /**
     * Gets or sets an optional value that indicates if this is an error message.
     *
     * If this property is set to true the message dialog title will be shown with the error styling.
     */
    isError?: boolean;
    /**
     * Sets css class on modal.
     */
    cssClass?: string;
    /**
     * Specifies wether or not to automatically set primary button styling.
     *
     * True is default.
     */
    hasPrimaryButton?: boolean;
}
/**
 * Represents a dialog button.
 *
 * @since 1.0
 */
export interface IDialogButton {
    /**
     * Gets or sets the text to display on the button.
     */
    text: string;
    /**
     * Gets or sets the type of button defined in {@link DialogButtonType}.
     */
    type?: any;
    /**
     * Gets or sets an optional value object that will be returned in the {@link IDialogResult} if set.
     */
    value?: any;
    /**
     * Gets or sets an optional ID for the button.
     */
    id?: string;
    /**
     * Gets or sets an optional value that indicates if the button is a link.
     */
    isLink?: boolean;
    /**
     * Gets or sets an optional value that indicates if the button is the default button.
     */
    isDefault?: boolean;
    /**
     * Gets or sets an optional svg icon path for the button
     */
    icon?: string;
    /**
     * Gets or sets an optional css class for the dialog button
     */
    cssClass?: string;
}
/**
 * Represents options for a toast message.
 *
 * @since 1.0
 */
export interface IToastOptions {
    /**
     * Gets or sets the toast title.
     */
    title: string;
    /**
     * Gets or sets the toast message.
     */
    message: string;
    /**
     * Sting that stated where the toast should be displayed
     *
     * Possible values: top right, top left, bottom left, bottom right
     */
    position?: string;
    /**
     * States whether the notification should be audible only.
     */
    audibleOnly?: boolean;
    /**
     * States whether or not to display a progress bar.
     */
    progressBar?: boolean;
    /**
     * States for how long the toast should be visible (milliseconds).
     */
    timeout?: number;
}
/**
 * Represents options for a dialog.
 *
 * @since 1.0
 */
export interface IDialogOptions {
    /**
     * Gets or sets the dialog title.
     */
    title: string;
    /**
     * Gets or sets an optional parameter.
     *
     * If this property is set when showing a dialog it will be available on th {@link IDialog} instance.
     */
    parameter?: any;
    /**
     * Gets or sets an optional array of dialog buttons.
     *
     * This property should not be set if custom buttons are added in the dialog template.
     */
    buttons?: IDialogButton[];
    /**
     * Gets or sets an optional style string that will be applied to the modal dialog instance.
     */
    style?: string;
    /**
     * Gets or sets an optional CSS class that will be applied to the modal dialog instance.
     */
    cssClass?: string;
    /**
     * Gets or sets an optional ID of the modal dialog instance.
     */
    id?: string;
    actionPanel?: boolean;
}
/**
 * Represents a dialog event.
 *
 * An instance of this type will be a parameter to the closing and closed events on the {@link IDialog}.
 *
 * @since 1.0
 */
export interface IDialogEvent {
    /**
     * Gets or sets the dialog instance that is the source of the event.
     */
    dialog: IDialog;
    /**
     * Gets or sets an optional value that indicates if the event should be cancelled.
     *
     * Note that only the closing event can currently be cancelled.
     */
    cancel?: boolean;
}
/**
 * Represents a modal dialog instance.
 *
 * The dialog instance can be retrieved from the scope in a dialog controller using the name "lmDialog".
 *
 * @since 1.0
 */
export interface IDialog {
    /**
     * Gets or sets a function that will be called when the dialog is closing.
     *
     * The closing of the dialog can be cancelled by setting the cancel property to true on the event parameter.
     */
    closing: (e: IDialogEvent) => void;
    /**
     * Gets or sets a function that will be called when the dialog is closed.
     */
    closed: (e: IDialogEvent) => void;
    /**
     * Gets or sets a function that will be called when the dialog is opened.
     */
    opened: (e: IDialogEvent) => void;
    /**
     * Gets or sets an optional parameter.
     *
     * This property will have the value set on the {@link IDialogOptions} instance when showing the dialog.
     */
    parameter?: any;
    /**
     * Gets or sets the dialog result.
     */
    result?: IDialogResult;
    /**
     * Closes the dialog.
     *
     * @param result Optional dialog result. The result property will be set if a value is provided.
     */
    close(result?: IDialogResult): void;
}
/**
 * Represents options for the copy to clipboard function.
 *
 * @since 1.0
 */
export interface ICopyToClipboardOptions {
    /**
     * Data to be copied or displayed in message modal if copying is not possible.
     */
    copyData: string;
    /**
     * If true, opens a dialog containing the string to be copied, regardless of direct copying is possible.
     */
    forceDialog?: boolean;
}
/**
 * Represent the dialog service that can be use to show standard message dialogs or dialogs with custom content.
 *
 * @since 1.0.17
 */
export declare class DialogService {
    protected readonly messageService: SohoMessageService;
    private language;
    private messageFunction;
    constructor(messageService: SohoMessageService);
    /**
     * Shows a message dialog.
     *
     * @param options The message dialog options.
     * @returns An Observable that can be used to subscribe to the dialog result.
     */
    showMessage(options: IMessageDialogOptions): Observable<IDialogResult>;
    /**
     * Copies data to clipboard or opens a dialog with the data to copy if copying is not possible.
     * @param options The copy to clipboard options
     */
    copyToClipboard(options: ICopyToClipboardOptions): void;
    /**
     * Shows a toast notification with the specified options.
     *
     * Defaults position to "bottom right" and timeout to 3000 if not set.
     */
    showToast(options: IToastOptions): void;
    private initLanguage;
    private setDefaultButtons;
    private setSpecificButtons;
    private resolveMessageDialog;
    static ɵfac: i0.ɵɵFactoryDeclaration<DialogService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DialogService>;
}
