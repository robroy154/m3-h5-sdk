import * as i0 from '@angular/core';
import { Injectable, InjectionToken } from '@angular/core';
import { AsyncSubject, EMPTY } from 'rxjs';
import * as i1 from 'ids-enterprise-ng';

/**
 * Utility class for array operations.
 *
 * @since 1.0
 */
class ArrayUtil {
    /**
     * Checks if an item exists in an array.
     * @returns True if an item exists.
     */
    static contains(array, value) {
        if (array) {
            return $.inArray(value, array) >= 0;
        }
        return false;
    }
    /**
     * Gets the index of a value in an array.
     * @param array Array to get value index from.
     * @param value Value to get index of.
     * @returns index of value.
     */
    static indexOf(array, value) {
        return $.inArray(value, array);
    }
    /**
     * Sorts the array in acending order of the given property.
     * @param array Array to sort.
     * @param property Property to sort array by.
     * @param options Optional options for controlling the sorting.
     * @returns The sorted array.
     */
    static sortByProperty(array, property, options) {
        const ignoreCase = options && options.ignoreCase;
        const sortByLocale = options && options.localeOptions;
        if (sortByLocale) {
            const defaultOptions = { numeric: true };
            options.localeOptions = options.localeOptions
                ? options.localeOptions
                : {};
            let localeOptions = options.localeOptions;
            localeOptions = localeOptions ? localeOptions : defaultOptions;
            localeOptions.locale = localeOptions.locale
                ? localeOptions.locale
                : Soho.Locale.currentLocale.name;
        }
        return array.sort((x, y) => {
            const xProp = x[property];
            const yProp = y[property];
            // Use concatenation instead of toString to avoid crashes for missing properties
            const a = ignoreCase
                ? ("" + xProp).toLocaleLowerCase()
                : xProp;
            const b = ignoreCase
                ? ("" + yProp).toLocaleLowerCase()
                : yProp;
            if (sortByLocale && UIUtil.localeCompareSupportsLocales()) {
                return a.localeCompare(b, options.localeOptions.locale, options.localeOptions);
            }
            else {
                if (a > b) {
                    return 1;
                }
                else if (a < b) {
                    return -1;
                }
            }
            return 0;
        });
    }
    /**
     * Removes an item in an array.
     */
    static remove(array, item) {
        const index = $.inArray(item, array);
        if (index >= 0) {
            array.splice(index, 1);
        }
    }
    /**
     * Removes an item in an array by matching the value of a specific property.
     *
     * @param array the array to remove an item from
     * @param name the name of the propery
     * @param value that value that the property should match
     * @returns the removed item or null if the item could not be found
     */
    static removeByProperty(array, name, value) {
        for (let i = 0; i < array.length; i++) {
            if (array[i][name] === value) {
                return array.splice(i, 1)[0];
            }
        }
        return null;
    }
    /**
     * Removes the first item in an array that matches a predicate function.
     *
     * @param array the array to remove an item from
     * @param predicate a predicate function that returns true for a matching item in the array
     * @returns the removed item or null if the item could not be found
     */
    static removeByPredicate(array, predicate) {
        for (let i = 0; i < array.length; i++) {
            if (predicate(array[i])) {
                return array.splice(i, 1)[0];
            }
        }
        return null;
    }
    /**
     * Finds the index of an item in an array that matches a predicate function.
     *
     * @param array the arrary to find an item in
     * @param predicate a predicate function that returns true for a matching item in the array
     * @returns the index of the item or -1 if the item could not be found
     */
    static indexByPredicate(array, predicate) {
        for (let i = 0; i < array.length; i++) {
            if (predicate(array[i])) {
                return i;
            }
        }
        return -1;
    }
    /**
     * Gets the index of an item in an array by matching the value of a specific property.
     */
    static indexByProperty(array, name, value) {
        if (array) {
            for (let i = 0; i < array.length; i++) {
                const item = array[i];
                if (item) {
                    if (item[name] === value) {
                        return i;
                    }
                }
            }
        }
        return -1;
    }
    /**
     * Gets the item in an array by matching the value of a specific property.
     */
    static itemByProperty(array, name, value) {
        const index = this.indexByProperty(array, name, value);
        return index >= 0 ? array[index] : null;
    }
    /**
     * Gets the item matching the predicate.
     */
    static itemByPredicate(array, predicate) {
        for (const item of array) {
            if (predicate(item)) {
                return item;
            }
        }
        return null;
    }
    /**
     * Filters an array based on a predicate.
     */
    static filterByPredicate(array, predicate) {
        const target = [];
        for (const item of array) {
            if (predicate(item)) {
                target.push(item);
            }
        }
        return target;
    }
    /**
     * Checks if an item exists in an array by matching the value of a specific property.
     * @ returns True if an item with the property and value exists.
     */
    static containsByProperty(array, name, value) {
        return this.indexByProperty(array, name, value) >= 0;
    }
    /**
     * Gets the last item in an array.
     * @returns The last item or null if the array is null or empty.
     */
    static last(array) {
        if (array && array.length > 0) {
            return array[array.length - 1];
        }
        return null;
    }
    /**
     * Finds the first item in the array that matches the conditions defined in the predicate function.
     * @param array An array of items to search.
     * @param predicate A predicate function that should return true if the item parameter matches the predicate condition.
     */
    static find(array, predicate) {
        if (array) {
            for (const item of array) {
                if (predicate(item)) {
                    return item;
                }
            }
        }
        return null;
    }
    /**
     * Finds all items in the array that matches the conditions defined in the predicate function.
     * @param array An array of items to search.
     * @param predicate A predicate function that should return true if the item parameter matches the predicate condition.
     */
    static findAll(array, predicate) {
        if (array) {
            const arr = [];
            for (const item of array) {
                if (predicate(item)) {
                    arr.push(item);
                }
            }
            return arr;
        }
        return null;
    }
    /**
     * Creates an array of n entries with the specified default value.
     * @params n            Number of entries.
     * @params defaultValue The default values of the entries.
     * @returns Array.
     */
    static array(n, defaultValue) {
        const arr = new Array(n);
        for (let j = 0; j < n; j++) {
            arr[j] = defaultValue;
        }
        return arr;
    }
    /**
     * Creates a matrix (two dimensional array) with specified default values.
     * @param rows     The number of rows in the matrix.
     * @params columns The number of columns in the matrix.
     * @returns matrix.
     */
    static matrix(rows, columns, defaultValue) {
        const matrix = new Array(rows);
        for (let i = 0; i < matrix.length; i++) {
            const cols = new Array(columns);
            for (let j = 0; j < columns; j++) {
                cols[j] = defaultValue;
            }
            matrix[i] = ArrayUtil.array(columns, defaultValue);
        }
        return matrix;
    }
    /**
     * Moves a object in an array to another index.
     */
    static move(array, index, newIndex) {
        if (newIndex >= array.length) {
            let k = newIndex - array.length;
            while (k-- + 1) {
                array.push(undefined);
            }
        }
        array.splice(newIndex, 0, array.splice(index, 1)[0]);
    }
    /**
     * Swaps two items in an array
     *
     * @param items the array
     * @param index1 the index of the first item
     * @param index2 the index of the second item
     * @throws RangeError if either indices are out of bounds
     *
     * @since 1.0.17
     */
    static swap(items, index1, index2) {
        const isValidIndex = (i) => i >= 0 && i < items.length;
        if (!isValidIndex(index1) || !isValidIndex(index2)) {
            throw new RangeError(`swap(): Indices ${index1}, ${index2} are out of bounds for array of length ${items.length}`);
        }
        const temp = items[index1];
        items[index1] = items[index2];
        items[index2] = temp;
    }
    /**
     * Safely concatenates two arrays.
     *
     * @param items the first array
     * @param items2 the second array
     *
     * @since 1.0.27
     */
    static concat(items, items2) {
        if (!(items || items2)) {
            return [];
        }
        if (items && items2) {
            return [...items, ...items2];
        }
        else if (items) {
            return items;
        }
        else if (items2) {
            return items2;
        }
    }
    /**
     * Rotate array to the left a given number of clicks.
     * @example
     * rotateArray([1,2,3,4], 1) // [2,3,4,1]
     * @param array An array
     * @param clicks A positive integer
     *
     * @since 1.0.34
     */
    static rotateLeft(array, clicks) {
        if (clicks === 0 || array.length === 0) {
            return array;
        }
        else {
            const [first, ...rest] = array;
            return ArrayUtil.rotateLeft([...rest, first], clicks - 1);
        }
    }
}
/**
 * Number utility functions.
 *
 * @since 1.0
 */
class NumUtil {
    static { this.defaultSeparator = NumUtil.getLocaleSeparator(); }
    static { this.defaultOptions = {
        separator: NumUtil.defaultSeparator,
    }; }
    /**
     * Gets the default options used by the functions in the class.
     * @returns The default options.
     */
    static getDefaultOptions() {
        return NumUtil.defaultOptions;
    }
    /**
     * Sets the default options used by the functions in the class.
     * @options The default options.
     */
    static setDefaultOptions(options) {
        NumUtil.defaultOptions = options;
        if (options.separator) {
            NumUtil.defaultSeparator = options.separator;
        }
    }
    /**
     * Gets a values that indicates if the parameter is a number.
     *
     * The value is considered to be a number if it can be parsed as a float, it is a number and it is finite.
     * @param n The value to check.
     * @returns True if the value is a number.
     */
    static isNumber(n) {
        return !isNaN(parseFloat(n)) && isFinite(n);
    }
    /**
     * Gets an integer value from a string.
     * @param s The string to parse.
     * @param defaultValue Optional default value to return if the string cannot be parsed. The default is zero.
     * @returns An integer parsed from the string or the default value.
     */
    static getInt(s, defaultValue = 0) {
        if (s) {
            try {
                return parseInt(s) || defaultValue;
            }
            catch (e) { }
        }
        return defaultValue;
    }
    /**
     * Formats a number or string using default or specified formatting options.
     *
     * This function currently only supports formatting using a specified decimal separator.
     * The value to format is expected to be either a number or a string containing a number where any
     * decimal separator is dot (.). If the value is a string it may not contain any thousand separators
     * or other formatting characters.
     *
     * @param value The value to format which can be a number or a number in string format.
     * @param options Optional formatting options.
     */
    static format(value, options) {
        let s = value.toString();
        if ("" === s) {
            return s;
        }
        let separator = options
            ? options.separator
            : NumUtil.defaultOptions.separator;
        if (!separator) {
            separator = NumUtil.defaultSeparator;
        }
        s = s.replace(".", separator);
        return s;
    }
    /**
     * Pads a number with leading zeroes up to the specified length.
     * @param num The number to pad.
     * @param length The length of the string.
     */
    static pad(num, length) {
        let s = num + "";
        while (s.length < length) {
            s = "0" + s;
        }
        return s;
    }
    /**
     * Gets a value that indicates if the string contains only integers (1234567890).
     * @param s The string value to check.
     * @returns True if string contains only integers.
     */
    static hasOnlyIntegers(s) {
        if (!s) {
            return false;
        }
        const digits = "1234567890";
        for (let i = 0; i < s.length; i++) {
            if (digits.indexOf(s.charAt(i)) === -1) {
                return false;
            }
        }
        return true;
    }
    /**
     * Calculate the remainder between the dividend and the divisor. (dividend mod divisor)
     * @param dividend
     * @param divisor
     *
     * @since 1.0.32
     */
    static mod(dividend, divisor) {
        return ((dividend % divisor) + divisor) % divisor;
    }
    /**
     * Gets a random integer between the min and max values.
     * @param min The min integer value
     * @param max The max integer value
     * @returns A random integer.
     *
     * @since 2.0.0
     */
    static randomInt(min, max) {
        return Math.floor(Math.random() * (max - min + 1) + min);
    }
    static getLocaleSeparator() {
        const n = 1.1;
        const s = n.toLocaleString().substring(1, 2);
        return s;
    }
}
/**
 * Common Utility functions.
 *
 * @since 1.0
 */
class CommonUtil {
    static { this.chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"; }
    /**
     * Copies an object using JSON stringify and parse.
     *
     * The object to copy must be valid as JSON. Note the limitations with Date object
     * JSON serialization (avoid using this function with Date if unsure).
     *
     * @param value the object to copy
     * @returns	a copy of the input object
     *
     * @since 1.0.22
     */
    static copyJson(value) {
        return JSON.parse(JSON.stringify(value));
    }
    /**
     * Gets the local date string.
     * Options can be used to set the formatting, for example: `{ date: "short" }` or `{ pattern: "yyyy-MM-dd HH:mm" }`.
     * @params dateString Date string.
     * @params options    Options for fromatting.
     * @returns string    Formatted date.
     */
    static getLocaleDateString(dateString, options) {
        try {
            const date = new Date(dateString);
            if (!options) {
                options = { date: "datetime" }; // Locale datetime is used if available otherwise pattern is used
            }
            return Soho.Locale.formatDate(date, options);
        }
        catch (ex) {
            return dateString;
        }
    }
    /**
     * Delets a property of an object.
     * @param object   Object of which to delete a property.
     * @param property Property to delete.
     */
    static deleteProperty(object, property) {
        if (!CommonUtil.isUndefined(object[property])) {
            delete object[property];
        }
    }
    /**
     * Converts a boolean from a string.
     * @param string       String to convert.
     * @param defaultValue Default return value if string can't be used.
     */
    static getBoolean(s, defaultValue = false) {
        if (s && s.length > 0) {
            return s[0].toLowerCase() === "t";
        }
        return defaultValue;
    }
    /**
     * @deprecated
     * @param prefix
     * @since 1.0.28
     */
    static getUuid(prefix) {
        return (prefix +
            (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1) +
            (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1));
    }
    /**
     * Checks for undefined. Returns true if the object has a value, eg not undefined and not null.
     * @param anyObject Any object
     * @since 1.0.28
     */
    static hasValue(anyObject) {
        if (typeof anyObject !== "undefined") {
            return anyObject != null;
        }
        return false;
    }
    /**
     * Checks if undefined. Returns true if undefined.
     * @param anyObject Any object
     * @since 1.0.28
     */
    static isUndefined(anyObject) {
        return typeof anyObject === "undefined";
    }
    /**
     * Checks if the object is a boolean.
     * @param anyObject Any object
     * @since 1.0.28
     */
    static isBoolean(anyObject) {
        return typeof anyObject === "boolean";
    }
    /**
     * Checks if an arbitrary object has a specific function defined or not.
     * @param anyObject
     * @param functionName
     */
    static hasFunction(anyObject, functionName) {
        return typeof anyObject[functionName] === "function";
    }
    /**
     * Creates a string with random uppercase letters and numbers.
     * The default length is 16 if the stringLength parameter is omitted.
     */
    static random(stringLength = 16) {
        const chars = CommonUtil.chars;
        let randomstring = "";
        for (let i = 0; i < stringLength; i++) {
            const rnum = Math.floor(Math.random() * chars.length);
            randomstring += chars.substring(rnum, rnum + 1);
        }
        return randomstring;
    }
    /**
     * Gets a value that indicates if the current window is an IFrame or not.
     */
    static isIframe() {
        try {
            return window.self !== window.top;
        }
        catch (e) {
            return true;
        }
    }
    /**
     * Returns the client's date as yyyy-mm-ddThh:mm
     * Ex: 2015-01-20T21:20
     */
    static getClientDate() {
        const addZero = (dateNr) => {
            let dateString;
            if (dateNr < 10) {
                dateString = dateNr.toString();
                dateString = "0" + dateString;
            }
            else {
                dateString = dateNr.toString();
            }
            return dateString;
        };
        const date = new Date(Date.now());
        const year = date.getFullYear();
        const month = addZero(date.getMonth() + 1);
        const day = addZero(date.getDate());
        const hours = addZero(date.getHours());
        const min = addZero(date.getMinutes());
        return year + "-" + month + "-" + day + "T" + hours + ":" + min;
    }
    /**
     * Detects IE version and sets it as a class on the html element.
     */
    static detectBrowser() {
        if (navigator.userAgent.match(/Trident/)) {
            $("html").addClass("ie");
        }
        if (navigator.appVersion.indexOf("MSIE 9.0") > -1) {
            $("html").addClass("ie9");
        }
        if (navigator.appVersion.indexOf("MSIE 10.0") > -1) {
            $("html").addClass("ie10");
        }
        if (navigator.userAgent.match(/Trident\/7\./)) {
            $("html").addClass("ie11");
        }
    }
}
/**
 * String utility functions.
 *
 * @since 1.0
 */
class StringUtil {
    /**
     * Gets a value that indicates if the string is null, undefined, empty or contains only whitespace.
     * @param value The string to check.
     * @returns True if the string is null, undefined, empty or contains only whitespace.
     */
    static isNullOrWhitespace(value) {
        return !value || !value.trim();
    }
    /**
     * Returns true if the value is a string.
     * @param value An object that needs to be checked if it is a String or not
     */
    static isString(value) {
        if (typeof value === "string" || value instanceof String) {
            return true;
        }
        return false;
    }
    /**
     * Gets a value that indicates if a string starts with a specified value.
     * @param value The string value to check.
     * @param prefix The value that the string should start with.
     * @returns True if the string starts with the specified prefix value.
     */
    static startsWith(value, prefix) {
        return value ? value.indexOf(prefix) === 0 : false;
    }
    static replaceParameters(template, resolveFunction) {
        template = template.replace(/{(.*?)}/g, (substring, key) => {
            const value = resolveFunction(key);
            return typeof value !== "undefined" ? value : "";
        });
        return template;
    }
    /**
     * Gets a value that indicates if a string ends with a specified value.
     * @param value The string value to check.
     * @param prefix The value that the string should end with.
     * @returns True if the string ends with the specified suffix value.
     */
    static endsWith(value, suffix) {
        if (!value) {
            return false;
        }
        return value.indexOf(suffix, value.length - suffix.length) !== -1;
    }
    /**
     * Trims whitespace from the end of a string.
     * @param value The value to trim.
     * @returns The trimmed value.
     */
    static trimEnd(value) {
        return value.replace(/\s+$/, "");
    }
    /**
     * Replaces all occurrences of a string in a string.
     * @param value the string to replace strings in
     * @param find the string to find
     * @param replace the string to replace
     *
     * @since 1.0.29
     */
    static replaceAll(value, find, replace) {
        return value.replace(new RegExp(find, "g"), replace);
    }
    static format(...args) {
        let stringValue = "missing";
        try {
            stringValue = args[0];
            const params = Array.prototype.slice.call(args, 1);
            stringValue = stringValue.replace(/{(\d+)}/g, function () {
                const value = params[arguments[1]];
                return typeof value !== "undefined" ? value : arguments[0];
            });
        }
        catch (ignore) { }
        return stringValue;
    }
    static splitTagString(value) {
        return this.splitAndInsert(value, "#", " ");
    }
    static splitAndInsert(value, splitChar, insertChar) {
        if (this.isNullOrWhitespace(value)) {
            return value;
        }
        const values = value.split(splitChar);
        let newString = "";
        for (const entry of values) {
            if (!this.isNullOrWhitespace(entry)) {
                if (newString === "") {
                    newString = "#" + entry;
                }
                else {
                    newString = newString + " #" + entry;
                }
            }
        }
        return newString;
    }
    /**
     * Joins an array of object using a preticate and returns a string.
     * @param array An array of objects
     * @param predicate A predicate to select the string from the object that should be used in the join
     * @param splitChar Optional separator, default is comma.
     * @since 1.0.30
     */
    static join(array, predicate, splitChar) {
        if (!array || array.length === 0) {
            return null;
        }
        const stringArray = [];
        for (const element of array) {
            const result = predicate(element);
            stringArray.push(result);
        }
        const separator = splitChar ? splitChar : ",";
        return stringArray.join(separator);
    }
    /**
     * Removes all spaces " " in a text and inputs "-" instead. Also escapes the text
     * Used to format the text to be usable in id and name attribute.
     */
    static formatTextForId(text, defaultText) {
        try {
            const escapedText = HtmlUtil.escapeStringForHtml(text);
            const trimmedText = escapedText.trim();
            const replacedText = trimmedText.replace(/ |\./g, "-");
            const lowercaseText = replacedText.toLowerCase();
            return lowercaseText;
        }
        catch (ex) {
            return defaultText || "item";
        }
    }
}
/**
 * HTML utility functions for creating and manipulating HTML elements.
 *
 * @since 1.0
 */
class HtmlUtil {
    /**
     * Creates an iframe element without borders and the sandbox attribute set.
     */
    static iframe(url, name) {
        const iframe = $("<iframe />")
            .attr("sandbox", "allow-same-origin allow-scripts allow-popups allow-forms allow-downloads")
            .attr("seamless", "seamless")
            .attr("frameborder", "0")
            .addClass("lm-fill-absolute");
        if (url) {
            iframe.attr("src", url);
        }
        if (name) {
            iframe.attr("name", name);
        }
        return iframe;
    }
    static destroyIFrame(iframe) {
        if (!iframe) {
            return;
        }
        const logPrefix = "[HtmlUtil] destroyIFrame: ";
        if (Log.isDebug) {
            Log.debug(logPrefix + iframe.attr("src"));
        }
        try {
            iframe.attr("src", "about:blank");
        }
        catch (ex2) {
            Log.warning(logPrefix + "Failed to navigate iframe", ex2);
        }
        try {
            iframe.remove();
        }
        catch (ex2) {
            Log.warning(logPrefix + "Failed to remove iframe", ex2);
        }
    }
    /**
     * Returns a string that has been escaped so it can safely be used within an HTML element.
     * Use this method to avoid XSS when inserting untrusted content into HTML elements.
     * Read more at https://www.owasp.org/index.php/XSS_(Cross_Site_Scripting)_Prevention_Cheat_Sheet#RULE_.231_-_HTML_Escape_Before_Inserting_Untrusted_Data_into_HTML_Element_Content.
     * @param content String to be escaped
     * @returns Escaped content
     */
    static escapeStringForHtml(content) {
        if (content && content.length > 0) {
            content = content
                .replace(/&/g, "&amp;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;")
                .replace(/"/g, "&quot;")
                .replace(/'/g, "&#x27;")
                .replace(/\//g, "&#x2F;");
        }
        return content;
    }
    /**
     * Escapes all properties of the given object that are strings, so it can safely be used within an HTML element.
     * @param obj Object to be escaped
     * @returns Escaped content
     */
    static escapeObjectStringsForHtml(obj) {
        for (const prop in obj) {
            if (obj.hasOwnProperty(prop) && typeof obj[prop] === "string") {
                obj[prop] = HtmlUtil.escapeStringForHtml(obj[prop]);
            }
        }
        return obj;
    }
}
/**
 * Log text messages and exceptions on different log levels to the browser console and optional custom log appenders.
 *
 * **Example:**
 *
 * import Log = require("log");
 * Log.info("Application initialized");
 *
 * @since 1.0
 */
class Log {
    /**
     * Fatal log level. Severe errors that prevents the application from functioning.
     */
    static { this.levelFatal = 0; }
    /**
     * Error log level.
     */
    static { this.levelError = 1; }
    /**
     * Warning log level.
     */
    static { this.levelWarning = 2; }
    /**
     * Information log level.
     */
    static { this.levelInfo = 3; }
    /**
     * Debug log level. Detailed information for debug purposes.
     */
    static { this.levelDebug = 4; }
    /**
     * Trace log level. Most detailed information for debug purposes.
     */
    static { this.levelTrace = 5; }
    /**
     * Gets or sets the current log level. The default log level is information.
     */
    static { this.level = Log.levelInfo; }
    /**
     * Gets or sets a value that indicates if logging to the browser console is enabled.
     * The default value is true.
     */
    static { this.isConsoleLogEnabled = true; }
    static { this.prefixes = [
        "[FATAL]",
        "[ERROR]",
        "[WARNING]",
        "[INFO]",
        "[DEBUG]",
        "[TRACE]",
    ]; }
    static { this.appenders = []; }
    /**
     * Adds a new log appender that will receive log entries for the current log level.
     * @param A log appender.
     */
    static addAppender(appender) {
        Log.appenders.push(appender);
    }
    /**
     * Removes an existing log appender.
     * @param appender An existing appender to remove.
     */
    static removeAppender(appender) {
        ArrayUtil.remove(Log.appenders, appender);
    }
    /**
     * Gets a formatted log entry.
     * @param level The log level.
     * @param ex An optional exception object.
     */
    static getLogEntry(level, text, ex) {
        let logText = "[" + Log.getTime() + "] " + this.prefixes[level] + " " + text;
        if (ex) {
            const error = ex;
            const message = error.message;
            const stack = error.stack;
            if (stack) {
                if (message && stack.indexOf(message) < 0) {
                    logText += " " + message;
                }
                logText += " " + stack;
            }
            else if (message) {
                logText += " " + message;
            }
            else {
                logText += " " + ex;
            }
        }
        return logText;
    }
    /**
     * Sets the default log level which is information.
     */
    static setDefault() {
        this.level = this.levelInfo;
    }
    /**
     * Logs a text message and an optional exception on the fatal log level.
     * @param text A log message.
     * @param ex An optional exception object.
     */
    static fatal(text, ex) {
        this.log(this.level, this.levelFatal, text, ex);
    }
    /**
     * Logs a text message and an optional exception on the error log level.
     * @param text A log message.
     * @param ex An optional exception object.
     */
    static error(text, ex) {
        this.log(this.level, this.levelError, text, ex);
    }
    /**
     * Logs a text message and an optional exception on the warning log level.
     * @param text A log message.
     * @param ex An optional exception object.
     */
    static warning(text, ex) {
        this.log(this.level, this.levelWarning, text, ex);
    }
    /**
     * Logs a text message and an optional exception on the information log level.
     * @param text A log message.
     * @param ex An optional exception object.
     */
    static info(text, ex) {
        this.log(this.level, this.levelInfo, text, ex);
    }
    /**
     * Gets a value that indicates if the debug log level is enabled. Use this before logging large debug messages.
     *
     * @returns True if the debug log level is enabled
     */
    static isDebug() {
        return this.level >= this.levelDebug;
    }
    /**
     * Sets the current log level to debug.
     */
    static setDebug() {
        this.level = this.levelDebug;
    }
    /**
     * Logs a text message and an optional exception on the debug log level.
     * @param text A log message.
     * @param ex An optional exception object.
     */
    static debug(text, ex) {
        this.log(this.level, this.levelDebug, text, ex);
    }
    /**
     * Gets a value that indicates if the trace log level is enabled. Use this before logging large trace messages.
     *
     * @returns True if the trace log level is enabled
     */
    static isTrace() {
        return this.level >= this.levelTrace;
    }
    /**
     * Sets the current log level to trace.
     */
    static setTrace() {
        this.level = this.levelTrace;
    }
    /**
     * Logs a text message and an optional exception on the trace log level.
     * @param text A log message.
     * @param ex An optional exception object.
     */
    static trace(text, ex) {
        this.log(this.level, this.levelTrace, text, ex);
    }
    /**
     * Gets a military time string with hours, minutes, seconds and milliseconds on the format hh:mm:ss,ttt.
     * @returns A military time string.
     */
    static getTime() {
        const date = new Date();
        const hours = date.getHours();
        const minutes = date.getMinutes();
        const seconds = date.getSeconds();
        const ms = date.getMilliseconds();
        const time = (hours < 10 ? "0" : "") +
            hours +
            ":" +
            (minutes < 10 ? "0" : "") +
            minutes +
            ":" +
            (seconds < 10 ? "0" : "") +
            seconds +
            "," +
            (ms < 10 ? "00" : (ms < 100 ? "0" : "") + ms);
        return time;
    }
    static log(currentLevel, level, text, ex) {
        if (level <= currentLevel) {
            // Log to the console if it is enabled and exist in the current browser.
            if (Log.isConsoleLogEnabled && window.console) {
                const logText = Log.getLogEntry(level, text, ex);
                if (level <= 1) {
                    console.error(logText);
                }
                else if (level === 2) {
                    console.warn(logText);
                }
                else if (level === 3) {
                    console.info(logText);
                }
                else {
                    console.log(logText);
                }
            }
            if (Log.appenders) {
                for (let i = 0; i < Log.appenders.length; i++) {
                    try {
                        Log.appenders[i](level, text, ex);
                    }
                    catch (e) { }
                }
            }
        }
    }
}
class UIUtil {
    /**
     * Check if the locale options of LocaleCompare is supported by the current runtime environment.
     */
    static localeCompareSupportsLocales() {
        const options = {
            localeMatcher: "lookup",
            usage: "search",
            sensitivity: "base",
            ignorePunctuation: true,
            numeric: true,
            caseFirst: "upper",
        };
        try {
            return "a".localeCompare("A", "en-US", options) === 0;
        }
        catch (e) {
            Log.debug("The full implementation of LocaleCompare is not supported by this browser.");
        }
        return false;
    }
}

/**
 * Defines standard button combinations for a message dialog.
 *
 * @since 1.0
 */
var StandardDialogButtons;
(function (StandardDialogButtons) {
    /**
     * Shows an OK button (1).
     */
    StandardDialogButtons[StandardDialogButtons["Ok"] = 1] = "Ok";
    /**
     * Shows an OK button and a Cancel button (2).
     */
    StandardDialogButtons[StandardDialogButtons["OkCancel"] = 2] = "OkCancel";
    /**
     * Shows a Yes and a No button (3).
     */
    StandardDialogButtons[StandardDialogButtons["YesNo"] = 3] = "YesNo";
    /**
     * Shows a Yes, No and a Cancel button (4).
     */
    StandardDialogButtons[StandardDialogButtons["YesNoCancel"] = 4] = "YesNoCancel";
})(StandardDialogButtons || (StandardDialogButtons = {}));
/**
 * Defines the different types of buttons that can be used in dialogs.
 *
 * @since 1.0
 */
var DialogButtonType;
(function (DialogButtonType) {
    /**
     * No button is used or the button is unknown (1).
     */
    DialogButtonType[DialogButtonType["None"] = 1] = "None";
    /**
     * OK button (2).
     */
    DialogButtonType[DialogButtonType["Ok"] = 2] = "Ok";
    /**
     * Cancel button (3).
     */
    DialogButtonType[DialogButtonType["Cancel"] = 3] = "Cancel";
    /**
     * Yes button (4).
     */
    DialogButtonType[DialogButtonType["Yes"] = 4] = "Yes";
    /**
     * No button (5).
     */
    DialogButtonType[DialogButtonType["No"] = 5] = "No";
    /**
     * Custom button (6).
     */
    DialogButtonType[DialogButtonType["Custom"] = 6] = "Custom";
})(DialogButtonType || (DialogButtonType = {}));
/**
 * Represent the dialog service that can be use to show standard message dialogs or dialogs with custom content.
 *
 * @since 1.0.17
 */
class DialogService {
    constructor(messageService) {
        this.messageService = messageService;
        this.language = {};
        this.initLanguage();
    }
    /**
     * Shows a message dialog.
     *
     * @param options The message dialog options.
     * @returns An Observable that can be used to subscribe to the dialog result.
     */
    showMessage(options) {
        const subject = new AsyncSubject();
        let buttons = null;
        if (!options.buttons && !options.standardButtons) {
            options.standardButtons = StandardDialogButtons.Ok;
        }
        if (options.standardButtons !== null) {
            buttons = this.setDefaultButtons(options.standardButtons, subject, CommonUtil.isUndefined(options.hasPrimaryButton) ||
                options.hasPrimaryButton === true);
        }
        else if (options.buttons) {
            buttons = this.setSpecificButtons(options.buttons, subject);
        }
        this.messageService
            .message()
            .title(HtmlUtil.escapeStringForHtml(options.title))
            .message(HtmlUtil.escapeStringForHtml(options.message))
            .isError(options.isError === true)
            .buttons(buttons)
            .cssClass(options.cssClass)
            .open();
        return subject.asObservable();
    }
    /**
     * Copies data to clipboard or opens a dialog with the data to copy if copying is not possible.
     * @param options The copy to clipboard options
     */
    copyToClipboard(options) {
        // Escape copy data as it is added to the DOM. Veracode finding.
        const copyData = HtmlUtil.escapeStringForHtml(options.copyData);
        // Create hidden input with the text to be copied and select it.
        const copyElement = document.createElement("textarea");
        copyElement.setAttribute("type", "text");
        copyElement.setAttribute("id", "lm-copy-to-clipboard");
        document.body.appendChild(copyElement);
        $("#lm-copy-to-clipboard").val(copyData);
        copyElement.select();
        const title = this.language.copyToClipboard;
        // Show message if force or browser is Safari
        if (options.forceDialog ||
            (navigator.userAgent.indexOf("Safari") !== -1 &&
                navigator.userAgent.indexOf("Chrome") === -1)) {
            this.showMessage({
                title: title,
                message: copyData,
                cssClass: "lm-text",
            });
        }
        else {
            // Copy the input text or open a dialog with the text if it fails.
            try {
                document.execCommand("copy");
            }
            catch (e) {
                this.showMessage({
                    title: title,
                    message: copyData,
                    cssClass: "lm-text",
                });
            }
        }
        // Remove the hidden input
        $("#lm-copy-to-clipboard").remove();
    }
    /**
     * Shows a toast notification with the specified options.
     *
     * Defaults position to "bottom right" and timeout to 3000 if not set.
     */
    showToast(options) {
        options.title = HtmlUtil.escapeStringForHtml(options.title);
        options.message = HtmlUtil.escapeStringForHtml(options.message);
        if (!options.position) {
            options.position = "bottom right";
        }
        if (!options.timeout) {
            options.timeout = 3000;
        }
        $("body").toast(options);
    }
    initLanguage() {
        // Workaround for the ILanguageService not being part of lime
        let language;
        if (typeof infor !== "undefined") {
            language = infor.lime.ResourcesKeys;
        }
        else {
            language = {};
        }
        this.language = language;
    }
    setDefaultButtons(defaults, subject, hasPrimaryButton) {
        const language = this.language;
        const buttons = [];
        if (defaults === StandardDialogButtons.OkCancel ||
            defaults === StandardDialogButtons.YesNoCancel) {
            buttons.push({
                text: language.cancel || "Cancel",
                click: (e, modal) => {
                    modal.close();
                    this.resolveMessageDialog(subject, {
                        button: DialogButtonType.Cancel,
                    });
                },
                isDefault: false,
            });
        }
        if (defaults === StandardDialogButtons.Ok ||
            defaults === StandardDialogButtons.OkCancel) {
            buttons.push({
                text: language.ok || "OK",
                click: (e, modal) => {
                    modal.close();
                    this.resolveMessageDialog(subject, { button: DialogButtonType.Ok });
                },
                isDefault: hasPrimaryButton,
            });
        }
        else if (defaults === StandardDialogButtons.YesNo ||
            defaults === StandardDialogButtons.YesNoCancel) {
            buttons.push({
                text: language.no || "No",
                click: (e, modal) => {
                    modal.close();
                    this.resolveMessageDialog(subject, { button: DialogButtonType.No });
                },
                isDefault: false,
            });
            buttons.push({
                text: language.yes || "Yes",
                click: (e, modal) => {
                    modal.close();
                    this.resolveMessageDialog(subject, { button: DialogButtonType.Yes });
                },
                isDefault: hasPrimaryButton,
            });
        }
        return buttons;
    }
    setSpecificButtons(specificButtons, subject) {
        const buttons = [];
        for (const button of specificButtons) {
            button.click = (e, modal) => {
                modal.close();
                const result = { button: button.type };
                this.resolveMessageDialog(subject, result);
            };
            buttons.push(button);
        }
        return buttons;
    }
    resolveMessageDialog(subject, result) {
        subject.next(result);
        subject.complete();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.2.1", ngImport: i0, type: DialogService, deps: [{ token: i1.SohoMessageService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.2.1", ngImport: i0, type: DialogService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.2.1", ngImport: i0, type: DialogService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.SohoMessageService }] });

/**
 * Content translation service.
 * @since 1.0.22
 */
class TranslationService {
    initialize(instance) {
        if (this.instance) {
            throw new Error("Already initialized");
        }
        this.instance = instance;
    }
    /**
     * Gets a value that indicates if content translation is enabled.
     * This function must be called before translation is enabled in a widget.
     */
    isEnabled() {
        return this.instance && this.instance.isEnabled();
    }
    /**
     * Shows a dialog for content translation.
     * @param options dialog options
     * @returns an Observable that will be resolved to an ITranslationResult if the user
     * closes the dialog with OK or rejected if the user closes the dialog with cancel.
     */
    translate(options) {
        if (this.isEnabled()) {
            return this.instance.translate(options);
        }
        else {
            console.error("[TranslationService] Unable to open translation dialog. The service is not available.");
            return EMPTY;
        }
    }
    /**
     * Gets the current language code.
     */
    getLanguage() {
        if (this.isEnabled()) {
            return this.instance.getLanguage();
        }
        else {
            console.warn("[TranslationService] The service is not available. Returning infor.lime.language");
            return infor.lime.language;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.2.1", ngImport: i0, type: TranslationService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.2.1", ngImport: i0, type: TranslationService, providedIn: "root" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.2.1", ngImport: i0, type: TranslationService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: "root",
                }]
        }] });

/* Most of this file consist of interfaces. Many are "for future use" placeholders, so having them empty is okay */
/* eslint-disable @typescript-eslint/no-empty-interface */
/**
 * Badge type controlling the background color of the badge.
 *
 * @since 3.8.0
 */
var BadgeType;
(function (BadgeType) {
    BadgeType[BadgeType["Info"] = 0] = "Info";
    BadgeType[BadgeType["Alert"] = 1] = "Alert";
    BadgeType[BadgeType["Error"] = 2] = "Error";
    BadgeType[BadgeType["Good"] = 3] = "Good";
})(BadgeType || (BadgeType = {}));
var TrackEventType;
(function (TrackEventType) {
    TrackEventType["Click"] = "click";
})(TrackEventType || (TrackEventType = {}));
/**
 * Icon to be used in the empty state message shown by {@link IWidgetContext.setEmptyState}.
 *
 * @since 3.11.0
 */
var EmptyStateIcon;
(function (EmptyStateIcon) {
    EmptyStateIcon["ErrorLoading"] = "empty-error-loading";
    EmptyStateIcon["Generic"] = "empty-generic";
    EmptyStateIcon["NewProject"] = "empty-new-project";
    EmptyStateIcon["NoAlerts"] = "empty-no-alerts";
    EmptyStateIcon["NoAnalytics"] = "empty-no-analytics";
    EmptyStateIcon["NoBudget"] = "empty-no-budget";
    EmptyStateIcon["NoData"] = "empty-no-data";
    EmptyStateIcon["NoEvents"] = "empty-no-events";
    EmptyStateIcon["NoNotes"] = "empty-no-notes";
    EmptyStateIcon["NoOrders"] = "empty-no-orders";
    EmptyStateIcon["NoTasks"] = "empty-no-tasks";
    EmptyStateIcon["NoUsers"] = "empty-no-users";
    EmptyStateIcon["SearchData"] = "empty-search-data";
})(EmptyStateIcon || (EmptyStateIcon = {}));
/**
 * Defines widget states.
 * @since 1.0
 */
class WidgetState {
    /**
     * Running state.
     *
     * The running state is the default widget state.
     */
    static { this.running = "running"; }
    /**
     * Busy state.
     *
     * The busy state can be used to indicate that the widget is busy performing an operation
     * such as a server request.
     */
    static { this.busy = "busy"; }
    /**
     * Error state.
     *
     * The error state indicates that the widget is broken in some way and is not functioning properly.
     * There could be different reasons for this such as missing settings
     * or that a backend service cannot be reached for example.
     */
    static { this.error = "error"; }
}
/**
 * Defines widget activation and deactivation types.
 *
 * The activation types indicates what caused a widget to be activated or deactivated.
 * Most types can be used for both activation and deactivation but close for example can only be used in deactivation.
 *
 * @since 1.0
 */
class WidgetActivationType {
    /**
     * The widget visibility has been changed.
     */
    static { this.visibility = "visibility"; }
    /**
     * The "close" type has been deprecated since it was never raised.
     * If it was raised it would only happen just before the widget is destroyed which serves no purpose.
     *
     * Usage is deprected from version 2.0.0 and the property may be removed in future versions.
     *
     * @deprecated
     */
    static { this.close = "close"; }
    /**
     * The widget settings dialog has been opened or closed.
     */
    static { this.settings = "settings"; }
    /**
     * The widget has entered or exited edit mode.
     */
    static { this.edit = "edit"; }
}
/**
 * Used to define severity in IWidgetMessage.
 *
 * @since 1.0
 */
var WidgetMessageType;
(function (WidgetMessageType) {
    /**
     * Information message.
     */
    WidgetMessageType[WidgetMessageType["Info"] = 0] = "Info";
    /**
     * Alert message.
     */
    WidgetMessageType[WidgetMessageType["Alert"] = 1] = "Alert";
    /**
     * Error message.
     */
    WidgetMessageType[WidgetMessageType["Error"] = 2] = "Error";
    /**
     * Success message.
     * @since 3.10.0
     */
    WidgetMessageType[WidgetMessageType["Success"] = 3] = "Success";
})(WidgetMessageType || (WidgetMessageType = {}));
/**
 * Represents a widget instance.
 *
 * An object of this type should be returned by the widgetFactory function in the widget module.
 * All properties in this interface are optional however so it is OK to return an empty object.
 *
 * A widget implementation may choose which properties to set depending on what types of callbacks the widget requires.
 *
 * @since 1.0
 */
class IWidgetInstance {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.2.1", ngImport: i0, type: IWidgetInstance, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.2.1", ngImport: i0, type: IWidgetInstance }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.2.1", ngImport: i0, type: IWidgetInstance, decorators: [{
            type: Injectable
        }] });
/**
 * Represents the different types of widget settings.
 * All except the object type are supported in the metadata settings UI.
 *
 * @since 1.0
 */
class WidgetSettingsType {
    static { this.stringType = "string"; }
    static { this.numberType = "number"; }
    static { this.booleanType = "boolean"; }
    static { this.selectorType = "selector"; }
    static { this.radioType = "radio"; }
    static { this.objectType = "object"; }
}
/**
 * Defines ION API constants.
 *
 * @since 1.0.17
 */
class IonApiConstants {
    /**
     * Gets the name of the header used to specify the platform that is calling ION API.
     * The header value should always be "homepages", specified in the platformHeaderValue property.
     */
    static { this.platformHeaderName = "x-infor-ionapi-platform"; }
    /**
     * Gets the ION API platform header value to use in Homepages.
     */
    static { this.platformHeaderValue = "infor.homepages"; }
    /**
     * Gets the name of the header used to specify the source that is calling ION API.
     * The value should be the standard widget ID of the calling widget.
     */
    static { this.sourceHeaderName = "x-infor-ionapi-source"; }
}
/**
 * Represents the context for a widget in runtime.
 *
 * The context is received as a parameter to the widgetFactory function in the widget module.
 *
 * The context provides a widget instance with data, settings, the DOM element etc and
 * functions that can be used to interact with the framework.
 *
 * @since 1.0
 */
class IWidgetContext {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.2.1", ngImport: i0, type: IWidgetContext, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.2.1", ngImport: i0, type: IWidgetContext }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.2.1", ngImport: i0, type: IWidgetContext, decorators: [{
            type: Injectable
        }] });
/**
 * Represents a custom widget settings instance.
 *
 * An object of this type should be set in IWidgetSettingsobject when settingsOpenings is called.
 *
 * A widget implementation may choose which properties to set depending on what types of callbacks the widget requires.
 *
 * @since 1.0
 */
class IWidgetSettingsInstance {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.2.1", ngImport: i0, type: IWidgetSettingsInstance, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.2.1", ngImport: i0, type: IWidgetSettingsInstance }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.2.1", ngImport: i0, type: IWidgetSettingsInstance, decorators: [{
            type: Injectable
        }] });
/**
 * Represents the context for a custom settings UI implementation.
 *
 * @since 1.0
 */
class IWidgetSettingsContext {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.2.1", ngImport: i0, type: IWidgetSettingsContext, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.2.1", ngImport: i0, type: IWidgetSettingsContext }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.2.1", ngImport: i0, type: IWidgetSettingsContext, decorators: [{
            type: Injectable
        }] });
/**
 * Defines widget constants.
 *
 * @since 1.0
 */
class WidgetConstants {
    static { this.widgetInstanceKey = "lmWidgetInstance"; }
    static { this.widgetContextKey = "lmWidgetContext"; }
    static { this.widgetTitle = "widgetTitle"; }
    static { this.widgetDescription = "widgetDescription"; }
}
/**
 * Gets the Angular injection token for the widget context.
 * Use this when injecting the widget context in an Angular component constructor.
 *
 * @since 1.0.22
 */
const widgetContextInjectionToken = new InjectionToken("widgetContext");
/**
 * Gets the Angular injection token for the widget instance.
 * Use this when injecting the widget instance in an Angular component constructor.
 *
 * @since 1.0.22
 */
const widgetInstanceInjectionToken = new InjectionToken("widgetInstance");
/**
 * Defines the different modes the widget can be executing in. The widget will start in one mode
 * that cannot changed during the entire session.
 * @since 1.0.34
 */
var Mode;
(function (Mode) {
    Mode[Mode["Default"] = 0] = "Default";
    Mode[Mode["Mobile"] = 1] = "Mobile";
    Mode[Mode["ContextApp"] = 2] = "ContextApp";
})(Mode || (Mode = {}));
/**
 * Defines a sub mode if applicable. The widget will start in one mode
 * that cannot changed during the entire session. Currently there is only sub modes for the Mobile mode when a widget
 * can be part of a page or in a single view mode which is called MobileSingle.
 * @since 1.0.34
 */
var SubMode;
(function (SubMode) {
    SubMode[SubMode["Default"] = 0] = "Default";
    SubMode[SubMode["MobilePage"] = 1] = "MobilePage";
    SubMode[SubMode["MobileSingle"] = 2] = "MobileSingle";
})(SubMode || (SubMode = {}));

/*
 * Public API Surface of lime
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ArrayUtil, BadgeType, CommonUtil, DialogButtonType, DialogService, EmptyStateIcon, HtmlUtil, IWidgetContext, IWidgetInstance, IWidgetSettingsContext, IWidgetSettingsInstance, IonApiConstants, Log, Mode, NumUtil, StandardDialogButtons, StringUtil, SubMode, TrackEventType, TranslationService, WidgetActivationType, WidgetConstants, WidgetMessageType, WidgetSettingsType, WidgetState, widgetContextInjectionToken, widgetInstanceInjectionToken };
//# sourceMappingURL=lime.mjs.map
