# Infor Widget SDK API documentation.

Click on one of the namespace links to the right or click the magnifier icon to show the search field.
